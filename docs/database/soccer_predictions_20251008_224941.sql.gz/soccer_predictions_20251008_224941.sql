pg_dump: last built-in OID is 16383
pg_dump: reading extensions
pg_dump: identifying extension members
pg_dump: reading schemas
pg_dump: reading user-defined tables
pg_dump: reading user-defined functions
pg_dump: reading user-defined types
pg_dump: reading procedural languages
pg_dump: reading user-defined aggregate functions
pg_dump: reading user-defined operators
pg_dump: reading user-defined access methods
pg_dump: reading user-defined operator classes
pg_dump: reading user-defined operator families
pg_dump: reading user-defined text search parsers
pg_dump: reading user-defined text search templates
pg_dump: reading user-defined text search dictionaries
pg_dump: reading user-defined text search configurations
pg_dump: reading user-defined foreign-data wrappers
pg_dump: reading user-defined foreign servers
pg_dump: reading default privileges
pg_dump: reading user-defined collations
pg_dump: reading user-defined conversions
pg_dump: reading type casts
pg_dump: reading transforms
pg_dump: reading table inheritance information
pg_dump: reading event triggers
pg_dump: finding extension tables
pg_dump: finding inheritance relationships
pg_dump: reading column info for interesting tables
pg_dump: finding table default expressions
pg_dump: finding table check constraints
pg_dump: flagging inherited columns in subtables
pg_dump: reading partitioning data
pg_dump: reading indexes
pg_dump: flagging indexes in partitioned tables
pg_dump: reading extended statistics
pg_dump: reading constraints
pg_dump: reading triggers
pg_dump: reading rewrite rules
pg_dump: reading policies
pg_dump: reading row-level security policies
pg_dump: reading publications
pg_dump: reading publication membership of tables
pg_dump: reading publication membership of schemas
pg_dump: reading subscriptions
pg_dump: reading large objects
pg_dump: reading dependency data
pg_dump: saving encoding = UTF8
pg_dump: saving standard_conforming_strings = on
pg_dump: saving search_path = 
pg_dump: saving database definition
--
-- PostgreSQL database dump
--

\restrict EgneefYQixXTeWaKaunCsxPltTcz7aNYxYcxmzzauW1xthQVgGFQfPU4mU3BSdE

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

-- Started on 2025-10-09 02:49:41 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

pg_dump: dropping DATABASE PROPERTIES soccer_predictions
pg_dump: dropping DATABASE soccer_predictions
DROP DATABASE IF EXISTS soccer_predictions;
pg_dump: creating DATABASE "soccer_predictions"
--
-- TOC entry 4537 (class 1262 OID 16384)
-- Name: soccer_predictions; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE soccer_predictions WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE soccer_predictions OWNER TO postgres;

pg_dump: connecting to new database "soccer_predictions"
\unrestrict EgneefYQixXTeWaKaunCsxPltTcz7aNYxYcxmzzauW1xthQVgGFQfPU4mU3BSdE
\connect soccer_predictions
\restrict EgneefYQixXTeWaKaunCsxPltTcz7aNYxYcxmzzauW1xthQVgGFQfPU4mU3BSdE

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

pg_dump: creating DATABASE PROPERTIES "soccer_predictions"
--
-- TOC entry 4538 (class 0 OID 0)
-- Name: soccer_predictions; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE soccer_predictions SET search_path TO 'users', 'predictions', 'ml_models', 'analytics', 'audit', 'public';


pg_dump: connecting to new database "soccer_predictions"
\unrestrict EgneefYQixXTeWaKaunCsxPltTcz7aNYxYcxmzzauW1xthQVgGFQfPU4mU3BSdE
\connect soccer_predictions
\restrict EgneefYQixXTeWaKaunCsxPltTcz7aNYxYcxmzzauW1xthQVgGFQfPU4mU3BSdE

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

pg_dump: creating SCHEMA "analytics"
--
-- TOC entry 13 (class 2615 OID 16388)
-- Name: analytics; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA analytics;


ALTER SCHEMA analytics OWNER TO postgres;

pg_dump: creating SCHEMA "audit"
--
-- TOC entry 14 (class 2615 OID 16389)
-- Name: audit; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA audit;


ALTER SCHEMA audit OWNER TO postgres;

pg_dump: creating SCHEMA "ml_models"
--
-- TOC entry 12 (class 2615 OID 16387)
-- Name: ml_models; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA ml_models;


ALTER SCHEMA ml_models OWNER TO postgres;

pg_dump: creating SCHEMA "predictions"
--
-- TOC entry 11 (class 2615 OID 16386)
-- Name: predictions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA predictions;


ALTER SCHEMA predictions OWNER TO postgres;

pg_dump: creating SCHEMA "users"
--
-- TOC entry 10 (class 2615 OID 16385)
-- Name: users; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA users;


ALTER SCHEMA users OWNER TO postgres;

pg_dump: creating EXTENSION "btree_gin"
--
-- TOC entry 3 (class 3079 OID 16401)
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


pg_dump: creating COMMENT "EXTENSION btree_gin"
--
-- TOC entry 4539 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


pg_dump: creating EXTENSION "pg_trgm"
--
-- TOC entry 4 (class 3079 OID 16837)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


pg_dump: creating COMMENT "EXTENSION pg_trgm"
--
-- TOC entry 4540 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


pg_dump: creating EXTENSION "pgcrypto"
--
-- TOC entry 5 (class 3079 OID 16918)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


pg_dump: creating COMMENT "EXTENSION pgcrypto"
--
-- TOC entry 4541 (class 0 OID 0)
-- Dependencies: 5
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


pg_dump: creating EXTENSION "uuid-ossp"
--
-- TOC entry 2 (class 3079 OID 16390)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


pg_dump: creating COMMENT "EXTENSION "uuid-ossp""
--
-- TOC entry 4542 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


pg_dump: creating TYPE "users.accountstatus"
--
-- TOC entry 1125 (class 1247 OID 21670)
-- Name: accountstatus; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.accountstatus AS ENUM (
    'ACTIVE',
    'SUSPENDED',
    'DELETED',
    'PENDING_VERIFICATION'
);


ALTER TYPE users.accountstatus OWNER TO postgres;

pg_dump: creating TYPE "users.analyticsperiod"
--
-- TOC entry 1086 (class 1247 OID 21537)
-- Name: analyticsperiod; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.analyticsperiod AS ENUM (
    'HOURLY',
    'DAILY',
    'WEEKLY',
    'MONTHLY',
    'YEARLY'
);


ALTER TYPE users.analyticsperiod OWNER TO postgres;

pg_dump: creating TYPE "users.auditaction"
--
-- TOC entry 1149 (class 1247 OID 21780)
-- Name: auditaction; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.auditaction AS ENUM (
    'CREATE',
    'READ',
    'UPDATE',
    'DELETE',
    'LOGIN',
    'LOGOUT',
    'APPROVE',
    'REJECT',
    'PUBLISH',
    'ARCHIVE'
);


ALTER TYPE users.auditaction OWNER TO postgres;

pg_dump: creating TYPE "users.auditseverity"
--
-- TOC entry 1152 (class 1247 OID 21802)
-- Name: auditseverity; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.auditseverity AS ENUM (
    'INFO',
    'WARNING',
    'ERROR',
    'CRITICAL'
);


ALTER TYPE users.auditseverity OWNER TO postgres;

pg_dump: creating TYPE "users.dataexportstatus"
--
-- TOC entry 1161 (class 1247 OID 21853)
-- Name: dataexportstatus; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.dataexportstatus AS ENUM (
    'REQUESTED',
    'PROCESSING',
    'COMPLETED',
    'FAILED',
    'EXPIRED'
);


ALTER TYPE users.dataexportstatus OWNER TO postgres;

pg_dump: creating TYPE "users.deploymentstatus"
--
-- TOC entry 1287 (class 1247 OID 22542)
-- Name: deploymentstatus; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.deploymentstatus AS ENUM (
    'DEPLOYING',
    'ACTIVE',
    'INACTIVE',
    'FAILED',
    'ROLLED_BACK'
);


ALTER TYPE users.deploymentstatus OWNER TO postgres;

pg_dump: creating TYPE "users.engagementlevel"
--
-- TOC entry 1140 (class 1247 OID 21741)
-- Name: engagementlevel; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.engagementlevel AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'VERY_HIGH'
);


ALTER TYPE users.engagementlevel OWNER TO postgres;

pg_dump: creating TYPE "users.gdprconsenttype"
--
-- TOC entry 1167 (class 1247 OID 21880)
-- Name: gdprconsenttype; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.gdprconsenttype AS ENUM (
    'MARKETING',
    'ANALYTICS',
    'PERSONALIZATION',
    'THIRD_PARTY_SHARING',
    'ESSENTIAL'
);


ALTER TYPE users.gdprconsenttype OWNER TO postgres;

pg_dump: creating TYPE "users.markettype"
--
-- TOC entry 1323 (class 1247 OID 22780)
-- Name: markettype; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.markettype AS ENUM (
    'MATCH_RESULT',
    'OVER_UNDER',
    'BOTH_TEAMS_SCORE',
    'CORRECT_SCORE',
    'DOUBLE_CHANCE'
);


ALTER TYPE users.markettype OWNER TO postgres;

pg_dump: creating TYPE "users.matchstatus"
--
-- TOC entry 1191 (class 1247 OID 22003)
-- Name: matchstatus; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.matchstatus AS ENUM (
    'SCHEDULED',
    'LIVE',
    'FINISHED',
    'POSTPONED',
    'CANCELLED'
);


ALTER TYPE users.matchstatus OWNER TO postgres;

pg_dump: creating TYPE "users.modelstatus"
--
-- TOC entry 1185 (class 1247 OID 21972)
-- Name: modelstatus; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.modelstatus AS ENUM (
    'DEVELOPMENT',
    'TESTING',
    'STAGING',
    'PRODUCTION',
    'DEPRECATED',
    'ARCHIVED'
);


ALTER TYPE users.modelstatus OWNER TO postgres;

pg_dump: creating TYPE "users.modeltype"
--
-- TOC entry 1182 (class 1247 OID 21959)
-- Name: modeltype; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.modeltype AS ENUM (
    'RANDOM_FOREST',
    'XGBOOST',
    'NEURAL_NETWORK',
    'ENSEMBLE',
    'LOGISTIC_REGRESSION',
    'SVM'
);


ALTER TYPE users.modeltype OWNER TO postgres;

pg_dump: creating TYPE "users.notificationtype"
--
-- TOC entry 1215 (class 1247 OID 22150)
-- Name: notificationtype; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.notificationtype AS ENUM (
    'PREDICTION_PUBLISHED',
    'PREDICTION_RESULT',
    'EXPERT_OVERRIDE',
    'SYSTEM_ALERT',
    'SUBSCRIPTION_EXPIRING'
);


ALTER TYPE users.notificationtype OWNER TO postgres;

pg_dump: creating TYPE "users.predictionoutcome"
--
-- TOC entry 1332 (class 1247 OID 22841)
-- Name: predictionoutcome; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.predictionoutcome AS ENUM (
    'PENDING',
    'WON',
    'LOST',
    'VOID',
    'PUSH'
);


ALTER TYPE users.predictionoutcome OWNER TO postgres;

pg_dump: creating TYPE "users.predictionsource"
--
-- TOC entry 1302 (class 1247 OID 22637)
-- Name: predictionsource; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.predictionsource AS ENUM (
    'ML_BASELINE',
    'EXPERT_OVERRIDE',
    'EXPERT_MANUAL',
    'ADMIN_MANUAL'
);


ALTER TYPE users.predictionsource OWNER TO postgres;

pg_dump: creating TYPE "users.predictionstatus"
--
-- TOC entry 1305 (class 1247 OID 22646)
-- Name: predictionstatus; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.predictionstatus AS ENUM (
    'PENDING',
    'UNDER_REVIEW',
    'APPROVED',
    'PUBLISHED',
    'ARCHIVED',
    'REJECTED'
);


ALTER TYPE users.predictionstatus OWNER TO postgres;

pg_dump: creating TYPE "users.subscriptionstatus"
--
-- TOC entry 1233 (class 1247 OID 22244)
-- Name: subscriptionstatus; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.subscriptionstatus AS ENUM (
    'ACTIVE',
    'CANCELLED',
    'EXPIRED',
    'TRIAL'
);


ALTER TYPE users.subscriptionstatus OWNER TO postgres;

pg_dump: creating TYPE "users.subscriptiontier"
--
-- TOC entry 1230 (class 1247 OID 22234)
-- Name: subscriptiontier; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.subscriptiontier AS ENUM (
    'FREE',
    'BASIC',
    'PREMIUM',
    'PRO'
);


ALTER TYPE users.subscriptiontier OWNER TO postgres;

pg_dump: creating TYPE "users.trainingstatus"
--
-- TOC entry 1296 (class 1247 OID 22598)
-- Name: trainingstatus; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.trainingstatus AS ENUM (
    'QUEUED',
    'RUNNING',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


ALTER TYPE users.trainingstatus OWNER TO postgres;

pg_dump: creating TYPE "users.usertype"
--
-- TOC entry 1122 (class 1247 OID 21662)
-- Name: usertype; Type: TYPE; Schema: users; Owner: postgres
--

CREATE TYPE users.usertype AS ENUM (
    'REGULAR',
    'EXPERT',
    'ADMIN'
);


ALTER TYPE users.usertype OWNER TO postgres;

pg_dump: creating FUNCTION "public.generate_slug(text)"
--
-- TOC entry 468 (class 1255 OID 17098)
-- Name: generate_slug(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.generate_slug(text_input text) RETURNS text
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN lower(regexp_replace(text_input, '[^a-zA-Z0-9]+', '-', 'g'));
END;
$$;


ALTER FUNCTION public.generate_slug(text_input text) OWNER TO postgres;

pg_dump: creating FUNCTION "public.update_updated_at_column()"
--
-- TOC entry 467 (class 1255 OID 17097)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

pg_dump: creating TABLE "analytics.api_usage_analytics"
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 238 (class 1259 OID 21695)
-- Name: api_usage_analytics; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.api_usage_analytics (
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    period_type users.analyticsperiod NOT NULL,
    endpoint character varying(255) NOT NULL,
    http_method character varying(10) NOT NULL,
    user_id uuid,
    total_requests bigint NOT NULL,
    successful_requests bigint NOT NULL,
    failed_requests bigint NOT NULL,
    average_response_time_ms integer,
    p50_response_time_ms integer,
    p95_response_time_ms integer,
    p99_response_time_ms integer,
    error_rate numeric(5,4),
    detailed_metrics jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.api_usage_analytics OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE api_usage_analytics"
--
-- TOC entry 4543 (class 0 OID 0)
-- Dependencies: 238
-- Name: TABLE api_usage_analytics; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.api_usage_analytics IS 'API usage analytics';


pg_dump: creating COMMENT "analytics.COLUMN api_usage_analytics.id"
--
-- TOC entry 4544 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN api_usage_analytics.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.api_usage_analytics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN api_usage_analytics.created_at"
--
-- TOC entry 4545 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN api_usage_analytics.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.api_usage_analytics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN api_usage_analytics.updated_at"
--
-- TOC entry 4546 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN api_usage_analytics.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.api_usage_analytics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "analytics.conversion_analytics"
--
-- TOC entry 226 (class 1259 OID 21547)
-- Name: conversion_analytics; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.conversion_analytics (
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    period_type users.analyticsperiod NOT NULL,
    funnel_name character varying(255) NOT NULL,
    funnel_step character varying(100) NOT NULL,
    funnel_step_order integer NOT NULL,
    total_entered integer NOT NULL,
    total_completed integer NOT NULL,
    total_dropped integer NOT NULL,
    completion_rate numeric(5,4),
    drop_off_rate numeric(5,4),
    average_time_to_complete_seconds integer,
    detailed_metrics jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.conversion_analytics OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE conversion_analytics"
--
-- TOC entry 4547 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE conversion_analytics; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.conversion_analytics IS 'Conversion analytics';


pg_dump: creating COMMENT "analytics.COLUMN conversion_analytics.funnel_name"
--
-- TOC entry 4548 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN conversion_analytics.funnel_name; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.conversion_analytics.funnel_name IS 'signup, subscription, etc.';


pg_dump: creating COMMENT "analytics.COLUMN conversion_analytics.id"
--
-- TOC entry 4549 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN conversion_analytics.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.conversion_analytics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN conversion_analytics.created_at"
--
-- TOC entry 4550 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN conversion_analytics.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.conversion_analytics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN conversion_analytics.updated_at"
--
-- TOC entry 4551 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN conversion_analytics.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.conversion_analytics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "analytics.error_analytics"
--
-- TOC entry 227 (class 1259 OID 21556)
-- Name: error_analytics; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.error_analytics (
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    period_type users.analyticsperiod NOT NULL,
    error_type character varying(255) NOT NULL,
    error_category character varying(100),
    severity character varying(50),
    total_occurrences bigint NOT NULL,
    unique_users_affected integer NOT NULL,
    total_requests_affected bigint NOT NULL,
    error_rate numeric(5,4),
    is_resolved boolean NOT NULL,
    resolved_at timestamp without time zone,
    detailed_metrics jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.error_analytics OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE error_analytics"
--
-- TOC entry 4552 (class 0 OID 0)
-- Dependencies: 227
-- Name: TABLE error_analytics; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.error_analytics IS 'Error analytics';


pg_dump: creating COMMENT "analytics.COLUMN error_analytics.severity"
--
-- TOC entry 4553 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN error_analytics.severity; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.error_analytics.severity IS 'critical, error, warning';


pg_dump: creating COMMENT "analytics.COLUMN error_analytics.id"
--
-- TOC entry 4554 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN error_analytics.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.error_analytics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN error_analytics.created_at"
--
-- TOC entry 4555 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN error_analytics.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.error_analytics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN error_analytics.updated_at"
--
-- TOC entry 4556 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN error_analytics.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.error_analytics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "analytics.expert_analytics"
--
-- TOC entry 263 (class 1259 OID 22270)
-- Name: expert_analytics; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.expert_analytics (
    expert_profile_id uuid NOT NULL,
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    period_type users.analyticsperiod NOT NULL,
    total_predictions integer NOT NULL,
    total_overrides integer NOT NULL,
    predictions_approved integer NOT NULL,
    predictions_rejected integer NOT NULL,
    total_settled integer NOT NULL,
    total_correct integer NOT NULL,
    accuracy_rate numeric(5,4),
    override_accuracy numeric(5,4),
    override_improvement numeric(6,4),
    total_followers integer NOT NULL,
    follower_growth integer,
    average_prediction_views numeric(10,2),
    reputation_score integer,
    reputation_change integer,
    detailed_metrics jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.expert_analytics OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE expert_analytics"
--
-- TOC entry 4557 (class 0 OID 0)
-- Dependencies: 263
-- Name: TABLE expert_analytics; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.expert_analytics IS 'Expert analytics';


pg_dump: creating COMMENT "analytics.COLUMN expert_analytics.override_improvement"
--
-- TOC entry 4558 (class 0 OID 0)
-- Dependencies: 263
-- Name: COLUMN expert_analytics.override_improvement; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.expert_analytics.override_improvement IS 'Improvement over ML baseline';


pg_dump: creating COMMENT "analytics.COLUMN expert_analytics.id"
--
-- TOC entry 4559 (class 0 OID 0)
-- Dependencies: 263
-- Name: COLUMN expert_analytics.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.expert_analytics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN expert_analytics.created_at"
--
-- TOC entry 4560 (class 0 OID 0)
-- Dependencies: 263
-- Name: COLUMN expert_analytics.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.expert_analytics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN expert_analytics.updated_at"
--
-- TOC entry 4561 (class 0 OID 0)
-- Dependencies: 263
-- Name: COLUMN expert_analytics.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.expert_analytics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "analytics.feature_usage_analytics"
--
-- TOC entry 228 (class 1259 OID 21566)
-- Name: feature_usage_analytics; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.feature_usage_analytics (
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    period_type users.analyticsperiod NOT NULL,
    feature_name character varying(255) NOT NULL,
    feature_category character varying(100),
    total_users integer NOT NULL,
    total_uses bigint NOT NULL,
    unique_users integer NOT NULL,
    average_uses_per_user numeric(10,2),
    adoption_rate numeric(5,4),
    detailed_metrics jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.feature_usage_analytics OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE feature_usage_analytics"
--
-- TOC entry 4562 (class 0 OID 0)
-- Dependencies: 228
-- Name: TABLE feature_usage_analytics; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.feature_usage_analytics IS 'Feature usage analytics';


pg_dump: creating COMMENT "analytics.COLUMN feature_usage_analytics.adoption_rate"
--
-- TOC entry 4563 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN feature_usage_analytics.adoption_rate; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.feature_usage_analytics.adoption_rate IS '% of active users using feature';


pg_dump: creating COMMENT "analytics.COLUMN feature_usage_analytics.id"
--
-- TOC entry 4564 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN feature_usage_analytics.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.feature_usage_analytics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN feature_usage_analytics.created_at"
--
-- TOC entry 4565 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN feature_usage_analytics.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.feature_usage_analytics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN feature_usage_analytics.updated_at"
--
-- TOC entry 4566 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN feature_usage_analytics.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.feature_usage_analytics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "analytics.model_performance_analytics"
--
-- TOC entry 264 (class 1259 OID 22285)
-- Name: model_performance_analytics; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.model_performance_analytics (
    model_id uuid NOT NULL,
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    period_type users.analyticsperiod NOT NULL,
    total_predictions integer NOT NULL,
    predictions_used integer NOT NULL,
    predictions_overridden integer NOT NULL,
    total_settled integer NOT NULL,
    total_correct integer NOT NULL,
    accuracy_rate numeric(5,4),
    average_confidence numeric(5,4),
    confidence_calibration numeric(5,4),
    override_rate numeric(5,4),
    override_accuracy_delta numeric(6,4),
    detailed_metrics jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.model_performance_analytics OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE model_performance_analytics"
--
-- TOC entry 4567 (class 0 OID 0)
-- Dependencies: 264
-- Name: TABLE model_performance_analytics; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.model_performance_analytics IS 'Model performance analytics';


pg_dump: creating COMMENT "analytics.COLUMN model_performance_analytics.predictions_used"
--
-- TOC entry 4568 (class 0 OID 0)
-- Dependencies: 264
-- Name: COLUMN model_performance_analytics.predictions_used; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.model_performance_analytics.predictions_used IS 'Not overridden';


pg_dump: creating COMMENT "analytics.COLUMN model_performance_analytics.override_accuracy_delta"
--
-- TOC entry 4569 (class 0 OID 0)
-- Dependencies: 264
-- Name: COLUMN model_performance_analytics.override_accuracy_delta; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.model_performance_analytics.override_accuracy_delta IS 'Accuracy change after override';


pg_dump: creating COMMENT "analytics.COLUMN model_performance_analytics.id"
--
-- TOC entry 4570 (class 0 OID 0)
-- Dependencies: 264
-- Name: COLUMN model_performance_analytics.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.model_performance_analytics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN model_performance_analytics.created_at"
--
-- TOC entry 4571 (class 0 OID 0)
-- Dependencies: 264
-- Name: COLUMN model_performance_analytics.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.model_performance_analytics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN model_performance_analytics.updated_at"
--
-- TOC entry 4572 (class 0 OID 0)
-- Dependencies: 264
-- Name: COLUMN model_performance_analytics.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.model_performance_analytics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "analytics.prediction_analytics_summary"
--
-- TOC entry 229 (class 1259 OID 21575)
-- Name: prediction_analytics_summary; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.prediction_analytics_summary (
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    period_type users.analyticsperiod NOT NULL,
    total_predictions integer NOT NULL,
    ml_predictions integer NOT NULL,
    expert_predictions integer NOT NULL,
    expert_overrides integer NOT NULL,
    total_settled integer NOT NULL,
    total_correct integer NOT NULL,
    overall_accuracy numeric(5,4),
    ml_accuracy numeric(5,4),
    expert_accuracy numeric(5,4),
    total_views bigint NOT NULL,
    total_shares integer NOT NULL,
    total_comments integer NOT NULL,
    detailed_metrics jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.prediction_analytics_summary OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE prediction_analytics_summary"
--
-- TOC entry 4573 (class 0 OID 0)
-- Dependencies: 229
-- Name: TABLE prediction_analytics_summary; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.prediction_analytics_summary IS 'Prediction analytics summary';


pg_dump: creating COMMENT "analytics.COLUMN prediction_analytics_summary.id"
--
-- TOC entry 4574 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN prediction_analytics_summary.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.prediction_analytics_summary.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN prediction_analytics_summary.created_at"
--
-- TOC entry 4575 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN prediction_analytics_summary.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.prediction_analytics_summary.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN prediction_analytics_summary.updated_at"
--
-- TOC entry 4576 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN prediction_analytics_summary.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.prediction_analytics_summary.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "analytics.prediction_performance_metrics"
--
-- TOC entry 239 (class 1259 OID 21710)
-- Name: prediction_performance_metrics; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.prediction_performance_metrics (
    metric_date timestamp without time zone NOT NULL,
    league_id uuid,
    market_type character varying(50),
    total_predictions integer NOT NULL,
    correct_predictions integer NOT NULL,
    accuracy_rate numeric(5,4),
    average_confidence numeric(5,4),
    confidence_calibration numeric(5,4),
    average_roi numeric(10,2),
    total_roi numeric(15,2),
    performance_metadata jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.prediction_performance_metrics OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE prediction_performance_metrics"
--
-- TOC entry 4577 (class 0 OID 0)
-- Dependencies: 239
-- Name: TABLE prediction_performance_metrics; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.prediction_performance_metrics IS 'Prediction performance metrics';


pg_dump: creating COMMENT "analytics.COLUMN prediction_performance_metrics.id"
--
-- TOC entry 4578 (class 0 OID 0)
-- Dependencies: 239
-- Name: COLUMN prediction_performance_metrics.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.prediction_performance_metrics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN prediction_performance_metrics.created_at"
--
-- TOC entry 4579 (class 0 OID 0)
-- Dependencies: 239
-- Name: COLUMN prediction_performance_metrics.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.prediction_performance_metrics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN prediction_performance_metrics.updated_at"
--
-- TOC entry 4580 (class 0 OID 0)
-- Dependencies: 239
-- Name: COLUMN prediction_performance_metrics.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.prediction_performance_metrics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "analytics.revenue_analytics"
--
-- TOC entry 230 (class 1259 OID 21584)
-- Name: revenue_analytics; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.revenue_analytics (
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    period_type users.analyticsperiod NOT NULL,
    subscription_tier character varying(50),
    total_revenue numeric(15,2) NOT NULL,
    new_revenue numeric(15,2) NOT NULL,
    recurring_revenue numeric(15,2) NOT NULL,
    mrr numeric(15,2),
    arr numeric(15,2),
    total_paying_customers integer NOT NULL,
    new_customers integer NOT NULL,
    churned_customers integer NOT NULL,
    arpu numeric(10,2),
    churn_rate numeric(5,4),
    detailed_metrics jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.revenue_analytics OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE revenue_analytics"
--
-- TOC entry 4581 (class 0 OID 0)
-- Dependencies: 230
-- Name: TABLE revenue_analytics; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.revenue_analytics IS 'Revenue analytics';


pg_dump: creating COMMENT "analytics.COLUMN revenue_analytics.mrr"
--
-- TOC entry 4582 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN revenue_analytics.mrr; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.revenue_analytics.mrr IS 'Monthly Recurring Revenue';


pg_dump: creating COMMENT "analytics.COLUMN revenue_analytics.arr"
--
-- TOC entry 4583 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN revenue_analytics.arr; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.revenue_analytics.arr IS 'Annual Recurring Revenue';


pg_dump: creating COMMENT "analytics.COLUMN revenue_analytics.arpu"
--
-- TOC entry 4584 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN revenue_analytics.arpu; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.revenue_analytics.arpu IS 'Average Revenue Per User';


pg_dump: creating COMMENT "analytics.COLUMN revenue_analytics.id"
--
-- TOC entry 4585 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN revenue_analytics.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.revenue_analytics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN revenue_analytics.created_at"
--
-- TOC entry 4586 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN revenue_analytics.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.revenue_analytics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN revenue_analytics.updated_at"
--
-- TOC entry 4587 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN revenue_analytics.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.revenue_analytics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "analytics.system_analytics"
--
-- TOC entry 231 (class 1259 OID 21594)
-- Name: system_analytics; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.system_analytics (
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    period_type users.analyticsperiod NOT NULL,
    total_users integer NOT NULL,
    active_users integer NOT NULL,
    new_users integer NOT NULL,
    churned_users integer NOT NULL,
    total_subscribers integer NOT NULL,
    new_subscribers integer NOT NULL,
    cancelled_subscriptions integer NOT NULL,
    total_predictions integer NOT NULL,
    published_predictions integer NOT NULL,
    average_response_time_ms integer,
    error_rate numeric(5,4),
    uptime_percentage numeric(5,2),
    detailed_metrics jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.system_analytics OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE system_analytics"
--
-- TOC entry 4588 (class 0 OID 0)
-- Dependencies: 231
-- Name: TABLE system_analytics; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.system_analytics IS 'System analytics';


pg_dump: creating COMMENT "analytics.COLUMN system_analytics.id"
--
-- TOC entry 4589 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN system_analytics.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.system_analytics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN system_analytics.created_at"
--
-- TOC entry 4590 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN system_analytics.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.system_analytics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN system_analytics.updated_at"
--
-- TOC entry 4591 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN system_analytics.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.system_analytics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "analytics.user_activity_log"
--
-- TOC entry 240 (class 1259 OID 21725)
-- Name: user_activity_log; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.user_activity_log (
    user_id uuid,
    activity_type character varying(100) NOT NULL,
    activity_category character varying(100),
    activity_description text,
    session_id character varying(255),
    page_url character varying(500),
    referrer_url character varying(500),
    device_type character varying(50),
    browser character varying(100),
    os character varying(100),
    country character varying(100),
    city character varying(100),
    activity_metadata jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.user_activity_log OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE user_activity_log"
--
-- TOC entry 4592 (class 0 OID 0)
-- Dependencies: 240
-- Name: TABLE user_activity_log; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.user_activity_log IS 'Analytics user activity log';


pg_dump: creating COMMENT "analytics.COLUMN user_activity_log.user_id"
--
-- TOC entry 4593 (class 0 OID 0)
-- Dependencies: 240
-- Name: COLUMN user_activity_log.user_id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_activity_log.user_id IS 'Null for anonymous';


pg_dump: creating COMMENT "analytics.COLUMN user_activity_log.device_type"
--
-- TOC entry 4594 (class 0 OID 0)
-- Dependencies: 240
-- Name: COLUMN user_activity_log.device_type; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_activity_log.device_type IS 'desktop, mobile, tablet';


pg_dump: creating COMMENT "analytics.COLUMN user_activity_log.id"
--
-- TOC entry 4595 (class 0 OID 0)
-- Dependencies: 240
-- Name: COLUMN user_activity_log.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_activity_log.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN user_activity_log.created_at"
--
-- TOC entry 4596 (class 0 OID 0)
-- Dependencies: 240
-- Name: COLUMN user_activity_log.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_activity_log.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN user_activity_log.updated_at"
--
-- TOC entry 4597 (class 0 OID 0)
-- Dependencies: 240
-- Name: COLUMN user_activity_log.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_activity_log.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "analytics.user_analytics"
--
-- TOC entry 241 (class 1259 OID 21749)
-- Name: user_analytics; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.user_analytics (
    user_id uuid NOT NULL,
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    period_type users.analyticsperiod NOT NULL,
    total_logins integer NOT NULL,
    total_sessions integer NOT NULL,
    total_session_duration_seconds bigint NOT NULL,
    average_session_duration_seconds integer,
    predictions_viewed integer NOT NULL,
    predictions_shared integer NOT NULL,
    predictions_commented integer NOT NULL,
    predictions_rated integer NOT NULL,
    engagement_score numeric(10,2),
    engagement_level users.engagementlevel,
    detailed_metrics jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.user_analytics OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE user_analytics"
--
-- TOC entry 4598 (class 0 OID 0)
-- Dependencies: 241
-- Name: TABLE user_analytics; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.user_analytics IS 'User analytics summary';


pg_dump: creating COMMENT "analytics.COLUMN user_analytics.engagement_score"
--
-- TOC entry 4599 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN user_analytics.engagement_score; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_analytics.engagement_score IS 'Composite engagement score';


pg_dump: creating COMMENT "analytics.COLUMN user_analytics.id"
--
-- TOC entry 4600 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN user_analytics.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_analytics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN user_analytics.created_at"
--
-- TOC entry 4601 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN user_analytics.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_analytics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN user_analytics.updated_at"
--
-- TOC entry 4602 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN user_analytics.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_analytics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "analytics.user_engagement_metrics"
--
-- TOC entry 242 (class 1259 OID 21764)
-- Name: user_engagement_metrics; Type: TABLE; Schema: analytics; Owner: postgres
--

CREATE TABLE analytics.user_engagement_metrics (
    user_id uuid NOT NULL,
    metric_date timestamp without time zone NOT NULL,
    metric_type character varying(100) NOT NULL,
    metric_category character varying(100),
    metric_value numeric(15,4) NOT NULL,
    metric_count integer NOT NULL,
    page_url character varying(500),
    referrer_url character varying(500),
    metric_metadata jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE analytics.user_engagement_metrics OWNER TO postgres;

pg_dump: creating COMMENT "analytics.TABLE user_engagement_metrics"
--
-- TOC entry 4603 (class 0 OID 0)
-- Dependencies: 242
-- Name: TABLE user_engagement_metrics; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON TABLE analytics.user_engagement_metrics IS 'User engagement metrics';


pg_dump: creating COMMENT "analytics.COLUMN user_engagement_metrics.metric_type"
--
-- TOC entry 4604 (class 0 OID 0)
-- Dependencies: 242
-- Name: COLUMN user_engagement_metrics.metric_type; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_engagement_metrics.metric_type IS 'page_view, click, scroll, etc.';


pg_dump: creating COMMENT "analytics.COLUMN user_engagement_metrics.metric_category"
--
-- TOC entry 4605 (class 0 OID 0)
-- Dependencies: 242
-- Name: COLUMN user_engagement_metrics.metric_category; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_engagement_metrics.metric_category IS 'navigation, content, interaction';


pg_dump: creating COMMENT "analytics.COLUMN user_engagement_metrics.id"
--
-- TOC entry 4606 (class 0 OID 0)
-- Dependencies: 242
-- Name: COLUMN user_engagement_metrics.id; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_engagement_metrics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "analytics.COLUMN user_engagement_metrics.created_at"
--
-- TOC entry 4607 (class 0 OID 0)
-- Dependencies: 242
-- Name: COLUMN user_engagement_metrics.created_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_engagement_metrics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "analytics.COLUMN user_engagement_metrics.updated_at"
--
-- TOC entry 4608 (class 0 OID 0)
-- Dependencies: 242
-- Name: COLUMN user_engagement_metrics.updated_at; Type: COMMENT; Schema: analytics; Owner: postgres
--

COMMENT ON COLUMN analytics.user_engagement_metrics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "audit.admin_action_log"
--
-- TOC entry 265 (class 1259 OID 22299)
-- Name: admin_action_log; Type: TABLE; Schema: audit; Owner: postgres
--

CREATE TABLE audit.admin_action_log (
    admin_user_id uuid NOT NULL,
    admin_profile_id uuid,
    action_type character varying(100) NOT NULL,
    action_category character varying(50),
    action_description text NOT NULL,
    target_resource_type character varying(100),
    target_resource_id uuid,
    target_user_id uuid,
    changes_made jsonb NOT NULL,
    justification text,
    requires_approval boolean NOT NULL,
    approved_by_admin_id uuid,
    approved_at timestamp without time zone,
    ip_address inet,
    user_agent text,
    retention_until timestamp without time zone,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE audit.admin_action_log OWNER TO postgres;

pg_dump: creating COMMENT "audit.TABLE admin_action_log"
--
-- TOC entry 4609 (class 0 OID 0)
-- Dependencies: 265
-- Name: TABLE admin_action_log; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON TABLE audit.admin_action_log IS 'Admin action log';


pg_dump: creating COMMENT "audit.COLUMN admin_action_log.action_category"
--
-- TOC entry 4610 (class 0 OID 0)
-- Dependencies: 265
-- Name: COLUMN admin_action_log.action_category; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.admin_action_log.action_category IS 'user_management, prediction_approval, etc.';


pg_dump: creating COMMENT "audit.COLUMN admin_action_log.target_resource_type"
--
-- TOC entry 4611 (class 0 OID 0)
-- Dependencies: 265
-- Name: COLUMN admin_action_log.target_resource_type; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.admin_action_log.target_resource_type IS 'user, prediction, expert, etc.';


pg_dump: creating COMMENT "audit.COLUMN admin_action_log.target_user_id"
--
-- TOC entry 4612 (class 0 OID 0)
-- Dependencies: 265
-- Name: COLUMN admin_action_log.target_user_id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.admin_action_log.target_user_id IS 'If action targets a user';


pg_dump: creating COMMENT "audit.COLUMN admin_action_log.changes_made"
--
-- TOC entry 4613 (class 0 OID 0)
-- Dependencies: 265
-- Name: COLUMN admin_action_log.changes_made; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.admin_action_log.changes_made IS 'Detailed changes';


pg_dump: creating COMMENT "audit.COLUMN admin_action_log.justification"
--
-- TOC entry 4614 (class 0 OID 0)
-- Dependencies: 265
-- Name: COLUMN admin_action_log.justification; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.admin_action_log.justification IS 'Reason for action';


pg_dump: creating COMMENT "audit.COLUMN admin_action_log.id"
--
-- TOC entry 4615 (class 0 OID 0)
-- Dependencies: 265
-- Name: COLUMN admin_action_log.id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.admin_action_log.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "audit.COLUMN admin_action_log.created_at"
--
-- TOC entry 4616 (class 0 OID 0)
-- Dependencies: 265
-- Name: COLUMN admin_action_log.created_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.admin_action_log.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "audit.COLUMN admin_action_log.updated_at"
--
-- TOC entry 4617 (class 0 OID 0)
-- Dependencies: 265
-- Name: COLUMN admin_action_log.updated_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.admin_action_log.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "audit.audit_log"
--
-- TOC entry 243 (class 1259 OID 21811)
-- Name: audit_log; Type: TABLE; Schema: audit; Owner: postgres
--

CREATE TABLE audit.audit_log (
    user_id uuid,
    user_type character varying(50),
    action users.auditaction NOT NULL,
    action_description text,
    severity users.auditseverity NOT NULL,
    resource_type character varying(100) NOT NULL,
    resource_id uuid,
    resource_name character varying(255),
    old_values jsonb,
    new_values jsonb,
    changes_summary text,
    ip_address inet,
    user_agent text,
    session_id character varying(255),
    request_id character varying(255),
    audit_metadata jsonb,
    retention_until timestamp without time zone,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE audit.audit_log OWNER TO postgres;

pg_dump: creating COMMENT "audit.TABLE audit_log"
--
-- TOC entry 4618 (class 0 OID 0)
-- Dependencies: 243
-- Name: TABLE audit_log; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON TABLE audit.audit_log IS 'Master audit log';


pg_dump: creating COMMENT "audit.COLUMN audit_log.user_id"
--
-- TOC entry 4619 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN audit_log.user_id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.audit_log.user_id IS 'Null for system actions';


pg_dump: creating COMMENT "audit.COLUMN audit_log.user_type"
--
-- TOC entry 4620 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN audit_log.user_type; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.audit_log.user_type IS 'regular, expert, admin, system';


pg_dump: creating COMMENT "audit.COLUMN audit_log.resource_type"
--
-- TOC entry 4621 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN audit_log.resource_type; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.audit_log.resource_type IS 'user, prediction, match, etc.';


pg_dump: creating COMMENT "audit.COLUMN audit_log.resource_id"
--
-- TOC entry 4622 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN audit_log.resource_id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.audit_log.resource_id IS 'ID of affected resource';


pg_dump: creating COMMENT "audit.COLUMN audit_log.old_values"
--
-- TOC entry 4623 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN audit_log.old_values; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.audit_log.old_values IS 'Previous values';


pg_dump: creating COMMENT "audit.COLUMN audit_log.new_values"
--
-- TOC entry 4624 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN audit_log.new_values; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.audit_log.new_values IS 'New values';


pg_dump: creating COMMENT "audit.COLUMN audit_log.request_id"
--
-- TOC entry 4625 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN audit_log.request_id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.audit_log.request_id IS 'Request tracking ID';


pg_dump: creating COMMENT "audit.COLUMN audit_log.audit_metadata"
--
-- TOC entry 4626 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN audit_log.audit_metadata; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.audit_log.audit_metadata IS 'Additional audit data';


pg_dump: creating COMMENT "audit.COLUMN audit_log.retention_until"
--
-- TOC entry 4627 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN audit_log.retention_until; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.audit_log.retention_until IS 'GDPR retention date';


pg_dump: creating COMMENT "audit.COLUMN audit_log.id"
--
-- TOC entry 4628 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN audit_log.id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.audit_log.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "audit.COLUMN audit_log.created_at"
--
-- TOC entry 4629 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN audit_log.created_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.audit_log.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "audit.COLUMN audit_log.updated_at"
--
-- TOC entry 4630 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN audit_log.updated_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.audit_log.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "audit.data_access_log"
--
-- TOC entry 244 (class 1259 OID 21830)
-- Name: data_access_log; Type: TABLE; Schema: audit; Owner: postgres
--

CREATE TABLE audit.data_access_log (
    user_id uuid,
    user_role character varying(50),
    accessed_user_id uuid,
    data_type character varying(100) NOT NULL,
    data_id uuid,
    access_method character varying(50) NOT NULL,
    access_reason text,
    is_authorized boolean NOT NULL,
    authorization_basis character varying(100),
    ip_address inet,
    user_agent text,
    access_metadata jsonb,
    retention_until timestamp without time zone,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE audit.data_access_log OWNER TO postgres;

pg_dump: creating COMMENT "audit.TABLE data_access_log"
--
-- TOC entry 4631 (class 0 OID 0)
-- Dependencies: 244
-- Name: TABLE data_access_log; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON TABLE audit.data_access_log IS 'Data access log';


pg_dump: creating COMMENT "audit.COLUMN data_access_log.user_id"
--
-- TOC entry 4632 (class 0 OID 0)
-- Dependencies: 244
-- Name: COLUMN data_access_log.user_id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_access_log.user_id IS 'Who accessed the data';


pg_dump: creating COMMENT "audit.COLUMN data_access_log.accessed_user_id"
--
-- TOC entry 4633 (class 0 OID 0)
-- Dependencies: 244
-- Name: COLUMN data_access_log.accessed_user_id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_access_log.accessed_user_id IS 'Whose data was accessed';


pg_dump: creating COMMENT "audit.COLUMN data_access_log.data_type"
--
-- TOC entry 4634 (class 0 OID 0)
-- Dependencies: 244
-- Name: COLUMN data_access_log.data_type; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_access_log.data_type IS 'user_profile, prediction, etc.';


pg_dump: creating COMMENT "audit.COLUMN data_access_log.access_method"
--
-- TOC entry 4635 (class 0 OID 0)
-- Dependencies: 244
-- Name: COLUMN data_access_log.access_method; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_access_log.access_method IS 'api, admin_panel, export';


pg_dump: creating COMMENT "audit.COLUMN data_access_log.access_reason"
--
-- TOC entry 4636 (class 0 OID 0)
-- Dependencies: 244
-- Name: COLUMN data_access_log.access_reason; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_access_log.access_reason IS 'Reason for access';


pg_dump: creating COMMENT "audit.COLUMN data_access_log.authorization_basis"
--
-- TOC entry 4637 (class 0 OID 0)
-- Dependencies: 244
-- Name: COLUMN data_access_log.authorization_basis; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_access_log.authorization_basis IS 'consent, legitimate_interest, etc.';


pg_dump: creating COMMENT "audit.COLUMN data_access_log.id"
--
-- TOC entry 4638 (class 0 OID 0)
-- Dependencies: 244
-- Name: COLUMN data_access_log.id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_access_log.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "audit.COLUMN data_access_log.created_at"
--
-- TOC entry 4639 (class 0 OID 0)
-- Dependencies: 244
-- Name: COLUMN data_access_log.created_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_access_log.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "audit.COLUMN data_access_log.updated_at"
--
-- TOC entry 4640 (class 0 OID 0)
-- Dependencies: 244
-- Name: COLUMN data_access_log.updated_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_access_log.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "audit.data_export_log"
--
-- TOC entry 245 (class 1259 OID 21863)
-- Name: data_export_log; Type: TABLE; Schema: audit; Owner: postgres
--

CREATE TABLE audit.data_export_log (
    user_id uuid NOT NULL,
    request_type character varying(50) NOT NULL,
    requested_data_types jsonb,
    status users.dataexportstatus NOT NULL,
    requested_at timestamp without time zone NOT NULL,
    processing_started_at timestamp without time zone,
    completed_at timestamp without time zone,
    expires_at timestamp without time zone,
    export_file_path character varying(500),
    export_file_size_bytes bigint,
    export_format character varying(20),
    download_count integer NOT NULL,
    last_downloaded_at timestamp without time zone,
    error_message text,
    ip_address inet,
    user_agent text,
    export_metadata jsonb,
    retention_until timestamp without time zone NOT NULL,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE audit.data_export_log OWNER TO postgres;

pg_dump: creating COMMENT "audit.TABLE data_export_log"
--
-- TOC entry 4641 (class 0 OID 0)
-- Dependencies: 245
-- Name: TABLE data_export_log; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON TABLE audit.data_export_log IS 'GDPR data export log';


pg_dump: creating COMMENT "audit.COLUMN data_export_log.request_type"
--
-- TOC entry 4642 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN data_export_log.request_type; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_export_log.request_type IS 'full_export, specific_data';


pg_dump: creating COMMENT "audit.COLUMN data_export_log.requested_data_types"
--
-- TOC entry 4643 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN data_export_log.requested_data_types; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_export_log.requested_data_types IS 'Types of data requested';


pg_dump: creating COMMENT "audit.COLUMN data_export_log.expires_at"
--
-- TOC entry 4644 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN data_export_log.expires_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_export_log.expires_at IS 'Export file expiration';


pg_dump: creating COMMENT "audit.COLUMN data_export_log.export_file_path"
--
-- TOC entry 4645 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN data_export_log.export_file_path; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_export_log.export_file_path IS 'S3 path to export file';


pg_dump: creating COMMENT "audit.COLUMN data_export_log.export_format"
--
-- TOC entry 4646 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN data_export_log.export_format; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_export_log.export_format IS 'json, csv, xml';


pg_dump: creating COMMENT "audit.COLUMN data_export_log.id"
--
-- TOC entry 4647 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN data_export_log.id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_export_log.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "audit.COLUMN data_export_log.created_at"
--
-- TOC entry 4648 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN data_export_log.created_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_export_log.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "audit.COLUMN data_export_log.updated_at"
--
-- TOC entry 4649 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN data_export_log.updated_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.data_export_log.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "audit.gdpr_consent_log"
--
-- TOC entry 246 (class 1259 OID 21891)
-- Name: gdpr_consent_log; Type: TABLE; Schema: audit; Owner: postgres
--

CREATE TABLE audit.gdpr_consent_log (
    user_id uuid NOT NULL,
    consent_type users.gdprconsenttype NOT NULL,
    consent_version character varying(50) NOT NULL,
    is_granted boolean NOT NULL,
    is_active boolean NOT NULL,
    granted_at timestamp without time zone,
    revoked_at timestamp without time zone,
    expires_at timestamp without time zone,
    consent_text text NOT NULL,
    consent_language character varying(10),
    ip_address inet,
    user_agent text,
    consent_method character varying(50),
    consent_metadata jsonb,
    retention_until timestamp without time zone NOT NULL,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE audit.gdpr_consent_log OWNER TO postgres;

pg_dump: creating COMMENT "audit.TABLE gdpr_consent_log"
--
-- TOC entry 4650 (class 0 OID 0)
-- Dependencies: 246
-- Name: TABLE gdpr_consent_log; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON TABLE audit.gdpr_consent_log IS 'GDPR consent log';


pg_dump: creating COMMENT "audit.COLUMN gdpr_consent_log.consent_version"
--
-- TOC entry 4651 (class 0 OID 0)
-- Dependencies: 246
-- Name: COLUMN gdpr_consent_log.consent_version; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.gdpr_consent_log.consent_version IS 'Version of consent text';


pg_dump: creating COMMENT "audit.COLUMN gdpr_consent_log.consent_text"
--
-- TOC entry 4652 (class 0 OID 0)
-- Dependencies: 246
-- Name: COLUMN gdpr_consent_log.consent_text; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.gdpr_consent_log.consent_text IS 'Exact consent text shown';


pg_dump: creating COMMENT "audit.COLUMN gdpr_consent_log.consent_method"
--
-- TOC entry 4653 (class 0 OID 0)
-- Dependencies: 246
-- Name: COLUMN gdpr_consent_log.consent_method; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.gdpr_consent_log.consent_method IS 'web_form, api, email, etc.';


pg_dump: creating COMMENT "audit.COLUMN gdpr_consent_log.id"
--
-- TOC entry 4654 (class 0 OID 0)
-- Dependencies: 246
-- Name: COLUMN gdpr_consent_log.id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.gdpr_consent_log.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "audit.COLUMN gdpr_consent_log.created_at"
--
-- TOC entry 4655 (class 0 OID 0)
-- Dependencies: 246
-- Name: COLUMN gdpr_consent_log.created_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.gdpr_consent_log.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "audit.COLUMN gdpr_consent_log.updated_at"
--
-- TOC entry 4656 (class 0 OID 0)
-- Dependencies: 246
-- Name: COLUMN gdpr_consent_log.updated_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.gdpr_consent_log.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "audit.prediction_change_log"
--
-- TOC entry 282 (class 1259 OID 22699)
-- Name: prediction_change_log; Type: TABLE; Schema: audit; Owner: postgres
--

CREATE TABLE audit.prediction_change_log (
    prediction_id uuid NOT NULL,
    changed_by uuid NOT NULL,
    change_type character varying(50) NOT NULL,
    change_description text,
    field_changed character varying(100),
    old_value jsonb,
    new_value jsonb,
    old_probabilities jsonb,
    new_probabilities jsonb,
    probability_delta jsonb,
    old_confidence numeric(5,4),
    new_confidence numeric(5,4),
    confidence_delta numeric(6,4),
    change_reason text,
    ip_address inet,
    user_agent text,
    retention_until timestamp without time zone,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE audit.prediction_change_log OWNER TO postgres;

pg_dump: creating COMMENT "audit.TABLE prediction_change_log"
--
-- TOC entry 4657 (class 0 OID 0)
-- Dependencies: 282
-- Name: TABLE prediction_change_log; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON TABLE audit.prediction_change_log IS 'Prediction change log';


pg_dump: creating COMMENT "audit.COLUMN prediction_change_log.change_type"
--
-- TOC entry 4658 (class 0 OID 0)
-- Dependencies: 282
-- Name: COLUMN prediction_change_log.change_type; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.prediction_change_log.change_type IS 'created, updated, approved, published';


pg_dump: creating COMMENT "audit.COLUMN prediction_change_log.probability_delta"
--
-- TOC entry 4659 (class 0 OID 0)
-- Dependencies: 282
-- Name: COLUMN prediction_change_log.probability_delta; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.prediction_change_log.probability_delta IS 'Change in probabilities';


pg_dump: creating COMMENT "audit.COLUMN prediction_change_log.id"
--
-- TOC entry 4660 (class 0 OID 0)
-- Dependencies: 282
-- Name: COLUMN prediction_change_log.id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.prediction_change_log.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "audit.COLUMN prediction_change_log.created_at"
--
-- TOC entry 4661 (class 0 OID 0)
-- Dependencies: 282
-- Name: COLUMN prediction_change_log.created_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.prediction_change_log.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "audit.COLUMN prediction_change_log.updated_at"
--
-- TOC entry 4662 (class 0 OID 0)
-- Dependencies: 282
-- Name: COLUMN prediction_change_log.updated_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.prediction_change_log.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "audit.system_event_log"
--
-- TOC entry 247 (class 1259 OID 21907)
-- Name: system_event_log; Type: TABLE; Schema: audit; Owner: postgres
--

CREATE TABLE audit.system_event_log (
    event_type character varying(100) NOT NULL,
    event_category character varying(50),
    event_description text NOT NULL,
    severity users.auditseverity NOT NULL,
    source_component character varying(100),
    source_function character varying(255),
    error_message text,
    error_traceback text,
    error_code character varying(50),
    affected_users_count integer,
    affected_requests_count integer,
    is_resolved boolean NOT NULL,
    resolved_at timestamp without time zone,
    resolved_by_admin_id uuid,
    resolution_notes text,
    event_metadata jsonb,
    retention_until timestamp without time zone,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE audit.system_event_log OWNER TO postgres;

pg_dump: creating COMMENT "audit.TABLE system_event_log"
--
-- TOC entry 4663 (class 0 OID 0)
-- Dependencies: 247
-- Name: TABLE system_event_log; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON TABLE audit.system_event_log IS 'System event log';


pg_dump: creating COMMENT "audit.COLUMN system_event_log.event_category"
--
-- TOC entry 4664 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN system_event_log.event_category; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.system_event_log.event_category IS 'deployment, error, performance, security';


pg_dump: creating COMMENT "audit.COLUMN system_event_log.source_component"
--
-- TOC entry 4665 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN system_event_log.source_component; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.system_event_log.source_component IS 'api, ml_service, database, etc.';


pg_dump: creating COMMENT "audit.COLUMN system_event_log.id"
--
-- TOC entry 4666 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN system_event_log.id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.system_event_log.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "audit.COLUMN system_event_log.created_at"
--
-- TOC entry 4667 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN system_event_log.created_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.system_event_log.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "audit.COLUMN system_event_log.updated_at"
--
-- TOC entry 4668 (class 0 OID 0)
-- Dependencies: 247
-- Name: COLUMN system_event_log.updated_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.system_event_log.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "audit.user_action_log"
--
-- TOC entry 248 (class 1259 OID 21923)
-- Name: user_action_log; Type: TABLE; Schema: audit; Owner: postgres
--

CREATE TABLE audit.user_action_log (
    user_id uuid NOT NULL,
    action_type character varying(100) NOT NULL,
    action_category character varying(50),
    action_description text,
    action_result character varying(50),
    error_message text,
    is_suspicious boolean NOT NULL,
    risk_score integer,
    ip_address inet,
    user_agent text,
    session_id character varying(255),
    country character varying(100),
    city character varying(100),
    action_metadata jsonb,
    retention_until timestamp without time zone,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE audit.user_action_log OWNER TO postgres;

pg_dump: creating COMMENT "audit.TABLE user_action_log"
--
-- TOC entry 4669 (class 0 OID 0)
-- Dependencies: 248
-- Name: TABLE user_action_log; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON TABLE audit.user_action_log IS 'User action log';


pg_dump: creating COMMENT "audit.COLUMN user_action_log.action_category"
--
-- TOC entry 4670 (class 0 OID 0)
-- Dependencies: 248
-- Name: COLUMN user_action_log.action_category; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.user_action_log.action_category IS 'authentication, profile, prediction, etc.';


pg_dump: creating COMMENT "audit.COLUMN user_action_log.action_result"
--
-- TOC entry 4671 (class 0 OID 0)
-- Dependencies: 248
-- Name: COLUMN user_action_log.action_result; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.user_action_log.action_result IS 'success, failure, blocked';


pg_dump: creating COMMENT "audit.COLUMN user_action_log.risk_score"
--
-- TOC entry 4672 (class 0 OID 0)
-- Dependencies: 248
-- Name: COLUMN user_action_log.risk_score; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.user_action_log.risk_score IS '0-100 risk score';


pg_dump: creating COMMENT "audit.COLUMN user_action_log.id"
--
-- TOC entry 4673 (class 0 OID 0)
-- Dependencies: 248
-- Name: COLUMN user_action_log.id; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.user_action_log.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "audit.COLUMN user_action_log.created_at"
--
-- TOC entry 4674 (class 0 OID 0)
-- Dependencies: 248
-- Name: COLUMN user_action_log.created_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.user_action_log.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "audit.COLUMN user_action_log.updated_at"
--
-- TOC entry 4675 (class 0 OID 0)
-- Dependencies: 248
-- Name: COLUMN user_action_log.updated_at; Type: COMMENT; Schema: audit; Owner: postgres
--

COMMENT ON COLUMN audit.user_action_log.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "ml_models.ml_ab_test_results"
--
-- TOC entry 277 (class 1259 OID 22521)
-- Name: ml_ab_test_results; Type: TABLE; Schema: ml_models; Owner: postgres
--

CREATE TABLE ml_models.ml_ab_test_results (
    ab_test_id uuid NOT NULL,
    model_id uuid NOT NULL,
    evaluation_date timestamp without time zone NOT NULL,
    total_predictions integer NOT NULL,
    correct_predictions integer NOT NULL,
    accuracy numeric(5,4),
    user_engagement_score numeric(10,2),
    average_confidence numeric(5,4),
    detailed_results jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ml_models.ml_ab_test_results OWNER TO postgres;

pg_dump: creating COMMENT "ml_models.TABLE ml_ab_test_results"
--
-- TOC entry 4676 (class 0 OID 0)
-- Dependencies: 277
-- Name: TABLE ml_ab_test_results; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON TABLE ml_models.ml_ab_test_results IS 'ML A/B test results';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ab_test_results.id"
--
-- TOC entry 4677 (class 0 OID 0)
-- Dependencies: 277
-- Name: COLUMN ml_ab_test_results.id; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ab_test_results.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ab_test_results.created_at"
--
-- TOC entry 4678 (class 0 OID 0)
-- Dependencies: 277
-- Name: COLUMN ml_ab_test_results.created_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ab_test_results.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ab_test_results.updated_at"
--
-- TOC entry 4679 (class 0 OID 0)
-- Dependencies: 277
-- Name: COLUMN ml_ab_test_results.updated_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ab_test_results.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "ml_models.ml_ab_tests"
--
-- TOC entry 266 (class 1259 OID 22330)
-- Name: ml_ab_tests; Type: TABLE; Schema: ml_models; Owner: postgres
--

CREATE TABLE ml_models.ml_ab_tests (
    test_name character varying(255) NOT NULL,
    description text,
    model_a_id uuid NOT NULL,
    model_b_id uuid NOT NULL,
    traffic_split_percentage integer NOT NULL,
    is_active boolean NOT NULL,
    started_at timestamp without time zone NOT NULL,
    ended_at timestamp without time zone,
    winner_model_id uuid,
    conclusion text,
    created_by_user_id uuid,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ml_models.ml_ab_tests OWNER TO postgres;

pg_dump: creating COMMENT "ml_models.TABLE ml_ab_tests"
--
-- TOC entry 4680 (class 0 OID 0)
-- Dependencies: 266
-- Name: TABLE ml_ab_tests; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON TABLE ml_models.ml_ab_tests IS 'ML A/B tests';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ab_tests.traffic_split_percentage"
--
-- TOC entry 4681 (class 0 OID 0)
-- Dependencies: 266
-- Name: COLUMN ml_ab_tests.traffic_split_percentage; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ab_tests.traffic_split_percentage IS '% traffic to model A';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ab_tests.id"
--
-- TOC entry 4682 (class 0 OID 0)
-- Dependencies: 266
-- Name: COLUMN ml_ab_tests.id; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ab_tests.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ab_tests.created_at"
--
-- TOC entry 4683 (class 0 OID 0)
-- Dependencies: 266
-- Name: COLUMN ml_ab_tests.created_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ab_tests.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ab_tests.updated_at"
--
-- TOC entry 4684 (class 0 OID 0)
-- Dependencies: 266
-- Name: COLUMN ml_ab_tests.updated_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ab_tests.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "ml_models.ml_ensemble_configs"
--
-- TOC entry 267 (class 1259 OID 22361)
-- Name: ml_ensemble_configs; Type: TABLE; Schema: ml_models; Owner: postgres
--

CREATE TABLE ml_models.ml_ensemble_configs (
    ensemble_model_id uuid NOT NULL,
    ensemble_method character varying(50) NOT NULL,
    member_models jsonb NOT NULL,
    model_weights jsonb,
    ensemble_config jsonb,
    is_active boolean NOT NULL,
    ensemble_accuracy numeric(5,4),
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ml_models.ml_ensemble_configs OWNER TO postgres;

pg_dump: creating COMMENT "ml_models.TABLE ml_ensemble_configs"
--
-- TOC entry 4685 (class 0 OID 0)
-- Dependencies: 267
-- Name: TABLE ml_ensemble_configs; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON TABLE ml_models.ml_ensemble_configs IS 'ML ensemble configurations';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ensemble_configs.ensemble_method"
--
-- TOC entry 4686 (class 0 OID 0)
-- Dependencies: 267
-- Name: COLUMN ml_ensemble_configs.ensemble_method; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ensemble_configs.ensemble_method IS 'voting, stacking, blending';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ensemble_configs.member_models"
--
-- TOC entry 4687 (class 0 OID 0)
-- Dependencies: 267
-- Name: COLUMN ml_ensemble_configs.member_models; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ensemble_configs.member_models IS 'List of member model IDs and weights';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ensemble_configs.model_weights"
--
-- TOC entry 4688 (class 0 OID 0)
-- Dependencies: 267
-- Name: COLUMN ml_ensemble_configs.model_weights; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ensemble_configs.model_weights IS 'Weights for each model';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ensemble_configs.ensemble_config"
--
-- TOC entry 4689 (class 0 OID 0)
-- Dependencies: 267
-- Name: COLUMN ml_ensemble_configs.ensemble_config; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ensemble_configs.ensemble_config IS 'Additional ensemble configuration';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ensemble_configs.id"
--
-- TOC entry 4690 (class 0 OID 0)
-- Dependencies: 267
-- Name: COLUMN ml_ensemble_configs.id; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ensemble_configs.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ensemble_configs.created_at"
--
-- TOC entry 4691 (class 0 OID 0)
-- Dependencies: 267
-- Name: COLUMN ml_ensemble_configs.created_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ensemble_configs.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "ml_models.COLUMN ml_ensemble_configs.updated_at"
--
-- TOC entry 4692 (class 0 OID 0)
-- Dependencies: 267
-- Name: COLUMN ml_ensemble_configs.updated_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_ensemble_configs.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "ml_models.ml_feature_engineering"
--
-- TOC entry 249 (class 1259 OID 21939)
-- Name: ml_feature_engineering; Type: TABLE; Schema: ml_models; Owner: postgres
--

CREATE TABLE ml_models.ml_feature_engineering (
    feature_id uuid NOT NULL,
    transformation_name character varying(255) NOT NULL,
    transformation_type character varying(100),
    transformation_config jsonb NOT NULL,
    transformation_code text,
    is_active boolean NOT NULL,
    created_by_user_id uuid,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ml_models.ml_feature_engineering OWNER TO postgres;

pg_dump: creating COMMENT "ml_models.TABLE ml_feature_engineering"
--
-- TOC entry 4693 (class 0 OID 0)
-- Dependencies: 249
-- Name: TABLE ml_feature_engineering; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON TABLE ml_models.ml_feature_engineering IS 'Feature engineering';


pg_dump: creating COMMENT "ml_models.COLUMN ml_feature_engineering.transformation_type"
--
-- TOC entry 4694 (class 0 OID 0)
-- Dependencies: 249
-- Name: COLUMN ml_feature_engineering.transformation_type; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_feature_engineering.transformation_type IS 'scaling, encoding, binning, etc.';


pg_dump: creating COMMENT "ml_models.COLUMN ml_feature_engineering.transformation_code"
--
-- TOC entry 4695 (class 0 OID 0)
-- Dependencies: 249
-- Name: COLUMN ml_feature_engineering.transformation_code; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_feature_engineering.transformation_code IS 'Python code for transformation';


pg_dump: creating COMMENT "ml_models.COLUMN ml_feature_engineering.id"
--
-- TOC entry 4696 (class 0 OID 0)
-- Dependencies: 249
-- Name: COLUMN ml_feature_engineering.id; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_feature_engineering.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "ml_models.COLUMN ml_feature_engineering.created_at"
--
-- TOC entry 4697 (class 0 OID 0)
-- Dependencies: 249
-- Name: COLUMN ml_feature_engineering.created_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_feature_engineering.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "ml_models.COLUMN ml_feature_engineering.updated_at"
--
-- TOC entry 4698 (class 0 OID 0)
-- Dependencies: 249
-- Name: COLUMN ml_feature_engineering.updated_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_feature_engineering.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "ml_models.ml_features"
--
-- TOC entry 232 (class 1259 OID 21603)
-- Name: ml_features; Type: TABLE; Schema: ml_models; Owner: postgres
--

CREATE TABLE ml_models.ml_features (
    feature_name character varying(255) NOT NULL,
    feature_category character varying(100),
    description text,
    data_type character varying(50) NOT NULL,
    calculation_method text,
    is_active boolean NOT NULL,
    average_importance numeric(5,4),
    feature_metadata jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ml_models.ml_features OWNER TO postgres;

pg_dump: creating COMMENT "ml_models.TABLE ml_features"
--
-- TOC entry 4699 (class 0 OID 0)
-- Dependencies: 232
-- Name: TABLE ml_features; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON TABLE ml_models.ml_features IS 'ML feature definitions';


pg_dump: creating COMMENT "ml_models.COLUMN ml_features.feature_category"
--
-- TOC entry 4700 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN ml_features.feature_category; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_features.feature_category IS 'team_stats, player_stats, historical, etc.';


pg_dump: creating COMMENT "ml_models.COLUMN ml_features.data_type"
--
-- TOC entry 4701 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN ml_features.data_type; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_features.data_type IS 'numeric, categorical, boolean';


pg_dump: creating COMMENT "ml_models.COLUMN ml_features.calculation_method"
--
-- TOC entry 4702 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN ml_features.calculation_method; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_features.calculation_method IS 'How feature is calculated';


pg_dump: creating COMMENT "ml_models.COLUMN ml_features.id"
--
-- TOC entry 4703 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN ml_features.id; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_features.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "ml_models.COLUMN ml_features.created_at"
--
-- TOC entry 4704 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN ml_features.created_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_features.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "ml_models.COLUMN ml_features.updated_at"
--
-- TOC entry 4705 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN ml_features.updated_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_features.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "ml_models.ml_model_deployments"
--
-- TOC entry 278 (class 1259 OID 22553)
-- Name: ml_model_deployments; Type: TABLE; Schema: ml_models; Owner: postgres
--

CREATE TABLE ml_models.ml_model_deployments (
    model_id uuid NOT NULL,
    model_version_id uuid NOT NULL,
    deployment_environment character varying(50) NOT NULL,
    status users.deploymentstatus NOT NULL,
    deployed_at timestamp without time zone NOT NULL,
    deactivated_at timestamp without time zone,
    deployment_config jsonb,
    deployed_by_user_id uuid,
    rollback_reason text,
    rolled_back_at timestamp without time zone,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ml_models.ml_model_deployments OWNER TO postgres;

pg_dump: creating COMMENT "ml_models.TABLE ml_model_deployments"
--
-- TOC entry 4706 (class 0 OID 0)
-- Dependencies: 278
-- Name: TABLE ml_model_deployments; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON TABLE ml_models.ml_model_deployments IS 'ML model deployments';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_deployments.deployment_environment"
--
-- TOC entry 4707 (class 0 OID 0)
-- Dependencies: 278
-- Name: COLUMN ml_model_deployments.deployment_environment; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_deployments.deployment_environment IS 'staging, production';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_deployments.id"
--
-- TOC entry 4708 (class 0 OID 0)
-- Dependencies: 278
-- Name: COLUMN ml_model_deployments.id; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_deployments.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_deployments.created_at"
--
-- TOC entry 4709 (class 0 OID 0)
-- Dependencies: 278
-- Name: COLUMN ml_model_deployments.created_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_deployments.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_deployments.updated_at"
--
-- TOC entry 4710 (class 0 OID 0)
-- Dependencies: 278
-- Name: COLUMN ml_model_deployments.updated_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_deployments.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "ml_models.ml_model_metadata"
--
-- TOC entry 268 (class 1259 OID 22375)
-- Name: ml_model_metadata; Type: TABLE; Schema: ml_models; Owner: postgres
--

CREATE TABLE ml_models.ml_model_metadata (
    model_id uuid NOT NULL,
    metadata_key character varying(255) NOT NULL,
    metadata_value jsonb NOT NULL,
    description text,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ml_models.ml_model_metadata OWNER TO postgres;

pg_dump: creating COMMENT "ml_models.TABLE ml_model_metadata"
--
-- TOC entry 4711 (class 0 OID 0)
-- Dependencies: 268
-- Name: TABLE ml_model_metadata; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON TABLE ml_models.ml_model_metadata IS 'ML model metadata';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_metadata.id"
--
-- TOC entry 4712 (class 0 OID 0)
-- Dependencies: 268
-- Name: COLUMN ml_model_metadata.id; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_metadata.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_metadata.created_at"
--
-- TOC entry 4713 (class 0 OID 0)
-- Dependencies: 268
-- Name: COLUMN ml_model_metadata.created_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_metadata.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_metadata.updated_at"
--
-- TOC entry 4714 (class 0 OID 0)
-- Dependencies: 268
-- Name: COLUMN ml_model_metadata.updated_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_metadata.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "ml_models.ml_model_performance"
--
-- TOC entry 279 (class 1259 OID 22578)
-- Name: ml_model_performance; Type: TABLE; Schema: ml_models; Owner: postgres
--

CREATE TABLE ml_models.ml_model_performance (
    model_id uuid NOT NULL,
    model_version_id uuid,
    evaluation_date timestamp without time zone NOT NULL,
    evaluation_period character varying(50),
    accuracy numeric(5,4),
    "precision" numeric(5,4),
    recall numeric(5,4),
    f1_score numeric(5,4),
    auc_roc numeric(5,4),
    confidence_calibration numeric(5,4),
    brier_score numeric(5,4),
    total_predictions integer NOT NULL,
    correct_predictions integer NOT NULL,
    detailed_metrics jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ml_models.ml_model_performance OWNER TO postgres;

pg_dump: creating COMMENT "ml_models.TABLE ml_model_performance"
--
-- TOC entry 4715 (class 0 OID 0)
-- Dependencies: 279
-- Name: TABLE ml_model_performance; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON TABLE ml_models.ml_model_performance IS 'ML model performance';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_performance.evaluation_period"
--
-- TOC entry 4716 (class 0 OID 0)
-- Dependencies: 279
-- Name: COLUMN ml_model_performance.evaluation_period; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_performance.evaluation_period IS 'daily, weekly, monthly';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_performance.detailed_metrics"
--
-- TOC entry 4717 (class 0 OID 0)
-- Dependencies: 279
-- Name: COLUMN ml_model_performance.detailed_metrics; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_performance.detailed_metrics IS 'Additional metrics';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_performance.id"
--
-- TOC entry 4718 (class 0 OID 0)
-- Dependencies: 279
-- Name: COLUMN ml_model_performance.id; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_performance.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_performance.created_at"
--
-- TOC entry 4719 (class 0 OID 0)
-- Dependencies: 279
-- Name: COLUMN ml_model_performance.created_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_performance.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_performance.updated_at"
--
-- TOC entry 4720 (class 0 OID 0)
-- Dependencies: 279
-- Name: COLUMN ml_model_performance.updated_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_performance.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "ml_models.ml_model_versions"
--
-- TOC entry 269 (class 1259 OID 22389)
-- Name: ml_model_versions; Type: TABLE; Schema: ml_models; Owner: postgres
--

CREATE TABLE ml_models.ml_model_versions (
    model_id uuid NOT NULL,
    version character varying(50) NOT NULL,
    version_notes text,
    parameters jsonb NOT NULL,
    model_artifact_path character varying(500) NOT NULL,
    training_data_hash character varying(255),
    training_data_size integer,
    is_production boolean NOT NULL,
    deployed_at timestamp without time zone,
    deprecated_at timestamp without time zone,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ml_models.ml_model_versions OWNER TO postgres;

pg_dump: creating COMMENT "ml_models.TABLE ml_model_versions"
--
-- TOC entry 4721 (class 0 OID 0)
-- Dependencies: 269
-- Name: TABLE ml_model_versions; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON TABLE ml_models.ml_model_versions IS 'ML model versions';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_versions.training_data_hash"
--
-- TOC entry 4722 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN ml_model_versions.training_data_hash; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_versions.training_data_hash IS 'Hash of training data';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_versions.id"
--
-- TOC entry 4723 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN ml_model_versions.id; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_versions.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_versions.created_at"
--
-- TOC entry 4724 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN ml_model_versions.created_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_versions.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "ml_models.COLUMN ml_model_versions.updated_at"
--
-- TOC entry 4725 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN ml_model_versions.updated_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_model_versions.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "ml_models.ml_models"
--
-- TOC entry 250 (class 1259 OID 21985)
-- Name: ml_models; Type: TABLE; Schema: ml_models; Owner: postgres
--

CREATE TABLE ml_models.ml_models (
    model_name character varying(255) NOT NULL,
    model_version character varying(50) NOT NULL,
    model_type users.modeltype NOT NULL,
    description text,
    model_status users.modelstatus NOT NULL,
    is_champion boolean NOT NULL,
    is_deployed boolean NOT NULL,
    framework character varying(50),
    framework_version character varying(50),
    hyperparameters jsonb,
    s3_model_path character varying(500),
    s3_checkpoint_path character varying(500),
    model_size_bytes bigint,
    training_accuracy numeric(5,4),
    validation_accuracy numeric(5,4),
    test_accuracy numeric(5,4),
    created_by_user_id uuid,
    model_metadata jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ml_models.ml_models OWNER TO postgres;

pg_dump: creating COMMENT "ml_models.TABLE ml_models"
--
-- TOC entry 4726 (class 0 OID 0)
-- Dependencies: 250
-- Name: TABLE ml_models; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON TABLE ml_models.ml_models IS 'ML model registry';


pg_dump: creating COMMENT "ml_models.COLUMN ml_models.model_version"
--
-- TOC entry 4727 (class 0 OID 0)
-- Dependencies: 250
-- Name: COLUMN ml_models.model_version; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_models.model_version IS 'Semantic version';


pg_dump: creating COMMENT "ml_models.COLUMN ml_models.is_champion"
--
-- TOC entry 4728 (class 0 OID 0)
-- Dependencies: 250
-- Name: COLUMN ml_models.is_champion; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_models.is_champion IS 'Best performing model';


pg_dump: creating COMMENT "ml_models.COLUMN ml_models.framework"
--
-- TOC entry 4729 (class 0 OID 0)
-- Dependencies: 250
-- Name: COLUMN ml_models.framework; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_models.framework IS 'scikit-learn, tensorflow, pytorch';


pg_dump: creating COMMENT "ml_models.COLUMN ml_models.hyperparameters"
--
-- TOC entry 4730 (class 0 OID 0)
-- Dependencies: 250
-- Name: COLUMN ml_models.hyperparameters; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_models.hyperparameters IS 'Model hyperparameters';


pg_dump: creating COMMENT "ml_models.COLUMN ml_models.s3_model_path"
--
-- TOC entry 4731 (class 0 OID 0)
-- Dependencies: 250
-- Name: COLUMN ml_models.s3_model_path; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_models.s3_model_path IS 'S3 path to model artifact';


pg_dump: creating COMMENT "ml_models.COLUMN ml_models.id"
--
-- TOC entry 4732 (class 0 OID 0)
-- Dependencies: 250
-- Name: COLUMN ml_models.id; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_models.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "ml_models.COLUMN ml_models.created_at"
--
-- TOC entry 4733 (class 0 OID 0)
-- Dependencies: 250
-- Name: COLUMN ml_models.created_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_models.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "ml_models.COLUMN ml_models.updated_at"
--
-- TOC entry 4734 (class 0 OID 0)
-- Dependencies: 250
-- Name: COLUMN ml_models.updated_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_models.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "ml_models.ml_predictions"
--
-- TOC entry 270 (class 1259 OID 22406)
-- Name: ml_predictions; Type: TABLE; Schema: ml_models; Owner: postgres
--

CREATE TABLE ml_models.ml_predictions (
    model_id uuid NOT NULL,
    match_id uuid NOT NULL,
    home_win_prob numeric(5,4) NOT NULL,
    draw_prob numeric(5,4) NOT NULL,
    away_win_prob numeric(5,4) NOT NULL,
    confidence_score numeric(5,4) NOT NULL,
    prediction_quality_score numeric(5,4),
    features_used jsonb,
    feature_importance jsonb,
    was_overridden boolean NOT NULL,
    overridden_by_expert_id uuid,
    override_reason text,
    model_version character varying(50),
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ml_models.ml_predictions OWNER TO postgres;

pg_dump: creating COMMENT "ml_models.TABLE ml_predictions"
--
-- TOC entry 4735 (class 0 OID 0)
-- Dependencies: 270
-- Name: TABLE ml_predictions; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON TABLE ml_models.ml_predictions IS 'Raw ML predictions';


pg_dump: creating COMMENT "ml_models.COLUMN ml_predictions.features_used"
--
-- TOC entry 4736 (class 0 OID 0)
-- Dependencies: 270
-- Name: COLUMN ml_predictions.features_used; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_predictions.features_used IS 'Features used for prediction';


pg_dump: creating COMMENT "ml_models.COLUMN ml_predictions.feature_importance"
--
-- TOC entry 4737 (class 0 OID 0)
-- Dependencies: 270
-- Name: COLUMN ml_predictions.feature_importance; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_predictions.feature_importance IS 'Feature importance scores';


pg_dump: creating COMMENT "ml_models.COLUMN ml_predictions.id"
--
-- TOC entry 4738 (class 0 OID 0)
-- Dependencies: 270
-- Name: COLUMN ml_predictions.id; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_predictions.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "ml_models.COLUMN ml_predictions.created_at"
--
-- TOC entry 4739 (class 0 OID 0)
-- Dependencies: 270
-- Name: COLUMN ml_predictions.created_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_predictions.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "ml_models.COLUMN ml_predictions.updated_at"
--
-- TOC entry 4740 (class 0 OID 0)
-- Dependencies: 270
-- Name: COLUMN ml_predictions.updated_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_predictions.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "ml_models.ml_training_runs"
--
-- TOC entry 280 (class 1259 OID 22609)
-- Name: ml_training_runs; Type: TABLE; Schema: ml_models; Owner: postgres
--

CREATE TABLE ml_models.ml_training_runs (
    model_id uuid NOT NULL,
    model_version_id uuid,
    training_job_id character varying(255),
    status users.trainingstatus NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    duration_seconds integer,
    training_parameters jsonb NOT NULL,
    training_data_size integer,
    validation_data_size integer,
    test_data_size integer,
    final_metrics jsonb,
    best_epoch integer,
    total_epochs integer,
    error_message text,
    error_traceback text,
    triggered_by_user_id uuid,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ml_models.ml_training_runs OWNER TO postgres;

pg_dump: creating COMMENT "ml_models.TABLE ml_training_runs"
--
-- TOC entry 4741 (class 0 OID 0)
-- Dependencies: 280
-- Name: TABLE ml_training_runs; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON TABLE ml_models.ml_training_runs IS 'ML training runs';


pg_dump: creating COMMENT "ml_models.COLUMN ml_training_runs.final_metrics"
--
-- TOC entry 4742 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN ml_training_runs.final_metrics; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_training_runs.final_metrics IS 'Final training metrics';


pg_dump: creating COMMENT "ml_models.COLUMN ml_training_runs.id"
--
-- TOC entry 4743 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN ml_training_runs.id; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_training_runs.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "ml_models.COLUMN ml_training_runs.created_at"
--
-- TOC entry 4744 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN ml_training_runs.created_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_training_runs.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "ml_models.COLUMN ml_training_runs.updated_at"
--
-- TOC entry 4745 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN ml_training_runs.updated_at; Type: COMMENT; Schema: ml_models; Owner: postgres
--

COMMENT ON COLUMN ml_models.ml_training_runs.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.leagues"
--
-- TOC entry 233 (class 1259 OID 21615)
-- Name: leagues; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.leagues (
    name character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    country character varying(100) NOT NULL,
    country_code character varying(3),
    logo_url character varying(500),
    tier integer,
    external_api_id character varying(100),
    external_api_source character varying(50),
    is_active boolean NOT NULL,
    league_metadata jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.leagues OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE leagues"
--
-- TOC entry 4746 (class 0 OID 0)
-- Dependencies: 233
-- Name: TABLE leagues; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.leagues IS 'League reference data';


pg_dump: creating COMMENT "predictions.COLUMN leagues.tier"
--
-- TOC entry 4747 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN leagues.tier; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.leagues.tier IS 'League tier/division';


pg_dump: creating COMMENT "predictions.COLUMN leagues.id"
--
-- TOC entry 4748 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN leagues.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.leagues.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN leagues.created_at"
--
-- TOC entry 4749 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN leagues.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.leagues.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN leagues.updated_at"
--
-- TOC entry 4750 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN leagues.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.leagues.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.match_results"
--
-- TOC entry 271 (class 1259 OID 22432)
-- Name: match_results; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.match_results (
    match_id uuid NOT NULL,
    home_score integer NOT NULL,
    away_score integer NOT NULL,
    home_score_ht integer,
    away_score_ht integer,
    result character varying(10),
    home_corners integer,
    away_corners integer,
    home_yellow_cards integer,
    away_yellow_cards integer,
    home_red_cards integer,
    away_red_cards integer,
    result_metadata jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.match_results OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE match_results"
--
-- TOC entry 4751 (class 0 OID 0)
-- Dependencies: 271
-- Name: TABLE match_results; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.match_results IS 'Match results';


pg_dump: creating COMMENT "predictions.COLUMN match_results.result"
--
-- TOC entry 4752 (class 0 OID 0)
-- Dependencies: 271
-- Name: COLUMN match_results.result; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.match_results.result IS 'H, D, A';


pg_dump: creating COMMENT "predictions.COLUMN match_results.result_metadata"
--
-- TOC entry 4753 (class 0 OID 0)
-- Dependencies: 271
-- Name: COLUMN match_results.result_metadata; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.match_results.result_metadata IS 'Additional result data';


pg_dump: creating COMMENT "predictions.COLUMN match_results.id"
--
-- TOC entry 4754 (class 0 OID 0)
-- Dependencies: 271
-- Name: COLUMN match_results.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.match_results.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN match_results.created_at"
--
-- TOC entry 4755 (class 0 OID 0)
-- Dependencies: 271
-- Name: COLUMN match_results.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.match_results.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN match_results.updated_at"
--
-- TOC entry 4756 (class 0 OID 0)
-- Dependencies: 271
-- Name: COLUMN match_results.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.match_results.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.match_statistics"
--
-- TOC entry 272 (class 1259 OID 22447)
-- Name: match_statistics; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.match_statistics (
    match_id uuid NOT NULL,
    stat_type character varying(50) NOT NULL,
    stat_category character varying(50),
    home_value numeric(10,2),
    away_value numeric(10,2),
    stat_metadata jsonb,
    recorded_at timestamp without time zone NOT NULL,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.match_statistics OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE match_statistics"
--
-- TOC entry 4757 (class 0 OID 0)
-- Dependencies: 272
-- Name: TABLE match_statistics; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.match_statistics IS 'Match statistics';


pg_dump: creating COMMENT "predictions.COLUMN match_statistics.stat_type"
--
-- TOC entry 4758 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN match_statistics.stat_type; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.match_statistics.stat_type IS 'pre_match, live, post_match';


pg_dump: creating COMMENT "predictions.COLUMN match_statistics.stat_category"
--
-- TOC entry 4759 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN match_statistics.stat_category; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.match_statistics.stat_category IS 'possession, shots, passes, etc.';


pg_dump: creating COMMENT "predictions.COLUMN match_statistics.id"
--
-- TOC entry 4760 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN match_statistics.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.match_statistics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN match_statistics.created_at"
--
-- TOC entry 4761 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN match_statistics.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.match_statistics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN match_statistics.updated_at"
--
-- TOC entry 4762 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN match_statistics.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.match_statistics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.matches"
--
-- TOC entry 251 (class 1259 OID 22013)
-- Name: matches; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.matches (
    home_team_id uuid NOT NULL,
    away_team_id uuid NOT NULL,
    league_id uuid NOT NULL,
    match_date timestamp without time zone NOT NULL,
    venue character varying(255),
    season character varying(20),
    round character varying(50),
    status users.matchstatus NOT NULL,
    external_api_id character varying(100),
    external_api_source character varying(50),
    match_metadata jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.matches OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE matches"
--
-- TOC entry 4763 (class 0 OID 0)
-- Dependencies: 251
-- Name: TABLE matches; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.matches IS 'Match information';


pg_dump: creating COMMENT "predictions.COLUMN matches.season"
--
-- TOC entry 4764 (class 0 OID 0)
-- Dependencies: 251
-- Name: COLUMN matches.season; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.matches.season IS 'e.g., ''2023-24''';


pg_dump: creating COMMENT "predictions.COLUMN matches.round"
--
-- TOC entry 4765 (class 0 OID 0)
-- Dependencies: 251
-- Name: COLUMN matches.round; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.matches.round IS 'e.g., ''Matchday 15''';


pg_dump: creating COMMENT "predictions.COLUMN matches.external_api_id"
--
-- TOC entry 4766 (class 0 OID 0)
-- Dependencies: 251
-- Name: COLUMN matches.external_api_id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.matches.external_api_id IS 'External API match ID';


pg_dump: creating COMMENT "predictions.COLUMN matches.external_api_source"
--
-- TOC entry 4767 (class 0 OID 0)
-- Dependencies: 251
-- Name: COLUMN matches.external_api_source; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.matches.external_api_source IS 'API source name';


pg_dump: creating COMMENT "predictions.COLUMN matches.match_metadata"
--
-- TOC entry 4768 (class 0 OID 0)
-- Dependencies: 251
-- Name: COLUMN matches.match_metadata; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.matches.match_metadata IS 'Additional match data';


pg_dump: creating COMMENT "predictions.COLUMN matches.id"
--
-- TOC entry 4769 (class 0 OID 0)
-- Dependencies: 251
-- Name: COLUMN matches.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.matches.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN matches.created_at"
--
-- TOC entry 4770 (class 0 OID 0)
-- Dependencies: 251
-- Name: COLUMN matches.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.matches.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN matches.updated_at"
--
-- TOC entry 4771 (class 0 OID 0)
-- Dependencies: 251
-- Name: COLUMN matches.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.matches.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.prediction_analytics"
--
-- TOC entry 283 (class 1259 OID 22720)
-- Name: prediction_analytics; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.prediction_analytics (
    prediction_id uuid NOT NULL,
    view_count integer NOT NULL,
    unique_viewers integer NOT NULL,
    share_count integer NOT NULL,
    comment_count integer NOT NULL,
    upvote_count integer NOT NULL,
    downvote_count integer NOT NULL,
    average_rating numeric(3,2),
    total_ratings integer NOT NULL,
    accuracy_score numeric(5,4),
    roi_percentage numeric(10,2),
    engagement_score numeric(10,2),
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.prediction_analytics OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE prediction_analytics"
--
-- TOC entry 4772 (class 0 OID 0)
-- Dependencies: 283
-- Name: TABLE prediction_analytics; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.prediction_analytics IS 'Prediction analytics';


pg_dump: creating COMMENT "predictions.COLUMN prediction_analytics.engagement_score"
--
-- TOC entry 4773 (class 0 OID 0)
-- Dependencies: 283
-- Name: COLUMN prediction_analytics.engagement_score; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_analytics.engagement_score IS 'Composite engagement metric';


pg_dump: creating COMMENT "predictions.COLUMN prediction_analytics.id"
--
-- TOC entry 4774 (class 0 OID 0)
-- Dependencies: 283
-- Name: COLUMN prediction_analytics.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_analytics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN prediction_analytics.created_at"
--
-- TOC entry 4775 (class 0 OID 0)
-- Dependencies: 283
-- Name: COLUMN prediction_analytics.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_analytics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN prediction_analytics.updated_at"
--
-- TOC entry 4776 (class 0 OID 0)
-- Dependencies: 283
-- Name: COLUMN prediction_analytics.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_analytics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.prediction_audit"
--
-- TOC entry 284 (class 1259 OID 22733)
-- Name: prediction_audit; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.prediction_audit (
    prediction_id uuid NOT NULL,
    user_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    action_description text,
    old_values jsonb,
    new_values jsonb,
    changes_summary text,
    ip_address character varying(45),
    user_agent text,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.prediction_audit OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE prediction_audit"
--
-- TOC entry 4777 (class 0 OID 0)
-- Dependencies: 284
-- Name: TABLE prediction_audit; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.prediction_audit IS 'Prediction audit trail';


pg_dump: creating COMMENT "predictions.COLUMN prediction_audit.action"
--
-- TOC entry 4778 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN prediction_audit.action; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_audit.action IS 'created, updated, approved, published, etc.';


pg_dump: creating COMMENT "predictions.COLUMN prediction_audit.old_values"
--
-- TOC entry 4779 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN prediction_audit.old_values; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_audit.old_values IS 'Previous values';


pg_dump: creating COMMENT "predictions.COLUMN prediction_audit.new_values"
--
-- TOC entry 4780 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN prediction_audit.new_values; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_audit.new_values IS 'New values';


pg_dump: creating COMMENT "predictions.COLUMN prediction_audit.changes_summary"
--
-- TOC entry 4781 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN prediction_audit.changes_summary; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_audit.changes_summary IS 'Human-readable summary';


pg_dump: creating COMMENT "predictions.COLUMN prediction_audit.id"
--
-- TOC entry 4782 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN prediction_audit.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_audit.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN prediction_audit.created_at"
--
-- TOC entry 4783 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN prediction_audit.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_audit.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN prediction_audit.updated_at"
--
-- TOC entry 4784 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN prediction_audit.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_audit.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.prediction_comments"
--
-- TOC entry 285 (class 1259 OID 22754)
-- Name: prediction_comments; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.prediction_comments (
    prediction_id uuid NOT NULL,
    user_id uuid NOT NULL,
    parent_comment_id uuid,
    comment_text text NOT NULL,
    is_flagged boolean NOT NULL,
    is_approved boolean NOT NULL,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


ALTER TABLE predictions.prediction_comments OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE prediction_comments"
--
-- TOC entry 4785 (class 0 OID 0)
-- Dependencies: 285
-- Name: TABLE prediction_comments; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.prediction_comments IS 'Prediction comments';


pg_dump: creating COMMENT "predictions.COLUMN prediction_comments.parent_comment_id"
--
-- TOC entry 4786 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN prediction_comments.parent_comment_id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_comments.parent_comment_id IS 'For nested comments';


pg_dump: creating COMMENT "predictions.COLUMN prediction_comments.id"
--
-- TOC entry 4787 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN prediction_comments.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_comments.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN prediction_comments.created_at"
--
-- TOC entry 4788 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN prediction_comments.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_comments.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN prediction_comments.updated_at"
--
-- TOC entry 4789 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN prediction_comments.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_comments.updated_at IS 'Record last update timestamp';


pg_dump: creating COMMENT "predictions.COLUMN prediction_comments.deleted_at"
--
-- TOC entry 4790 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN prediction_comments.deleted_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_comments.deleted_at IS 'Soft delete timestamp';


pg_dump: creating TABLE "predictions.prediction_markets"
--
-- TOC entry 286 (class 1259 OID 22791)
-- Name: prediction_markets; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.prediction_markets (
    prediction_id uuid NOT NULL,
    market_type users.markettype NOT NULL,
    market_value character varying(50),
    predicted_outcome character varying(50) NOT NULL,
    probability numeric(5,4) NOT NULL,
    confidence numeric(5,4) NOT NULL,
    recommended_odds numeric(6,2),
    market_odds numeric(6,2),
    is_primary boolean,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.prediction_markets OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE prediction_markets"
--
-- TOC entry 4791 (class 0 OID 0)
-- Dependencies: 286
-- Name: TABLE prediction_markets; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.prediction_markets IS 'Prediction markets';


pg_dump: creating COMMENT "predictions.COLUMN prediction_markets.market_value"
--
-- TOC entry 4792 (class 0 OID 0)
-- Dependencies: 286
-- Name: COLUMN prediction_markets.market_value; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_markets.market_value IS 'e.g., ''Over 2.5'', ''BTTS Yes''';


pg_dump: creating COMMENT "predictions.COLUMN prediction_markets.is_primary"
--
-- TOC entry 4793 (class 0 OID 0)
-- Dependencies: 286
-- Name: COLUMN prediction_markets.is_primary; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_markets.is_primary IS 'Primary market for this prediction';


pg_dump: creating COMMENT "predictions.COLUMN prediction_markets.id"
--
-- TOC entry 4794 (class 0 OID 0)
-- Dependencies: 286
-- Name: COLUMN prediction_markets.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_markets.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN prediction_markets.created_at"
--
-- TOC entry 4795 (class 0 OID 0)
-- Dependencies: 286
-- Name: COLUMN prediction_markets.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_markets.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN prediction_markets.updated_at"
--
-- TOC entry 4796 (class 0 OID 0)
-- Dependencies: 286
-- Name: COLUMN prediction_markets.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_markets.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.prediction_overrides"
--
-- TOC entry 287 (class 1259 OID 22803)
-- Name: prediction_overrides; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.prediction_overrides (
    prediction_id uuid NOT NULL,
    expert_user_id uuid NOT NULL,
    expert_profile_id uuid NOT NULL,
    original_ml_prediction_id uuid,
    original_probabilities jsonb NOT NULL,
    original_confidence numeric(5,4),
    new_probabilities jsonb NOT NULL,
    new_confidence numeric(5,4) NOT NULL,
    override_reason text NOT NULL,
    confidence_adjustment numeric(6,4),
    key_insights jsonb,
    reviewed_by_admin_id uuid,
    reviewed_at timestamp without time zone,
    review_notes text,
    is_approved boolean,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.prediction_overrides OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE prediction_overrides"
--
-- TOC entry 4797 (class 0 OID 0)
-- Dependencies: 287
-- Name: TABLE prediction_overrides; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.prediction_overrides IS 'Prediction overrides';


pg_dump: creating COMMENT "predictions.COLUMN prediction_overrides.original_probabilities"
--
-- TOC entry 4798 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN prediction_overrides.original_probabilities; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_overrides.original_probabilities IS 'Original ML probabilities';


pg_dump: creating COMMENT "predictions.COLUMN prediction_overrides.original_confidence"
--
-- TOC entry 4799 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN prediction_overrides.original_confidence; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_overrides.original_confidence IS 'Original ML confidence';


pg_dump: creating COMMENT "predictions.COLUMN prediction_overrides.new_probabilities"
--
-- TOC entry 4800 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN prediction_overrides.new_probabilities; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_overrides.new_probabilities IS 'Expert-adjusted probabilities';


pg_dump: creating COMMENT "predictions.COLUMN prediction_overrides.new_confidence"
--
-- TOC entry 4801 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN prediction_overrides.new_confidence; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_overrides.new_confidence IS 'Expert confidence';


pg_dump: creating COMMENT "predictions.COLUMN prediction_overrides.override_reason"
--
-- TOC entry 4802 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN prediction_overrides.override_reason; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_overrides.override_reason IS 'Reason for override';


pg_dump: creating COMMENT "predictions.COLUMN prediction_overrides.confidence_adjustment"
--
-- TOC entry 4803 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN prediction_overrides.confidence_adjustment; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_overrides.confidence_adjustment IS 'Confidence change';


pg_dump: creating COMMENT "predictions.COLUMN prediction_overrides.key_insights"
--
-- TOC entry 4804 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN prediction_overrides.key_insights; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_overrides.key_insights IS 'Expert insights';


pg_dump: creating COMMENT "predictions.COLUMN prediction_overrides.id"
--
-- TOC entry 4805 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN prediction_overrides.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_overrides.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN prediction_overrides.created_at"
--
-- TOC entry 4806 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN prediction_overrides.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_overrides.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN prediction_overrides.updated_at"
--
-- TOC entry 4807 (class 0 OID 0)
-- Dependencies: 287
-- Name: COLUMN prediction_overrides.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_overrides.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.prediction_results"
--
-- TOC entry 288 (class 1259 OID 22851)
-- Name: prediction_results; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.prediction_results (
    prediction_id uuid NOT NULL,
    match_result_id uuid NOT NULL,
    outcome users.predictionoutcome NOT NULL,
    is_correct boolean,
    probability_accuracy numeric(5,4),
    confidence_calibration numeric(5,4),
    potential_return numeric(10,2),
    actual_return numeric(10,2),
    roi_percentage numeric(10,2),
    settled_at timestamp without time zone NOT NULL,
    settled_by_system boolean,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.prediction_results OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE prediction_results"
--
-- TOC entry 4808 (class 0 OID 0)
-- Dependencies: 288
-- Name: TABLE prediction_results; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.prediction_results IS 'Prediction results';


pg_dump: creating COMMENT "predictions.COLUMN prediction_results.is_correct"
--
-- TOC entry 4809 (class 0 OID 0)
-- Dependencies: 288
-- Name: COLUMN prediction_results.is_correct; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_results.is_correct IS 'Was prediction correct';


pg_dump: creating COMMENT "predictions.COLUMN prediction_results.probability_accuracy"
--
-- TOC entry 4810 (class 0 OID 0)
-- Dependencies: 288
-- Name: COLUMN prediction_results.probability_accuracy; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_results.probability_accuracy IS 'How close probabilities were';


pg_dump: creating COMMENT "predictions.COLUMN prediction_results.confidence_calibration"
--
-- TOC entry 4811 (class 0 OID 0)
-- Dependencies: 288
-- Name: COLUMN prediction_results.confidence_calibration; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_results.confidence_calibration IS 'Confidence vs actual';


pg_dump: creating COMMENT "predictions.COLUMN prediction_results.id"
--
-- TOC entry 4812 (class 0 OID 0)
-- Dependencies: 288
-- Name: COLUMN prediction_results.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_results.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN prediction_results.created_at"
--
-- TOC entry 4813 (class 0 OID 0)
-- Dependencies: 288
-- Name: COLUMN prediction_results.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_results.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN prediction_results.updated_at"
--
-- TOC entry 4814 (class 0 OID 0)
-- Dependencies: 288
-- Name: COLUMN prediction_results.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_results.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.prediction_shares"
--
-- TOC entry 289 (class 1259 OID 22871)
-- Name: prediction_shares; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.prediction_shares (
    prediction_id uuid NOT NULL,
    user_id uuid,
    platform character varying(50) NOT NULL,
    share_url character varying(500),
    ip_address character varying(45),
    user_agent text,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.prediction_shares OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE prediction_shares"
--
-- TOC entry 4815 (class 0 OID 0)
-- Dependencies: 289
-- Name: TABLE prediction_shares; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.prediction_shares IS 'Prediction shares';


pg_dump: creating COMMENT "predictions.COLUMN prediction_shares.platform"
--
-- TOC entry 4816 (class 0 OID 0)
-- Dependencies: 289
-- Name: COLUMN prediction_shares.platform; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_shares.platform IS 'twitter, facebook, whatsapp, etc.';


pg_dump: creating COMMENT "predictions.COLUMN prediction_shares.id"
--
-- TOC entry 4817 (class 0 OID 0)
-- Dependencies: 289
-- Name: COLUMN prediction_shares.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_shares.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN prediction_shares.created_at"
--
-- TOC entry 4818 (class 0 OID 0)
-- Dependencies: 289
-- Name: COLUMN prediction_shares.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_shares.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN prediction_shares.updated_at"
--
-- TOC entry 4819 (class 0 OID 0)
-- Dependencies: 289
-- Name: COLUMN prediction_shares.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_shares.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.prediction_templates"
--
-- TOC entry 252 (class 1259 OID 22043)
-- Name: prediction_templates; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.prediction_templates (
    name character varying(255) NOT NULL,
    description text,
    created_by uuid NOT NULL,
    template_data jsonb NOT NULL,
    is_active boolean NOT NULL,
    is_public boolean NOT NULL,
    usage_count integer NOT NULL,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.prediction_templates OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE prediction_templates"
--
-- TOC entry 4820 (class 0 OID 0)
-- Dependencies: 252
-- Name: TABLE prediction_templates; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.prediction_templates IS 'Prediction templates';


pg_dump: creating COMMENT "predictions.COLUMN prediction_templates.template_data"
--
-- TOC entry 4821 (class 0 OID 0)
-- Dependencies: 252
-- Name: COLUMN prediction_templates.template_data; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_templates.template_data IS 'Template configuration';


pg_dump: creating COMMENT "predictions.COLUMN prediction_templates.id"
--
-- TOC entry 4822 (class 0 OID 0)
-- Dependencies: 252
-- Name: COLUMN prediction_templates.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_templates.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN prediction_templates.created_at"
--
-- TOC entry 4823 (class 0 OID 0)
-- Dependencies: 252
-- Name: COLUMN prediction_templates.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_templates.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN prediction_templates.updated_at"
--
-- TOC entry 4824 (class 0 OID 0)
-- Dependencies: 252
-- Name: COLUMN prediction_templates.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.prediction_templates.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.predictions"
--
-- TOC entry 281 (class 1259 OID 22659)
-- Name: predictions; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.predictions (
    match_id uuid NOT NULL,
    source users.predictionsource NOT NULL,
    created_by uuid NOT NULL,
    ml_prediction_id uuid,
    expert_profile_id uuid,
    home_win_prob numeric(5,4) NOT NULL,
    draw_prob numeric(5,4) NOT NULL,
    away_win_prob numeric(5,4) NOT NULL,
    confidence_score numeric(5,4) NOT NULL,
    reasoning text,
    key_factors jsonb,
    status users.predictionstatus NOT NULL,
    approved_by uuid,
    approved_at timestamp without time zone,
    published_at timestamp without time zone,
    prediction_metadata jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone,
    CONSTRAINT ck_predictions_confidence CHECK (((confidence_score >= (0)::numeric) AND (confidence_score <= (1)::numeric))),
    CONSTRAINT ck_predictions_prob_sum CHECK ((((home_win_prob + draw_prob) + away_win_prob) = 1.0))
);


ALTER TABLE predictions.predictions OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE predictions"
--
-- TOC entry 4825 (class 0 OID 0)
-- Dependencies: 281
-- Name: TABLE predictions; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.predictions IS 'Core predictions';


pg_dump: creating COMMENT "predictions.COLUMN predictions.source"
--
-- TOC entry 4826 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.source; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.source IS 'Prediction source';


pg_dump: creating COMMENT "predictions.COLUMN predictions.created_by"
--
-- TOC entry 4827 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.created_by; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.created_by IS 'User who created prediction';


pg_dump: creating COMMENT "predictions.COLUMN predictions.ml_prediction_id"
--
-- TOC entry 4828 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.ml_prediction_id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.ml_prediction_id IS 'Original ML prediction';


pg_dump: creating COMMENT "predictions.COLUMN predictions.expert_profile_id"
--
-- TOC entry 4829 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.expert_profile_id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.expert_profile_id IS 'Expert who created/modified';


pg_dump: creating COMMENT "predictions.COLUMN predictions.home_win_prob"
--
-- TOC entry 4830 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.home_win_prob; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.home_win_prob IS 'Home win probability';


pg_dump: creating COMMENT "predictions.COLUMN predictions.draw_prob"
--
-- TOC entry 4831 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.draw_prob; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.draw_prob IS 'Draw probability';


pg_dump: creating COMMENT "predictions.COLUMN predictions.away_win_prob"
--
-- TOC entry 4832 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.away_win_prob; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.away_win_prob IS 'Away win probability';


pg_dump: creating COMMENT "predictions.COLUMN predictions.confidence_score"
--
-- TOC entry 4833 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.confidence_score; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.confidence_score IS 'Confidence score 0-1';


pg_dump: creating COMMENT "predictions.COLUMN predictions.reasoning"
--
-- TOC entry 4834 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.reasoning; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.reasoning IS 'Prediction reasoning/explanation';


pg_dump: creating COMMENT "predictions.COLUMN predictions.key_factors"
--
-- TOC entry 4835 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.key_factors; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.key_factors IS 'Key factors influencing prediction';


pg_dump: creating COMMENT "predictions.COLUMN predictions.approved_by"
--
-- TOC entry 4836 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.approved_by; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.approved_by IS 'Admin who approved';


pg_dump: creating COMMENT "predictions.COLUMN predictions.prediction_metadata"
--
-- TOC entry 4837 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.prediction_metadata; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.prediction_metadata IS 'Additional prediction metadata';


pg_dump: creating COMMENT "predictions.COLUMN predictions.id"
--
-- TOC entry 4838 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN predictions.created_at"
--
-- TOC entry 4839 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN predictions.updated_at"
--
-- TOC entry 4840 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.updated_at IS 'Record last update timestamp';


pg_dump: creating COMMENT "predictions.COLUMN predictions.deleted_at"
--
-- TOC entry 4841 (class 0 OID 0)
-- Dependencies: 281
-- Name: COLUMN predictions.deleted_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.predictions.deleted_at IS 'Soft delete timestamp';


pg_dump: creating TABLE "predictions.teams"
--
-- TOC entry 234 (class 1259 OID 21627)
-- Name: teams; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.teams (
    name character varying(255) NOT NULL,
    short_name character varying(50),
    code character varying(10),
    country character varying(100),
    logo_url character varying(500),
    founded_year integer,
    venue_name character varying(255),
    venue_capacity integer,
    external_api_id character varying(100),
    external_api_source character varying(50),
    is_active boolean NOT NULL,
    team_metadata jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.teams OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE teams"
--
-- TOC entry 4842 (class 0 OID 0)
-- Dependencies: 234
-- Name: TABLE teams; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.teams IS 'Team reference data';


pg_dump: creating COMMENT "predictions.COLUMN teams.code"
--
-- TOC entry 4843 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN teams.code; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.teams.code IS '3-letter team code';


pg_dump: creating COMMENT "predictions.COLUMN teams.id"
--
-- TOC entry 4844 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN teams.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.teams.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN teams.created_at"
--
-- TOC entry 4845 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN teams.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.teams.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN teams.updated_at"
--
-- TOC entry 4846 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN teams.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.teams.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.user_prediction_feedback"
--
-- TOC entry 290 (class 1259 OID 22891)
-- Name: user_prediction_feedback; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.user_prediction_feedback (
    prediction_id uuid NOT NULL,
    user_id uuid NOT NULL,
    rating integer,
    is_upvote boolean,
    is_downvote boolean,
    comment text,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.user_prediction_feedback OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE user_prediction_feedback"
--
-- TOC entry 4847 (class 0 OID 0)
-- Dependencies: 290
-- Name: TABLE user_prediction_feedback; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.user_prediction_feedback IS 'User prediction feedback';


pg_dump: creating COMMENT "predictions.COLUMN user_prediction_feedback.rating"
--
-- TOC entry 4848 (class 0 OID 0)
-- Dependencies: 290
-- Name: COLUMN user_prediction_feedback.rating; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.user_prediction_feedback.rating IS '1-5 star rating';


pg_dump: creating COMMENT "predictions.COLUMN user_prediction_feedback.id"
--
-- TOC entry 4849 (class 0 OID 0)
-- Dependencies: 290
-- Name: COLUMN user_prediction_feedback.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.user_prediction_feedback.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN user_prediction_feedback.created_at"
--
-- TOC entry 4850 (class 0 OID 0)
-- Dependencies: 290
-- Name: COLUMN user_prediction_feedback.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.user_prediction_feedback.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN user_prediction_feedback.updated_at"
--
-- TOC entry 4851 (class 0 OID 0)
-- Dependencies: 290
-- Name: COLUMN user_prediction_feedback.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.user_prediction_feedback.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "predictions.user_prediction_views"
--
-- TOC entry 291 (class 1259 OID 22912)
-- Name: user_prediction_views; Type: TABLE; Schema: predictions; Owner: postgres
--

CREATE TABLE predictions.user_prediction_views (
    prediction_id uuid NOT NULL,
    user_id uuid,
    session_id character varying(255),
    view_duration_seconds integer,
    ip_address character varying(45),
    user_agent text,
    referrer character varying(500),
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE predictions.user_prediction_views OWNER TO postgres;

pg_dump: creating COMMENT "predictions.TABLE user_prediction_views"
--
-- TOC entry 4852 (class 0 OID 0)
-- Dependencies: 291
-- Name: TABLE user_prediction_views; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON TABLE predictions.user_prediction_views IS 'User prediction views';


pg_dump: creating COMMENT "predictions.COLUMN user_prediction_views.user_id"
--
-- TOC entry 4853 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN user_prediction_views.user_id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.user_prediction_views.user_id IS 'Null for anonymous users';


pg_dump: creating COMMENT "predictions.COLUMN user_prediction_views.id"
--
-- TOC entry 4854 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN user_prediction_views.id; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.user_prediction_views.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "predictions.COLUMN user_prediction_views.created_at"
--
-- TOC entry 4855 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN user_prediction_views.created_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.user_prediction_views.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "predictions.COLUMN user_prediction_views.updated_at"
--
-- TOC entry 4856 (class 0 OID 0)
-- Dependencies: 291
-- Name: COLUMN user_prediction_views.updated_at; Type: COMMENT; Schema: predictions; Owner: postgres
--

COMMENT ON COLUMN predictions.user_prediction_views.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "public.db_init_log"
--
-- TOC entry 224 (class 1259 OID 17105)
-- Name: db_init_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.db_init_log (
    id integer NOT NULL,
    script_name character varying(255) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(50) DEFAULT 'success'::character varying,
    message text
);


ALTER TABLE public.db_init_log OWNER TO postgres;

pg_dump: creating SEQUENCE "public.db_init_log_id_seq"
--
-- TOC entry 223 (class 1259 OID 17104)
-- Name: db_init_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.db_init_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.db_init_log_id_seq OWNER TO postgres;

pg_dump: creating SEQUENCE OWNED BY "public.db_init_log_id_seq"
--
-- TOC entry 4857 (class 0 OID 0)
-- Dependencies: 223
-- Name: db_init_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.db_init_log_id_seq OWNED BY public.db_init_log.id;


pg_dump: creating TABLE "users.admin_activity_log"
--
-- TOC entry 273 (class 1259 OID 22461)
-- Name: admin_activity_log; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.admin_activity_log (
    admin_profile_id uuid NOT NULL,
    action_type character varying(100) NOT NULL,
    action_description text,
    target_resource_type character varying(100),
    target_resource_id uuid,
    action_details jsonb,
    changes_made jsonb,
    ip_address inet,
    user_agent text,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.admin_activity_log OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE admin_activity_log"
--
-- TOC entry 4858 (class 0 OID 0)
-- Dependencies: 273
-- Name: TABLE admin_activity_log; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.admin_activity_log IS 'Admin activity log';


pg_dump: creating COMMENT "users.COLUMN admin_activity_log.target_resource_type"
--
-- TOC entry 4859 (class 0 OID 0)
-- Dependencies: 273
-- Name: COLUMN admin_activity_log.target_resource_type; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_activity_log.target_resource_type IS 'user, prediction, expert';


pg_dump: creating COMMENT "users.COLUMN admin_activity_log.action_details"
--
-- TOC entry 4860 (class 0 OID 0)
-- Dependencies: 273
-- Name: COLUMN admin_activity_log.action_details; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_activity_log.action_details IS 'Detailed action data';


pg_dump: creating COMMENT "users.COLUMN admin_activity_log.changes_made"
--
-- TOC entry 4861 (class 0 OID 0)
-- Dependencies: 273
-- Name: COLUMN admin_activity_log.changes_made; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_activity_log.changes_made IS 'Before/after changes';


pg_dump: creating COMMENT "users.COLUMN admin_activity_log.id"
--
-- TOC entry 4862 (class 0 OID 0)
-- Dependencies: 273
-- Name: COLUMN admin_activity_log.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_activity_log.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN admin_activity_log.created_at"
--
-- TOC entry 4863 (class 0 OID 0)
-- Dependencies: 273
-- Name: COLUMN admin_activity_log.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_activity_log.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN admin_activity_log.updated_at"
--
-- TOC entry 4864 (class 0 OID 0)
-- Dependencies: 273
-- Name: COLUMN admin_activity_log.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_activity_log.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.admin_permissions"
--
-- TOC entry 274 (class 1259 OID 22476)
-- Name: admin_permissions; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.admin_permissions (
    admin_profile_id uuid NOT NULL,
    permission_type character varying(100) NOT NULL,
    permission_scope character varying(100),
    scope_constraints jsonb,
    is_active boolean NOT NULL,
    granted_at timestamp without time zone NOT NULL,
    granted_by_admin_id uuid,
    expires_at timestamp without time zone,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.admin_permissions OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE admin_permissions"
--
-- TOC entry 4865 (class 0 OID 0)
-- Dependencies: 274
-- Name: TABLE admin_permissions; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.admin_permissions IS 'Admin permissions';


pg_dump: creating COMMENT "users.COLUMN admin_permissions.permission_scope"
--
-- TOC entry 4866 (class 0 OID 0)
-- Dependencies: 274
-- Name: COLUMN admin_permissions.permission_scope; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_permissions.permission_scope IS 'global, league, team';


pg_dump: creating COMMENT "users.COLUMN admin_permissions.scope_constraints"
--
-- TOC entry 4867 (class 0 OID 0)
-- Dependencies: 274
-- Name: COLUMN admin_permissions.scope_constraints; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_permissions.scope_constraints IS 'Scope limitations';


pg_dump: creating COMMENT "users.COLUMN admin_permissions.id"
--
-- TOC entry 4868 (class 0 OID 0)
-- Dependencies: 274
-- Name: COLUMN admin_permissions.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_permissions.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN admin_permissions.created_at"
--
-- TOC entry 4869 (class 0 OID 0)
-- Dependencies: 274
-- Name: COLUMN admin_permissions.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_permissions.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN admin_permissions.updated_at"
--
-- TOC entry 4870 (class 0 OID 0)
-- Dependencies: 274
-- Name: COLUMN admin_permissions.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_permissions.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.admin_profiles"
--
-- TOC entry 253 (class 1259 OID 22057)
-- Name: admin_profiles; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.admin_profiles (
    user_id uuid NOT NULL,
    department character varying(100),
    job_title character varying(100),
    is_super_admin boolean NOT NULL,
    can_approve_predictions boolean NOT NULL,
    can_manage_users boolean NOT NULL,
    can_manage_experts boolean NOT NULL,
    can_access_audit_logs boolean NOT NULL,
    can_manage_system_settings boolean NOT NULL,
    last_admin_action_at timestamp without time zone,
    total_actions_count integer NOT NULL,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.admin_profiles OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE admin_profiles"
--
-- TOC entry 4871 (class 0 OID 0)
-- Dependencies: 253
-- Name: TABLE admin_profiles; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.admin_profiles IS 'Admin user profiles';


pg_dump: creating COMMENT "users.COLUMN admin_profiles.department"
--
-- TOC entry 4872 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN admin_profiles.department; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_profiles.department IS 'Department/team';


pg_dump: creating COMMENT "users.COLUMN admin_profiles.job_title"
--
-- TOC entry 4873 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN admin_profiles.job_title; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_profiles.job_title IS 'Job title';


pg_dump: creating COMMENT "users.COLUMN admin_profiles.id"
--
-- TOC entry 4874 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN admin_profiles.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_profiles.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN admin_profiles.created_at"
--
-- TOC entry 4875 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN admin_profiles.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_profiles.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN admin_profiles.updated_at"
--
-- TOC entry 4876 (class 0 OID 0)
-- Dependencies: 253
-- Name: COLUMN admin_profiles.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.admin_profiles.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.alembic_version"
--
-- TOC entry 225 (class 1259 OID 19928)
-- Name: alembic_version; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE users.alembic_version OWNER TO postgres;

pg_dump: creating TABLE "users.expert_performance_metrics"
--
-- TOC entry 275 (class 1259 OID 22495)
-- Name: expert_performance_metrics; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.expert_performance_metrics (
    expert_profile_id uuid NOT NULL,
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    period_type character varying(20) NOT NULL,
    total_predictions integer NOT NULL,
    correct_predictions integer NOT NULL,
    accuracy_rate numeric(5,2),
    average_confidence numeric(5,2),
    roi_percentage numeric(10,2),
    detailed_metrics jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.expert_performance_metrics OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE expert_performance_metrics"
--
-- TOC entry 4877 (class 0 OID 0)
-- Dependencies: 275
-- Name: TABLE expert_performance_metrics; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.expert_performance_metrics IS 'Expert performance metrics';


pg_dump: creating COMMENT "users.COLUMN expert_performance_metrics.period_type"
--
-- TOC entry 4878 (class 0 OID 0)
-- Dependencies: 275
-- Name: COLUMN expert_performance_metrics.period_type; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_performance_metrics.period_type IS 'daily, weekly, monthly, yearly';


pg_dump: creating COMMENT "users.COLUMN expert_performance_metrics.detailed_metrics"
--
-- TOC entry 4879 (class 0 OID 0)
-- Dependencies: 275
-- Name: COLUMN expert_performance_metrics.detailed_metrics; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_performance_metrics.detailed_metrics IS 'Detailed performance data';


pg_dump: creating COMMENT "users.COLUMN expert_performance_metrics.id"
--
-- TOC entry 4880 (class 0 OID 0)
-- Dependencies: 275
-- Name: COLUMN expert_performance_metrics.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_performance_metrics.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN expert_performance_metrics.created_at"
--
-- TOC entry 4881 (class 0 OID 0)
-- Dependencies: 275
-- Name: COLUMN expert_performance_metrics.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_performance_metrics.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN expert_performance_metrics.updated_at"
--
-- TOC entry 4882 (class 0 OID 0)
-- Dependencies: 275
-- Name: COLUMN expert_performance_metrics.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_performance_metrics.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.expert_profiles"
--
-- TOC entry 254 (class 1259 OID 22071)
-- Name: expert_profiles; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.expert_profiles (
    user_id uuid NOT NULL,
    bio text,
    expertise_areas jsonb,
    years_of_experience integer,
    is_verified boolean NOT NULL,
    verified_at timestamp without time zone,
    verified_by_admin_id uuid,
    total_predictions integer NOT NULL,
    correct_predictions integer NOT NULL,
    accuracy_score numeric(5,2),
    average_confidence numeric(5,2),
    roi_percentage numeric(10,2),
    reputation_score integer NOT NULL,
    follower_count integer NOT NULL,
    performance_data jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.expert_profiles OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE expert_profiles"
--
-- TOC entry 4883 (class 0 OID 0)
-- Dependencies: 254
-- Name: TABLE expert_profiles; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.expert_profiles IS 'Expert user profiles';


pg_dump: creating COMMENT "users.COLUMN expert_profiles.user_id"
--
-- TOC entry 4884 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN expert_profiles.user_id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_profiles.user_id IS 'Reference to user';


pg_dump: creating COMMENT "users.COLUMN expert_profiles.bio"
--
-- TOC entry 4885 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN expert_profiles.bio; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_profiles.bio IS 'Expert biography';


pg_dump: creating COMMENT "users.COLUMN expert_profiles.expertise_areas"
--
-- TOC entry 4886 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN expert_profiles.expertise_areas; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_profiles.expertise_areas IS 'Areas of expertise (leagues, teams)';


pg_dump: creating COMMENT "users.COLUMN expert_profiles.years_of_experience"
--
-- TOC entry 4887 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN expert_profiles.years_of_experience; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_profiles.years_of_experience IS 'Years of experience';


pg_dump: creating COMMENT "users.COLUMN expert_profiles.accuracy_score"
--
-- TOC entry 4888 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN expert_profiles.accuracy_score; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_profiles.accuracy_score IS 'Overall accuracy percentage';


pg_dump: creating COMMENT "users.COLUMN expert_profiles.average_confidence"
--
-- TOC entry 4889 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN expert_profiles.average_confidence; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_profiles.average_confidence IS 'Average confidence score';


pg_dump: creating COMMENT "users.COLUMN expert_profiles.roi_percentage"
--
-- TOC entry 4890 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN expert_profiles.roi_percentage; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_profiles.roi_percentage IS 'Return on investment %';


pg_dump: creating COMMENT "users.COLUMN expert_profiles.performance_data"
--
-- TOC entry 4891 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN expert_profiles.performance_data; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_profiles.performance_data IS 'Detailed performance metrics';


pg_dump: creating COMMENT "users.COLUMN expert_profiles.id"
--
-- TOC entry 4892 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN expert_profiles.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_profiles.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN expert_profiles.created_at"
--
-- TOC entry 4893 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN expert_profiles.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_profiles.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN expert_profiles.updated_at"
--
-- TOC entry 4894 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN expert_profiles.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_profiles.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.expert_specialties"
--
-- TOC entry 276 (class 1259 OID 22509)
-- Name: expert_specialties; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.expert_specialties (
    expert_profile_id uuid NOT NULL,
    specialty_type character varying(50) NOT NULL,
    specialty_value character varying(255) NOT NULL,
    predictions_count integer NOT NULL,
    accuracy_rate numeric(5,2),
    confidence_level character varying(20),
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.expert_specialties OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE expert_specialties"
--
-- TOC entry 4895 (class 0 OID 0)
-- Dependencies: 276
-- Name: TABLE expert_specialties; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.expert_specialties IS 'Expert specialties';


pg_dump: creating COMMENT "users.COLUMN expert_specialties.specialty_type"
--
-- TOC entry 4896 (class 0 OID 0)
-- Dependencies: 276
-- Name: COLUMN expert_specialties.specialty_type; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_specialties.specialty_type IS 'league, team, market_type';


pg_dump: creating COMMENT "users.COLUMN expert_specialties.specialty_value"
--
-- TOC entry 4897 (class 0 OID 0)
-- Dependencies: 276
-- Name: COLUMN expert_specialties.specialty_value; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_specialties.specialty_value IS 'Specific league/team/market';


pg_dump: creating COMMENT "users.COLUMN expert_specialties.confidence_level"
--
-- TOC entry 4898 (class 0 OID 0)
-- Dependencies: 276
-- Name: COLUMN expert_specialties.confidence_level; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_specialties.confidence_level IS 'high, medium, low';


pg_dump: creating COMMENT "users.COLUMN expert_specialties.id"
--
-- TOC entry 4899 (class 0 OID 0)
-- Dependencies: 276
-- Name: COLUMN expert_specialties.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_specialties.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN expert_specialties.created_at"
--
-- TOC entry 4900 (class 0 OID 0)
-- Dependencies: 276
-- Name: COLUMN expert_specialties.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_specialties.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN expert_specialties.updated_at"
--
-- TOC entry 4901 (class 0 OID 0)
-- Dependencies: 276
-- Name: COLUMN expert_specialties.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.expert_specialties.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.password_reset_tokens"
--
-- TOC entry 255 (class 1259 OID 22093)
-- Name: password_reset_tokens; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.password_reset_tokens (
    user_id uuid NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    is_used boolean NOT NULL,
    used_at timestamp without time zone,
    ip_address inet,
    user_agent text,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.password_reset_tokens OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE password_reset_tokens"
--
-- TOC entry 4902 (class 0 OID 0)
-- Dependencies: 255
-- Name: TABLE password_reset_tokens; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.password_reset_tokens IS 'Password reset tokens';


pg_dump: creating COMMENT "users.COLUMN password_reset_tokens.id"
--
-- TOC entry 4903 (class 0 OID 0)
-- Dependencies: 255
-- Name: COLUMN password_reset_tokens.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.password_reset_tokens.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN password_reset_tokens.created_at"
--
-- TOC entry 4904 (class 0 OID 0)
-- Dependencies: 255
-- Name: COLUMN password_reset_tokens.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.password_reset_tokens.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN password_reset_tokens.updated_at"
--
-- TOC entry 4905 (class 0 OID 0)
-- Dependencies: 255
-- Name: COLUMN password_reset_tokens.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.password_reset_tokens.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.permissions"
--
-- TOC entry 235 (class 1259 OID 21639)
-- Name: permissions; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.permissions (
    name character varying(100) NOT NULL,
    display_name character varying(150) NOT NULL,
    description text,
    resource_type character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.permissions OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE permissions"
--
-- TOC entry 4906 (class 0 OID 0)
-- Dependencies: 235
-- Name: TABLE permissions; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.permissions IS 'RBAC permissions';


pg_dump: creating COMMENT "users.COLUMN permissions.resource_type"
--
-- TOC entry 4907 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN permissions.resource_type; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.permissions.resource_type IS 'prediction, user, expert, admin';


pg_dump: creating COMMENT "users.COLUMN permissions.action"
--
-- TOC entry 4908 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN permissions.action; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.permissions.action IS 'create, read, update, delete, approve';


pg_dump: creating COMMENT "users.COLUMN permissions.id"
--
-- TOC entry 4909 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN permissions.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.permissions.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN permissions.created_at"
--
-- TOC entry 4910 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN permissions.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.permissions.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN permissions.updated_at"
--
-- TOC entry 4911 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN permissions.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.permissions.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.role_permissions"
--
-- TOC entry 256 (class 1259 OID 22110)
-- Name: role_permissions; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.role_permissions (
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    granted_at timestamp without time zone NOT NULL,
    granted_by_admin_id uuid,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.role_permissions OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE role_permissions"
--
-- TOC entry 4912 (class 0 OID 0)
-- Dependencies: 256
-- Name: TABLE role_permissions; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.role_permissions IS 'Role-permission assignments';


pg_dump: creating COMMENT "users.COLUMN role_permissions.id"
--
-- TOC entry 4913 (class 0 OID 0)
-- Dependencies: 256
-- Name: COLUMN role_permissions.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.role_permissions.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN role_permissions.created_at"
--
-- TOC entry 4914 (class 0 OID 0)
-- Dependencies: 256
-- Name: COLUMN role_permissions.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.role_permissions.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN role_permissions.updated_at"
--
-- TOC entry 4915 (class 0 OID 0)
-- Dependencies: 256
-- Name: COLUMN role_permissions.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.role_permissions.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.roles"
--
-- TOC entry 236 (class 1259 OID 21650)
-- Name: roles; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.roles (
    name character varying(50) NOT NULL,
    display_name character varying(100) NOT NULL,
    description text,
    is_active boolean NOT NULL,
    is_system_role boolean NOT NULL,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.roles OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE roles"
--
-- TOC entry 4916 (class 0 OID 0)
-- Dependencies: 236
-- Name: TABLE roles; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.roles IS 'RBAC roles';


pg_dump: creating COMMENT "users.COLUMN roles.is_system_role"
--
-- TOC entry 4917 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN roles.is_system_role; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.roles.is_system_role IS 'System-defined role';


pg_dump: creating COMMENT "users.COLUMN roles.id"
--
-- TOC entry 4918 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN roles.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.roles.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN roles.created_at"
--
-- TOC entry 4919 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN roles.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.roles.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN roles.updated_at"
--
-- TOC entry 4920 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN roles.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.roles.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.user_activity_log"
--
-- TOC entry 257 (class 1259 OID 22134)
-- Name: user_activity_log; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.user_activity_log (
    user_id uuid NOT NULL,
    activity_type character varying(100) NOT NULL,
    activity_description text,
    activity_data jsonb,
    ip_address inet,
    user_agent text,
    session_id uuid,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.user_activity_log OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE user_activity_log"
--
-- TOC entry 4921 (class 0 OID 0)
-- Dependencies: 257
-- Name: TABLE user_activity_log; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.user_activity_log IS 'User activity log';


pg_dump: creating COMMENT "users.COLUMN user_activity_log.activity_type"
--
-- TOC entry 4922 (class 0 OID 0)
-- Dependencies: 257
-- Name: COLUMN user_activity_log.activity_type; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_activity_log.activity_type IS 'Type of activity';


pg_dump: creating COMMENT "users.COLUMN user_activity_log.activity_data"
--
-- TOC entry 4923 (class 0 OID 0)
-- Dependencies: 257
-- Name: COLUMN user_activity_log.activity_data; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_activity_log.activity_data IS 'Additional activity data';


pg_dump: creating COMMENT "users.COLUMN user_activity_log.id"
--
-- TOC entry 4924 (class 0 OID 0)
-- Dependencies: 257
-- Name: COLUMN user_activity_log.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_activity_log.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN user_activity_log.created_at"
--
-- TOC entry 4925 (class 0 OID 0)
-- Dependencies: 257
-- Name: COLUMN user_activity_log.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_activity_log.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN user_activity_log.updated_at"
--
-- TOC entry 4926 (class 0 OID 0)
-- Dependencies: 257
-- Name: COLUMN user_activity_log.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_activity_log.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.user_notifications"
--
-- TOC entry 258 (class 1259 OID 22161)
-- Name: user_notifications; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.user_notifications (
    user_id uuid NOT NULL,
    notification_type users.notificationtype NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    is_read boolean NOT NULL,
    read_at timestamp without time zone,
    notification_data jsonb,
    action_url character varying(500),
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.user_notifications OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE user_notifications"
--
-- TOC entry 4927 (class 0 OID 0)
-- Dependencies: 258
-- Name: TABLE user_notifications; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.user_notifications IS 'User notifications';


pg_dump: creating COMMENT "users.COLUMN user_notifications.notification_data"
--
-- TOC entry 4928 (class 0 OID 0)
-- Dependencies: 258
-- Name: COLUMN user_notifications.notification_data; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_notifications.notification_data IS 'Additional notification data';


pg_dump: creating COMMENT "users.COLUMN user_notifications.action_url"
--
-- TOC entry 4929 (class 0 OID 0)
-- Dependencies: 258
-- Name: COLUMN user_notifications.action_url; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_notifications.action_url IS 'URL for notification action';


pg_dump: creating COMMENT "users.COLUMN user_notifications.id"
--
-- TOC entry 4930 (class 0 OID 0)
-- Dependencies: 258
-- Name: COLUMN user_notifications.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_notifications.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN user_notifications.created_at"
--
-- TOC entry 4931 (class 0 OID 0)
-- Dependencies: 258
-- Name: COLUMN user_notifications.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_notifications.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN user_notifications.updated_at"
--
-- TOC entry 4932 (class 0 OID 0)
-- Dependencies: 258
-- Name: COLUMN user_notifications.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_notifications.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.user_preferences"
--
-- TOC entry 259 (class 1259 OID 22176)
-- Name: user_preferences; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.user_preferences (
    user_id uuid NOT NULL,
    email_notifications boolean NOT NULL,
    push_notifications boolean NOT NULL,
    sms_notifications boolean NOT NULL,
    theme character varying(20),
    odds_format character varying(20),
    favorite_leagues jsonb,
    favorite_teams jsonb,
    favorite_experts jsonb,
    profile_visibility character varying(20),
    show_prediction_history boolean NOT NULL,
    additional_settings jsonb,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.user_preferences OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE user_preferences"
--
-- TOC entry 4933 (class 0 OID 0)
-- Dependencies: 259
-- Name: TABLE user_preferences; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.user_preferences IS 'User preferences';


pg_dump: creating COMMENT "users.COLUMN user_preferences.theme"
--
-- TOC entry 4934 (class 0 OID 0)
-- Dependencies: 259
-- Name: COLUMN user_preferences.theme; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_preferences.theme IS 'UI theme';


pg_dump: creating COMMENT "users.COLUMN user_preferences.odds_format"
--
-- TOC entry 4935 (class 0 OID 0)
-- Dependencies: 259
-- Name: COLUMN user_preferences.odds_format; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_preferences.odds_format IS 'Odds display format';


pg_dump: creating COMMENT "users.COLUMN user_preferences.favorite_leagues"
--
-- TOC entry 4936 (class 0 OID 0)
-- Dependencies: 259
-- Name: COLUMN user_preferences.favorite_leagues; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_preferences.favorite_leagues IS 'Favorite league IDs';


pg_dump: creating COMMENT "users.COLUMN user_preferences.favorite_teams"
--
-- TOC entry 4937 (class 0 OID 0)
-- Dependencies: 259
-- Name: COLUMN user_preferences.favorite_teams; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_preferences.favorite_teams IS 'Favorite team IDs';


pg_dump: creating COMMENT "users.COLUMN user_preferences.favorite_experts"
--
-- TOC entry 4938 (class 0 OID 0)
-- Dependencies: 259
-- Name: COLUMN user_preferences.favorite_experts; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_preferences.favorite_experts IS 'Favorite expert IDs';


pg_dump: creating COMMENT "users.COLUMN user_preferences.additional_settings"
--
-- TOC entry 4939 (class 0 OID 0)
-- Dependencies: 259
-- Name: COLUMN user_preferences.additional_settings; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_preferences.additional_settings IS 'Additional user settings';


pg_dump: creating COMMENT "users.COLUMN user_preferences.id"
--
-- TOC entry 4940 (class 0 OID 0)
-- Dependencies: 259
-- Name: COLUMN user_preferences.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_preferences.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN user_preferences.created_at"
--
-- TOC entry 4941 (class 0 OID 0)
-- Dependencies: 259
-- Name: COLUMN user_preferences.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_preferences.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN user_preferences.updated_at"
--
-- TOC entry 4942 (class 0 OID 0)
-- Dependencies: 259
-- Name: COLUMN user_preferences.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_preferences.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.user_roles"
--
-- TOC entry 260 (class 1259 OID 22191)
-- Name: user_roles; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_at timestamp without time zone NOT NULL,
    assigned_by_admin_id uuid,
    expires_at timestamp without time zone,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.user_roles OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE user_roles"
--
-- TOC entry 4943 (class 0 OID 0)
-- Dependencies: 260
-- Name: TABLE user_roles; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.user_roles IS 'User-role assignments';


pg_dump: creating COMMENT "users.COLUMN user_roles.id"
--
-- TOC entry 4944 (class 0 OID 0)
-- Dependencies: 260
-- Name: COLUMN user_roles.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_roles.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN user_roles.created_at"
--
-- TOC entry 4945 (class 0 OID 0)
-- Dependencies: 260
-- Name: COLUMN user_roles.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_roles.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN user_roles.updated_at"
--
-- TOC entry 4946 (class 0 OID 0)
-- Dependencies: 260
-- Name: COLUMN user_roles.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_roles.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.user_sessions"
--
-- TOC entry 261 (class 1259 OID 22215)
-- Name: user_sessions; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.user_sessions (
    user_id uuid NOT NULL,
    refresh_token character varying(500) NOT NULL,
    access_token_jti character varying(255),
    device_info jsonb,
    ip_address inet,
    user_agent text,
    is_active boolean NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    last_activity_at timestamp without time zone,
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.user_sessions OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE user_sessions"
--
-- TOC entry 4947 (class 0 OID 0)
-- Dependencies: 261
-- Name: TABLE user_sessions; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.user_sessions IS 'User authentication sessions';


pg_dump: creating COMMENT "users.COLUMN user_sessions.access_token_jti"
--
-- TOC entry 4948 (class 0 OID 0)
-- Dependencies: 261
-- Name: COLUMN user_sessions.access_token_jti; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_sessions.access_token_jti IS 'JWT ID of access token';


pg_dump: creating COMMENT "users.COLUMN user_sessions.device_info"
--
-- TOC entry 4949 (class 0 OID 0)
-- Dependencies: 261
-- Name: COLUMN user_sessions.device_info; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_sessions.device_info IS 'Device information';


pg_dump: creating COMMENT "users.COLUMN user_sessions.id"
--
-- TOC entry 4950 (class 0 OID 0)
-- Dependencies: 261
-- Name: COLUMN user_sessions.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_sessions.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN user_sessions.created_at"
--
-- TOC entry 4951 (class 0 OID 0)
-- Dependencies: 261
-- Name: COLUMN user_sessions.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_sessions.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN user_sessions.updated_at"
--
-- TOC entry 4952 (class 0 OID 0)
-- Dependencies: 261
-- Name: COLUMN user_sessions.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_sessions.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.user_subscriptions"
--
-- TOC entry 262 (class 1259 OID 22253)
-- Name: user_subscriptions; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.user_subscriptions (
    user_id uuid NOT NULL,
    tier users.subscriptiontier NOT NULL,
    status users.subscriptionstatus NOT NULL,
    stripe_subscription_id character varying(255),
    stripe_customer_id character varying(255),
    starts_at timestamp without time zone NOT NULL,
    expires_at timestamp without time zone,
    cancelled_at timestamp without time zone,
    trial_ends_at timestamp without time zone,
    price_amount numeric(10,2),
    currency character varying(3),
    billing_cycle character varying(20),
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE users.user_subscriptions OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE user_subscriptions"
--
-- TOC entry 4953 (class 0 OID 0)
-- Dependencies: 262
-- Name: TABLE user_subscriptions; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.user_subscriptions IS 'User subscriptions';


pg_dump: creating COMMENT "users.COLUMN user_subscriptions.billing_cycle"
--
-- TOC entry 4954 (class 0 OID 0)
-- Dependencies: 262
-- Name: COLUMN user_subscriptions.billing_cycle; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_subscriptions.billing_cycle IS 'monthly, yearly';


pg_dump: creating COMMENT "users.COLUMN user_subscriptions.id"
--
-- TOC entry 4955 (class 0 OID 0)
-- Dependencies: 262
-- Name: COLUMN user_subscriptions.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_subscriptions.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN user_subscriptions.created_at"
--
-- TOC entry 4956 (class 0 OID 0)
-- Dependencies: 262
-- Name: COLUMN user_subscriptions.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_subscriptions.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN user_subscriptions.updated_at"
--
-- TOC entry 4957 (class 0 OID 0)
-- Dependencies: 262
-- Name: COLUMN user_subscriptions.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.user_subscriptions.updated_at IS 'Record last update timestamp';


pg_dump: creating TABLE "users.users"
--
-- TOC entry 237 (class 1259 OID 21679)
-- Name: users; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.users (
    email character varying(255) NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    avatar_url character varying(500),
    user_type users.usertype NOT NULL,
    account_status users.accountstatus NOT NULL,
    email_verified boolean NOT NULL,
    email_verification_token character varying(255),
    email_verified_at timestamp without time zone,
    password_reset_token character varying(255),
    password_reset_expires_at timestamp without time zone,
    last_login_at timestamp without time zone,
    last_login_ip inet,
    timezone character varying(50),
    language character varying(10),
    id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


ALTER TABLE users.users OWNER TO postgres;

pg_dump: creating COMMENT "users.TABLE users"
--
-- TOC entry 4958 (class 0 OID 0)
-- Dependencies: 237
-- Name: TABLE users; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON TABLE users.users IS 'Core user accounts';


pg_dump: creating COMMENT "users.COLUMN users.email"
--
-- TOC entry 4959 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN users.email; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.users.email IS 'User email address';


pg_dump: creating COMMENT "users.COLUMN users.username"
--
-- TOC entry 4960 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN users.username; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.users.username IS 'Unique username';


pg_dump: creating COMMENT "users.COLUMN users.password_hash"
--
-- TOC entry 4961 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN users.password_hash; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.users.password_hash IS 'Bcrypt hashed password';


pg_dump: creating COMMENT "users.COLUMN users.first_name"
--
-- TOC entry 4962 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN users.first_name; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.users.first_name IS 'First name';


pg_dump: creating COMMENT "users.COLUMN users.last_name"
--
-- TOC entry 4963 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN users.last_name; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.users.last_name IS 'Last name';


pg_dump: creating COMMENT "users.COLUMN users.avatar_url"
--
-- TOC entry 4964 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN users.avatar_url; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.users.avatar_url IS 'Profile image URL';


pg_dump: creating COMMENT "users.COLUMN users.user_type"
--
-- TOC entry 4965 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN users.user_type; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.users.user_type IS 'User type';


pg_dump: creating COMMENT "users.COLUMN users.id"
--
-- TOC entry 4966 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN users.id; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.users.id IS 'Primary key (UUID)';


pg_dump: creating COMMENT "users.COLUMN users.created_at"
--
-- TOC entry 4967 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN users.created_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.users.created_at IS 'Record creation timestamp';


pg_dump: creating COMMENT "users.COLUMN users.updated_at"
--
-- TOC entry 4968 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN users.updated_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.users.updated_at IS 'Record last update timestamp';


pg_dump: creating COMMENT "users.COLUMN users.deleted_at"
--
-- TOC entry 4969 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN users.deleted_at; Type: COMMENT; Schema: users; Owner: postgres
--

COMMENT ON COLUMN users.users.deleted_at IS 'Soft delete timestamp';


pg_dump: creating DEFAULT "public.db_init_log id"
--
-- TOC entry 3843 (class 2604 OID 17108)
-- Name: db_init_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_init_log ALTER COLUMN id SET DEFAULT nextval('public.db_init_log_id_seq'::regclass);


--
-- TOC entry 4478 (class 0 OID 21695)
-- Dependencies: 238
-- Data for Name: api_usage_analytics; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.api_usage_analytics"
COPY analytics.api_usage_analytics (period_start, period_end, period_type, endpoint, http_method, user_id, total_requests, successful_requests, failed_requests, average_response_time_ms, p50_response_time_ms, p95_response_time_ms, p99_response_time_ms, error_rate, detailed_metrics, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.api_usage_analytics"
\.


--
-- TOC entry 4466 (class 0 OID 21547)
-- Dependencies: 226
-- Data for Name: conversion_analytics; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.conversion_analytics"
COPY analytics.conversion_analytics (period_start, period_end, period_type, funnel_name, funnel_step, funnel_step_order, total_entered, total_completed, total_dropped, completion_rate, drop_off_rate, average_time_to_complete_seconds, detailed_metrics, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.conversion_analytics"
\.


--
-- TOC entry 4467 (class 0 OID 21556)
-- Dependencies: 227
-- Data for Name: error_analytics; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.error_analytics"
COPY analytics.error_analytics (period_start, period_end, period_type, error_type, error_category, severity, total_occurrences, unique_users_affected, total_requests_affected, error_rate, is_resolved, resolved_at, detailed_metrics, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.error_analytics"
\.


--
-- TOC entry 4503 (class 0 OID 22270)
-- Dependencies: 263
-- Data for Name: expert_analytics; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.expert_analytics"
COPY analytics.expert_analytics (expert_profile_id, period_start, period_end, period_type, total_predictions, total_overrides, predictions_approved, predictions_rejected, total_settled, total_correct, accuracy_rate, override_accuracy, override_improvement, total_followers, follower_growth, average_prediction_views, reputation_score, reputation_change, detailed_metrics, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.expert_analytics"
\.


--
-- TOC entry 4468 (class 0 OID 21566)
-- Dependencies: 228
-- Data for Name: feature_usage_analytics; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.feature_usage_analytics"
COPY analytics.feature_usage_analytics (period_start, period_end, period_type, feature_name, feature_category, total_users, total_uses, unique_users, average_uses_per_user, adoption_rate, detailed_metrics, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.feature_usage_analytics"
\.


--
-- TOC entry 4504 (class 0 OID 22285)
-- Dependencies: 264
-- Data for Name: model_performance_analytics; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.model_performance_analytics"
COPY analytics.model_performance_analytics (model_id, period_start, period_end, period_type, total_predictions, predictions_used, predictions_overridden, total_settled, total_correct, accuracy_rate, average_confidence, confidence_calibration, override_rate, override_accuracy_delta, detailed_metrics, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.model_performance_analytics"
\.


--
-- TOC entry 4469 (class 0 OID 21575)
-- Dependencies: 229
-- Data for Name: prediction_analytics_summary; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.prediction_analytics_summary"
COPY analytics.prediction_analytics_summary (period_start, period_end, period_type, total_predictions, ml_predictions, expert_predictions, expert_overrides, total_settled, total_correct, overall_accuracy, ml_accuracy, expert_accuracy, total_views, total_shares, total_comments, detailed_metrics, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.prediction_analytics_summary"
\.


--
-- TOC entry 4479 (class 0 OID 21710)
-- Dependencies: 239
-- Data for Name: prediction_performance_metrics; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.prediction_performance_metrics"
COPY analytics.prediction_performance_metrics (metric_date, league_id, market_type, total_predictions, correct_predictions, accuracy_rate, average_confidence, confidence_calibration, average_roi, total_roi, performance_metadata, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.prediction_performance_metrics"
\.


--
-- TOC entry 4470 (class 0 OID 21584)
-- Dependencies: 230
-- Data for Name: revenue_analytics; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.revenue_analytics"
COPY analytics.revenue_analytics (period_start, period_end, period_type, subscription_tier, total_revenue, new_revenue, recurring_revenue, mrr, arr, total_paying_customers, new_customers, churned_customers, arpu, churn_rate, detailed_metrics, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.revenue_analytics"
\.


--
-- TOC entry 4471 (class 0 OID 21594)
-- Dependencies: 231
-- Data for Name: system_analytics; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.system_analytics"
COPY analytics.system_analytics (period_start, period_end, period_type, total_users, active_users, new_users, churned_users, total_subscribers, new_subscribers, cancelled_subscriptions, total_predictions, published_predictions, average_response_time_ms, error_rate, uptime_percentage, detailed_metrics, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.system_analytics"
\.


--
-- TOC entry 4480 (class 0 OID 21725)
-- Dependencies: 240
-- Data for Name: user_activity_log; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.user_activity_log"
COPY analytics.user_activity_log (user_id, activity_type, activity_category, activity_description, session_id, page_url, referrer_url, device_type, browser, os, country, city, activity_metadata, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.user_activity_log"
\.


--
-- TOC entry 4481 (class 0 OID 21749)
-- Dependencies: 241
-- Data for Name: user_analytics; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.user_analytics"
COPY analytics.user_analytics (user_id, period_start, period_end, period_type, total_logins, total_sessions, total_session_duration_seconds, average_session_duration_seconds, predictions_viewed, predictions_shared, predictions_commented, predictions_rated, engagement_score, engagement_level, detailed_metrics, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.user_analytics"
\.


--
-- TOC entry 4482 (class 0 OID 21764)
-- Dependencies: 242
-- Data for Name: user_engagement_metrics; Type: TABLE DATA; Schema: analytics; Owner: postgres
--

pg_dump: processing data for table "analytics.user_engagement_metrics"
COPY analytics.user_engagement_metrics (user_id, metric_date, metric_type, metric_category, metric_value, metric_count, page_url, referrer_url, metric_metadata, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "analytics.user_engagement_metrics"
\.


--
-- TOC entry 4505 (class 0 OID 22299)
-- Dependencies: 265
-- Data for Name: admin_action_log; Type: TABLE DATA; Schema: audit; Owner: postgres
--

pg_dump: processing data for table "audit.admin_action_log"
COPY audit.admin_action_log (admin_user_id, admin_profile_id, action_type, action_category, action_description, target_resource_type, target_resource_id, target_user_id, changes_made, justification, requires_approval, approved_by_admin_id, approved_at, ip_address, user_agent, retention_until, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "audit.admin_action_log"
\.


--
-- TOC entry 4483 (class 0 OID 21811)
-- Dependencies: 243
-- Data for Name: audit_log; Type: TABLE DATA; Schema: audit; Owner: postgres
--

pg_dump: processing data for table "audit.audit_log"
COPY audit.audit_log (user_id, user_type, action, action_description, severity, resource_type, resource_id, resource_name, old_values, new_values, changes_summary, ip_address, user_agent, session_id, request_id, audit_metadata, retention_until, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "audit.audit_log"
\.


--
-- TOC entry 4484 (class 0 OID 21830)
-- Dependencies: 244
-- Data for Name: data_access_log; Type: TABLE DATA; Schema: audit; Owner: postgres
--

pg_dump: processing data for table "audit.data_access_log"
COPY audit.data_access_log (user_id, user_role, accessed_user_id, data_type, data_id, access_method, access_reason, is_authorized, authorization_basis, ip_address, user_agent, access_metadata, retention_until, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "audit.data_access_log"
\.


--
-- TOC entry 4485 (class 0 OID 21863)
-- Dependencies: 245
-- Data for Name: data_export_log; Type: TABLE DATA; Schema: audit; Owner: postgres
--

pg_dump: processing data for table "audit.data_export_log"
COPY audit.data_export_log (user_id, request_type, requested_data_types, status, requested_at, processing_started_at, completed_at, expires_at, export_file_path, export_file_size_bytes, export_format, download_count, last_downloaded_at, error_message, ip_address, user_agent, export_metadata, retention_until, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "audit.data_export_log"
\.


--
-- TOC entry 4486 (class 0 OID 21891)
-- Dependencies: 246
-- Data for Name: gdpr_consent_log; Type: TABLE DATA; Schema: audit; Owner: postgres
--

pg_dump: processing data for table "audit.gdpr_consent_log"
COPY audit.gdpr_consent_log (user_id, consent_type, consent_version, is_granted, is_active, granted_at, revoked_at, expires_at, consent_text, consent_language, ip_address, user_agent, consent_method, consent_metadata, retention_until, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "audit.gdpr_consent_log"
\.


--
-- TOC entry 4522 (class 0 OID 22699)
-- Dependencies: 282
-- Data for Name: prediction_change_log; Type: TABLE DATA; Schema: audit; Owner: postgres
--

pg_dump: processing data for table "audit.prediction_change_log"
COPY audit.prediction_change_log (prediction_id, changed_by, change_type, change_description, field_changed, old_value, new_value, old_probabilities, new_probabilities, probability_delta, old_confidence, new_confidence, confidence_delta, change_reason, ip_address, user_agent, retention_until, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "audit.prediction_change_log"
\.


--
-- TOC entry 4487 (class 0 OID 21907)
-- Dependencies: 247
-- Data for Name: system_event_log; Type: TABLE DATA; Schema: audit; Owner: postgres
--

pg_dump: processing data for table "audit.system_event_log"
COPY audit.system_event_log (event_type, event_category, event_description, severity, source_component, source_function, error_message, error_traceback, error_code, affected_users_count, affected_requests_count, is_resolved, resolved_at, resolved_by_admin_id, resolution_notes, event_metadata, retention_until, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "audit.system_event_log"
\.


--
-- TOC entry 4488 (class 0 OID 21923)
-- Dependencies: 248
-- Data for Name: user_action_log; Type: TABLE DATA; Schema: audit; Owner: postgres
--

pg_dump: processing data for table "audit.user_action_log"
COPY audit.user_action_log (user_id, action_type, action_category, action_description, action_result, error_message, is_suspicious, risk_score, ip_address, user_agent, session_id, country, city, action_metadata, retention_until, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "audit.user_action_log"
\.


--
-- TOC entry 4517 (class 0 OID 22521)
-- Dependencies: 277
-- Data for Name: ml_ab_test_results; Type: TABLE DATA; Schema: ml_models; Owner: postgres
--

pg_dump: processing data for table "ml_models.ml_ab_test_results"
COPY ml_models.ml_ab_test_results (ab_test_id, model_id, evaluation_date, total_predictions, correct_predictions, accuracy, user_engagement_score, average_confidence, detailed_results, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "ml_models.ml_ab_test_results"
\.


--
-- TOC entry 4506 (class 0 OID 22330)
-- Dependencies: 266
-- Data for Name: ml_ab_tests; Type: TABLE DATA; Schema: ml_models; Owner: postgres
--

pg_dump: processing data for table "ml_models.ml_ab_tests"
COPY ml_models.ml_ab_tests (test_name, description, model_a_id, model_b_id, traffic_split_percentage, is_active, started_at, ended_at, winner_model_id, conclusion, created_by_user_id, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "ml_models.ml_ab_tests"
\.


--
-- TOC entry 4507 (class 0 OID 22361)
-- Dependencies: 267
-- Data for Name: ml_ensemble_configs; Type: TABLE DATA; Schema: ml_models; Owner: postgres
--

pg_dump: processing data for table "ml_models.ml_ensemble_configs"
COPY ml_models.ml_ensemble_configs (ensemble_model_id, ensemble_method, member_models, model_weights, ensemble_config, is_active, ensemble_accuracy, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "ml_models.ml_ensemble_configs"
\.


--
-- TOC entry 4489 (class 0 OID 21939)
-- Dependencies: 249
-- Data for Name: ml_feature_engineering; Type: TABLE DATA; Schema: ml_models; Owner: postgres
--

pg_dump: processing data for table "ml_models.ml_feature_engineering"
COPY ml_models.ml_feature_engineering (feature_id, transformation_name, transformation_type, transformation_config, transformation_code, is_active, created_by_user_id, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "ml_models.ml_feature_engineering"
\.


--
-- TOC entry 4472 (class 0 OID 21603)
-- Dependencies: 232
-- Data for Name: ml_features; Type: TABLE DATA; Schema: ml_models; Owner: postgres
--

pg_dump: processing data for table "ml_models.ml_features"
COPY ml_models.ml_features (feature_name, feature_category, description, data_type, calculation_method, is_active, average_importance, feature_metadata, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "ml_models.ml_features"
\.


--
-- TOC entry 4518 (class 0 OID 22553)
-- Dependencies: 278
-- Data for Name: ml_model_deployments; Type: TABLE DATA; Schema: ml_models; Owner: postgres
--

pg_dump: processing data for table "ml_models.ml_model_deployments"
COPY ml_models.ml_model_deployments (model_id, model_version_id, deployment_environment, status, deployed_at, deactivated_at, deployment_config, deployed_by_user_id, rollback_reason, rolled_back_at, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "ml_models.ml_model_deployments"
\.


--
-- TOC entry 4508 (class 0 OID 22375)
-- Dependencies: 268
-- Data for Name: ml_model_metadata; Type: TABLE DATA; Schema: ml_models; Owner: postgres
--

pg_dump: processing data for table "ml_models.ml_model_metadata"
COPY ml_models.ml_model_metadata (model_id, metadata_key, metadata_value, description, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "ml_models.ml_model_metadata"
\.


--
-- TOC entry 4519 (class 0 OID 22578)
-- Dependencies: 279
-- Data for Name: ml_model_performance; Type: TABLE DATA; Schema: ml_models; Owner: postgres
--

pg_dump: processing data for table "ml_models.ml_model_performance"
COPY ml_models.ml_model_performance (model_id, model_version_id, evaluation_date, evaluation_period, accuracy, "precision", recall, f1_score, auc_roc, confidence_calibration, brier_score, total_predictions, correct_predictions, detailed_metrics, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "ml_models.ml_model_performance"
\.


--
-- TOC entry 4509 (class 0 OID 22389)
-- Dependencies: 269
-- Data for Name: ml_model_versions; Type: TABLE DATA; Schema: ml_models; Owner: postgres
--

pg_dump: processing data for table "ml_models.ml_model_versions"
COPY ml_models.ml_model_versions (model_id, version, version_notes, parameters, model_artifact_path, training_data_hash, training_data_size, is_production, deployed_at, deprecated_at, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "ml_models.ml_model_versions"
\.


--
-- TOC entry 4490 (class 0 OID 21985)
-- Dependencies: 250
-- Data for Name: ml_models; Type: TABLE DATA; Schema: ml_models; Owner: postgres
--

pg_dump: processing data for table "ml_models.ml_models"
COPY ml_models.ml_models (model_name, model_version, model_type, description, model_status, is_champion, is_deployed, framework, framework_version, hyperparameters, s3_model_path, s3_checkpoint_path, model_size_bytes, training_accuracy, validation_accuracy, test_accuracy, created_by_user_id, model_metadata, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "ml_models.ml_models"
\.


--
-- TOC entry 4510 (class 0 OID 22406)
-- Dependencies: 270
-- Data for Name: ml_predictions; Type: TABLE DATA; Schema: ml_models; Owner: postgres
--

pg_dump: processing data for table "ml_models.ml_predictions"
COPY ml_models.ml_predictions (model_id, match_id, home_win_prob, draw_prob, away_win_prob, confidence_score, prediction_quality_score, features_used, feature_importance, was_overridden, overridden_by_expert_id, override_reason, model_version, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "ml_models.ml_predictions"
\.


--
-- TOC entry 4520 (class 0 OID 22609)
-- Dependencies: 280
-- Data for Name: ml_training_runs; Type: TABLE DATA; Schema: ml_models; Owner: postgres
--

pg_dump: processing data for table "ml_models.ml_training_runs"
COPY ml_models.ml_training_runs (model_id, model_version_id, training_job_id, status, started_at, completed_at, duration_seconds, training_parameters, training_data_size, validation_data_size, test_data_size, final_metrics, best_epoch, total_epochs, error_message, error_traceback, triggered_by_user_id, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "ml_models.ml_training_runs"
\.


--
-- TOC entry 4473 (class 0 OID 21615)
-- Dependencies: 233
-- Data for Name: leagues; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.leagues"
COPY predictions.leagues (name, display_name, country, country_code, logo_url, tier, external_api_id, external_api_source, is_active, league_metadata, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.leagues"
\.


--
-- TOC entry 4511 (class 0 OID 22432)
-- Dependencies: 271
-- Data for Name: match_results; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.match_results"
COPY predictions.match_results (match_id, home_score, away_score, home_score_ht, away_score_ht, result, home_corners, away_corners, home_yellow_cards, away_yellow_cards, home_red_cards, away_red_cards, result_metadata, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.match_results"
\.


--
-- TOC entry 4512 (class 0 OID 22447)
-- Dependencies: 272
-- Data for Name: match_statistics; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.match_statistics"
COPY predictions.match_statistics (match_id, stat_type, stat_category, home_value, away_value, stat_metadata, recorded_at, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.match_statistics"
\.


--
-- TOC entry 4491 (class 0 OID 22013)
-- Dependencies: 251
-- Data for Name: matches; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.matches"
COPY predictions.matches (home_team_id, away_team_id, league_id, match_date, venue, season, round, status, external_api_id, external_api_source, match_metadata, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.matches"
\.


--
-- TOC entry 4523 (class 0 OID 22720)
-- Dependencies: 283
-- Data for Name: prediction_analytics; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.prediction_analytics"
COPY predictions.prediction_analytics (prediction_id, view_count, unique_viewers, share_count, comment_count, upvote_count, downvote_count, average_rating, total_ratings, accuracy_score, roi_percentage, engagement_score, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.prediction_analytics"
\.


--
-- TOC entry 4524 (class 0 OID 22733)
-- Dependencies: 284
-- Data for Name: prediction_audit; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.prediction_audit"
COPY predictions.prediction_audit (prediction_id, user_id, action, action_description, old_values, new_values, changes_summary, ip_address, user_agent, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.prediction_audit"
\.


--
-- TOC entry 4525 (class 0 OID 22754)
-- Dependencies: 285
-- Data for Name: prediction_comments; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.prediction_comments"
COPY predictions.prediction_comments (prediction_id, user_id, parent_comment_id, comment_text, is_flagged, is_approved, id, created_at, updated_at, deleted_at) FROM stdin;
pg_dump: dumping contents of table "predictions.prediction_comments"
\.


--
-- TOC entry 4526 (class 0 OID 22791)
-- Dependencies: 286
-- Data for Name: prediction_markets; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.prediction_markets"
COPY predictions.prediction_markets (prediction_id, market_type, market_value, predicted_outcome, probability, confidence, recommended_odds, market_odds, is_primary, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.prediction_markets"
\.


--
-- TOC entry 4527 (class 0 OID 22803)
-- Dependencies: 287
-- Data for Name: prediction_overrides; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.prediction_overrides"
COPY predictions.prediction_overrides (prediction_id, expert_user_id, expert_profile_id, original_ml_prediction_id, original_probabilities, original_confidence, new_probabilities, new_confidence, override_reason, confidence_adjustment, key_insights, reviewed_by_admin_id, reviewed_at, review_notes, is_approved, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.prediction_overrides"
\.


--
-- TOC entry 4528 (class 0 OID 22851)
-- Dependencies: 288
-- Data for Name: prediction_results; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.prediction_results"
COPY predictions.prediction_results (prediction_id, match_result_id, outcome, is_correct, probability_accuracy, confidence_calibration, potential_return, actual_return, roi_percentage, settled_at, settled_by_system, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.prediction_results"
\.


--
-- TOC entry 4529 (class 0 OID 22871)
-- Dependencies: 289
-- Data for Name: prediction_shares; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.prediction_shares"
COPY predictions.prediction_shares (prediction_id, user_id, platform, share_url, ip_address, user_agent, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.prediction_shares"
\.


--
-- TOC entry 4492 (class 0 OID 22043)
-- Dependencies: 252
-- Data for Name: prediction_templates; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.prediction_templates"
COPY predictions.prediction_templates (name, description, created_by, template_data, is_active, is_public, usage_count, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.prediction_templates"
\.


--
-- TOC entry 4521 (class 0 OID 22659)
-- Dependencies: 281
-- Data for Name: predictions; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.predictions"
COPY predictions.predictions (match_id, source, created_by, ml_prediction_id, expert_profile_id, home_win_prob, draw_prob, away_win_prob, confidence_score, reasoning, key_factors, status, approved_by, approved_at, published_at, prediction_metadata, id, created_at, updated_at, deleted_at) FROM stdin;
pg_dump: dumping contents of table "predictions.predictions"
\.


--
-- TOC entry 4474 (class 0 OID 21627)
-- Dependencies: 234
-- Data for Name: teams; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.teams"
COPY predictions.teams (name, short_name, code, country, logo_url, founded_year, venue_name, venue_capacity, external_api_id, external_api_source, is_active, team_metadata, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.teams"
\.


--
-- TOC entry 4530 (class 0 OID 22891)
-- Dependencies: 290
-- Data for Name: user_prediction_feedback; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.user_prediction_feedback"
COPY predictions.user_prediction_feedback (prediction_id, user_id, rating, is_upvote, is_downvote, comment, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.user_prediction_feedback"
\.


--
-- TOC entry 4531 (class 0 OID 22912)
-- Dependencies: 291
-- Data for Name: user_prediction_views; Type: TABLE DATA; Schema: predictions; Owner: postgres
--

pg_dump: processing data for table "predictions.user_prediction_views"
COPY predictions.user_prediction_views (prediction_id, user_id, session_id, view_duration_seconds, ip_address, user_agent, referrer, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "predictions.user_prediction_views"
\.


--
-- TOC entry 4464 (class 0 OID 17105)
-- Dependencies: 224
-- Data for Name: db_init_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

pg_dump: processing data for table "public.db_init_log"
COPY public.db_init_log (id, script_name, executed_at, status, message) FROM stdin;
pg_dump: dumping contents of table "public.db_init_log"
1	01-init-database.sql	2025-10-08 06:08:04.929132	success	Database schemas, extensions, and types created successfully
\.


--
-- TOC entry 4513 (class 0 OID 22461)
-- Dependencies: 273
-- Data for Name: admin_activity_log; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.admin_activity_log"
COPY users.admin_activity_log (admin_profile_id, action_type, action_description, target_resource_type, target_resource_id, action_details, changes_made, ip_address, user_agent, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.admin_activity_log"
\.


--
-- TOC entry 4514 (class 0 OID 22476)
-- Dependencies: 274
-- Data for Name: admin_permissions; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.admin_permissions"
COPY users.admin_permissions (admin_profile_id, permission_type, permission_scope, scope_constraints, is_active, granted_at, granted_by_admin_id, expires_at, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.admin_permissions"
\.


--
-- TOC entry 4493 (class 0 OID 22057)
-- Dependencies: 253
-- Data for Name: admin_profiles; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.admin_profiles"
COPY users.admin_profiles (user_id, department, job_title, is_super_admin, can_approve_predictions, can_manage_users, can_manage_experts, can_access_audit_logs, can_manage_system_settings, last_admin_action_at, total_actions_count, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.admin_profiles"
\.


--
-- TOC entry 4465 (class 0 OID 19928)
-- Dependencies: 225
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.alembic_version"
COPY users.alembic_version (version_num) FROM stdin;
pg_dump: dumping contents of table "users.alembic_version"
9b3c8646a52d
\.


--
-- TOC entry 4515 (class 0 OID 22495)
-- Dependencies: 275
-- Data for Name: expert_performance_metrics; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.expert_performance_metrics"
COPY users.expert_performance_metrics (expert_profile_id, period_start, period_end, period_type, total_predictions, correct_predictions, accuracy_rate, average_confidence, roi_percentage, detailed_metrics, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.expert_performance_metrics"
\.


--
-- TOC entry 4494 (class 0 OID 22071)
-- Dependencies: 254
-- Data for Name: expert_profiles; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.expert_profiles"
COPY users.expert_profiles (user_id, bio, expertise_areas, years_of_experience, is_verified, verified_at, verified_by_admin_id, total_predictions, correct_predictions, accuracy_score, average_confidence, roi_percentage, reputation_score, follower_count, performance_data, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.expert_profiles"
\.


--
-- TOC entry 4516 (class 0 OID 22509)
-- Dependencies: 276
-- Data for Name: expert_specialties; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.expert_specialties"
COPY users.expert_specialties (expert_profile_id, specialty_type, specialty_value, predictions_count, accuracy_rate, confidence_level, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.expert_specialties"
\.


--
-- TOC entry 4495 (class 0 OID 22093)
-- Dependencies: 255
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.password_reset_tokens"
COPY users.password_reset_tokens (user_id, token, expires_at, is_used, used_at, ip_address, user_agent, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.password_reset_tokens"
\.


--
-- TOC entry 4475 (class 0 OID 21639)
-- Dependencies: 235
-- Data for Name: permissions; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.permissions"
COPY users.permissions (name, display_name, description, resource_type, action, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.permissions"
\.


--
-- TOC entry 4496 (class 0 OID 22110)
-- Dependencies: 256
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.role_permissions"
COPY users.role_permissions (role_id, permission_id, granted_at, granted_by_admin_id, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.role_permissions"
\.


--
-- TOC entry 4476 (class 0 OID 21650)
-- Dependencies: 236
-- Data for Name: roles; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.roles"
COPY users.roles (name, display_name, description, is_active, is_system_role, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.roles"
\.


--
-- TOC entry 4497 (class 0 OID 22134)
-- Dependencies: 257
-- Data for Name: user_activity_log; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.user_activity_log"
COPY users.user_activity_log (user_id, activity_type, activity_description, activity_data, ip_address, user_agent, session_id, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.user_activity_log"
\.


--
-- TOC entry 4498 (class 0 OID 22161)
-- Dependencies: 258
-- Data for Name: user_notifications; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.user_notifications"
COPY users.user_notifications (user_id, notification_type, title, message, is_read, read_at, notification_data, action_url, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.user_notifications"
\.


--
-- TOC entry 4499 (class 0 OID 22176)
-- Dependencies: 259
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.user_preferences"
COPY users.user_preferences (user_id, email_notifications, push_notifications, sms_notifications, theme, odds_format, favorite_leagues, favorite_teams, favorite_experts, profile_visibility, show_prediction_history, additional_settings, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.user_preferences"
\.


--
-- TOC entry 4500 (class 0 OID 22191)
-- Dependencies: 260
-- Data for Name: user_roles; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.user_roles"
COPY users.user_roles (user_id, role_id, assigned_at, assigned_by_admin_id, expires_at, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.user_roles"
\.


--
-- TOC entry 4501 (class 0 OID 22215)
-- Dependencies: 261
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.user_sessions"
COPY users.user_sessions (user_id, refresh_token, access_token_jti, device_info, ip_address, user_agent, is_active, expires_at, last_activity_at, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.user_sessions"
\.


--
-- TOC entry 4502 (class 0 OID 22253)
-- Dependencies: 262
-- Data for Name: user_subscriptions; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.user_subscriptions"
COPY users.user_subscriptions (user_id, tier, status, stripe_subscription_id, stripe_customer_id, starts_at, expires_at, cancelled_at, trial_ends_at, price_amount, currency, billing_cycle, id, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "users.user_subscriptions"
\.


--
-- TOC entry 4477 (class 0 OID 21679)
-- Dependencies: 237
-- Data for Name: users; Type: TABLE DATA; Schema: users; Owner: postgres
--

pg_dump: processing data for table "users.users"
COPY users.users (email, username, password_hash, first_name, last_name, avatar_url, user_type, account_status, email_verified, email_verification_token, email_verified_at, password_reset_token, password_reset_expires_at, last_login_at, last_login_ip, timezone, language, id, created_at, updated_at, deleted_at) FROM stdin;
pg_dump: dumping contents of table "users.users"
\.


pg_dump: executing SEQUENCE SET db_init_log_id_seq
--
-- TOC entry 4970 (class 0 OID 0)
-- Dependencies: 223
-- Name: db_init_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.db_init_log_id_seq', 1, true);


pg_dump: creating CONSTRAINT "analytics.api_usage_analytics api_usage_analytics_pkey"
--
-- TOC entry 3923 (class 2606 OID 21701)
-- Name: api_usage_analytics api_usage_analytics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.api_usage_analytics
    ADD CONSTRAINT api_usage_analytics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "analytics.conversion_analytics conversion_analytics_pkey"
--
-- TOC entry 3853 (class 2606 OID 21553)
-- Name: conversion_analytics conversion_analytics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.conversion_analytics
    ADD CONSTRAINT conversion_analytics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "analytics.error_analytics error_analytics_pkey"
--
-- TOC entry 3857 (class 2606 OID 21562)
-- Name: error_analytics error_analytics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.error_analytics
    ADD CONSTRAINT error_analytics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "analytics.expert_analytics expert_analytics_pkey"
--
-- TOC entry 4075 (class 2606 OID 22276)
-- Name: expert_analytics expert_analytics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.expert_analytics
    ADD CONSTRAINT expert_analytics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "analytics.feature_usage_analytics feature_usage_analytics_pkey"
--
-- TOC entry 3862 (class 2606 OID 21572)
-- Name: feature_usage_analytics feature_usage_analytics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.feature_usage_analytics
    ADD CONSTRAINT feature_usage_analytics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "analytics.model_performance_analytics model_performance_analytics_pkey"
--
-- TOC entry 4082 (class 2606 OID 22291)
-- Name: model_performance_analytics model_performance_analytics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.model_performance_analytics
    ADD CONSTRAINT model_performance_analytics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "analytics.prediction_analytics_summary prediction_analytics_summary_pkey"
--
-- TOC entry 3868 (class 2606 OID 21581)
-- Name: prediction_analytics_summary prediction_analytics_summary_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.prediction_analytics_summary
    ADD CONSTRAINT prediction_analytics_summary_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "analytics.prediction_performance_metrics prediction_performance_metrics_pkey"
--
-- TOC entry 3931 (class 2606 OID 21716)
-- Name: prediction_performance_metrics prediction_performance_metrics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.prediction_performance_metrics
    ADD CONSTRAINT prediction_performance_metrics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "analytics.revenue_analytics revenue_analytics_pkey"
--
-- TOC entry 3873 (class 2606 OID 21590)
-- Name: revenue_analytics revenue_analytics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.revenue_analytics
    ADD CONSTRAINT revenue_analytics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "analytics.system_analytics system_analytics_pkey"
--
-- TOC entry 3877 (class 2606 OID 21600)
-- Name: system_analytics system_analytics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.system_analytics
    ADD CONSTRAINT system_analytics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "analytics.user_activity_log user_activity_log_pkey"
--
-- TOC entry 3936 (class 2606 OID 21731)
-- Name: user_activity_log user_activity_log_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.user_activity_log
    ADD CONSTRAINT user_activity_log_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "analytics.user_analytics user_analytics_pkey"
--
-- TOC entry 3941 (class 2606 OID 21755)
-- Name: user_analytics user_analytics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.user_analytics
    ADD CONSTRAINT user_analytics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "analytics.user_engagement_metrics user_engagement_metrics_pkey"
--
-- TOC entry 3946 (class 2606 OID 21770)
-- Name: user_engagement_metrics user_engagement_metrics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.user_engagement_metrics
    ADD CONSTRAINT user_engagement_metrics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "audit.admin_action_log admin_action_log_pkey"
--
-- TOC entry 4084 (class 2606 OID 22305)
-- Name: admin_action_log admin_action_log_pkey; Type: CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.admin_action_log
    ADD CONSTRAINT admin_action_log_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "audit.audit_log audit_log_pkey"
--
-- TOC entry 3948 (class 2606 OID 21817)
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "audit.data_access_log data_access_log_pkey"
--
-- TOC entry 3957 (class 2606 OID 21836)
-- Name: data_access_log data_access_log_pkey; Type: CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.data_access_log
    ADD CONSTRAINT data_access_log_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "audit.data_export_log data_export_log_pkey"
--
-- TOC entry 3964 (class 2606 OID 21869)
-- Name: data_export_log data_export_log_pkey; Type: CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.data_export_log
    ADD CONSTRAINT data_export_log_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "audit.gdpr_consent_log gdpr_consent_log_pkey"
--
-- TOC entry 3970 (class 2606 OID 21897)
-- Name: gdpr_consent_log gdpr_consent_log_pkey; Type: CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.gdpr_consent_log
    ADD CONSTRAINT gdpr_consent_log_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "audit.prediction_change_log prediction_change_log_pkey"
--
-- TOC entry 4176 (class 2606 OID 22705)
-- Name: prediction_change_log prediction_change_log_pkey; Type: CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.prediction_change_log
    ADD CONSTRAINT prediction_change_log_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "audit.system_event_log system_event_log_pkey"
--
-- TOC entry 3980 (class 2606 OID 21913)
-- Name: system_event_log system_event_log_pkey; Type: CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.system_event_log
    ADD CONSTRAINT system_event_log_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "audit.user_action_log user_action_log_pkey"
--
-- TOC entry 3986 (class 2606 OID 21929)
-- Name: user_action_log user_action_log_pkey; Type: CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.user_action_log
    ADD CONSTRAINT user_action_log_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_ab_test_results ml_ab_test_results_pkey"
--
-- TOC entry 4146 (class 2606 OID 22527)
-- Name: ml_ab_test_results ml_ab_test_results_pkey; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_ab_test_results
    ADD CONSTRAINT ml_ab_test_results_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_ab_tests ml_ab_tests_pkey"
--
-- TOC entry 4094 (class 2606 OID 22336)
-- Name: ml_ab_tests ml_ab_tests_pkey; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_ab_tests
    ADD CONSTRAINT ml_ab_tests_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_ensemble_configs ml_ensemble_configs_pkey"
--
-- TOC entry 4098 (class 2606 OID 22367)
-- Name: ml_ensemble_configs ml_ensemble_configs_pkey; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_ensemble_configs
    ADD CONSTRAINT ml_ensemble_configs_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_feature_engineering ml_feature_engineering_pkey"
--
-- TOC entry 3990 (class 2606 OID 21945)
-- Name: ml_feature_engineering ml_feature_engineering_pkey; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_feature_engineering
    ADD CONSTRAINT ml_feature_engineering_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_features ml_features_feature_name_key"
--
-- TOC entry 3882 (class 2606 OID 21611)
-- Name: ml_features ml_features_feature_name_key; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_features
    ADD CONSTRAINT ml_features_feature_name_key UNIQUE (feature_name);


pg_dump: creating CONSTRAINT "ml_models.ml_features ml_features_pkey"
--
-- TOC entry 3884 (class 2606 OID 21609)
-- Name: ml_features ml_features_pkey; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_features
    ADD CONSTRAINT ml_features_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_model_deployments ml_model_deployments_pkey"
--
-- TOC entry 4151 (class 2606 OID 22559)
-- Name: ml_model_deployments ml_model_deployments_pkey; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_model_deployments
    ADD CONSTRAINT ml_model_deployments_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_model_metadata ml_model_metadata_pkey"
--
-- TOC entry 4102 (class 2606 OID 22381)
-- Name: ml_model_metadata ml_model_metadata_pkey; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_model_metadata
    ADD CONSTRAINT ml_model_metadata_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_model_performance ml_model_performance_pkey"
--
-- TOC entry 4155 (class 2606 OID 22584)
-- Name: ml_model_performance ml_model_performance_pkey; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_model_performance
    ADD CONSTRAINT ml_model_performance_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_model_versions ml_model_versions_pkey"
--
-- TOC entry 4107 (class 2606 OID 22395)
-- Name: ml_model_versions ml_model_versions_pkey; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_model_versions
    ADD CONSTRAINT ml_model_versions_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_models ml_models_pkey"
--
-- TOC entry 3997 (class 2606 OID 21991)
-- Name: ml_models ml_models_pkey; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_models
    ADD CONSTRAINT ml_models_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_predictions ml_predictions_pkey"
--
-- TOC entry 4115 (class 2606 OID 22412)
-- Name: ml_predictions ml_predictions_pkey; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_predictions
    ADD CONSTRAINT ml_predictions_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_training_runs ml_training_runs_pkey"
--
-- TOC entry 4160 (class 2606 OID 22615)
-- Name: ml_training_runs ml_training_runs_pkey; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_training_runs
    ADD CONSTRAINT ml_training_runs_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "ml_models.ml_training_runs ml_training_runs_training_job_id_key"
--
-- TOC entry 4162 (class 2606 OID 22617)
-- Name: ml_training_runs ml_training_runs_training_job_id_key; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_training_runs
    ADD CONSTRAINT ml_training_runs_training_job_id_key UNIQUE (training_job_id);


pg_dump: creating CONSTRAINT "ml_models.ml_model_versions uq_ml_model_versions_model_version"
--
-- TOC entry 4109 (class 2606 OID 22397)
-- Name: ml_model_versions uq_ml_model_versions_model_version; Type: CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_model_versions
    ADD CONSTRAINT uq_ml_model_versions_model_version UNIQUE (model_id, version);


pg_dump: creating CONSTRAINT "predictions.leagues leagues_external_api_id_key"
--
-- TOC entry 3889 (class 2606 OID 21623)
-- Name: leagues leagues_external_api_id_key; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.leagues
    ADD CONSTRAINT leagues_external_api_id_key UNIQUE (external_api_id);


pg_dump: creating CONSTRAINT "predictions.leagues leagues_pkey"
--
-- TOC entry 3891 (class 2606 OID 21621)
-- Name: leagues leagues_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.leagues
    ADD CONSTRAINT leagues_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.match_results match_results_match_id_key"
--
-- TOC entry 4118 (class 2606 OID 22440)
-- Name: match_results match_results_match_id_key; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.match_results
    ADD CONSTRAINT match_results_match_id_key UNIQUE (match_id);


pg_dump: creating CONSTRAINT "predictions.match_results match_results_pkey"
--
-- TOC entry 4120 (class 2606 OID 22438)
-- Name: match_results match_results_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.match_results
    ADD CONSTRAINT match_results_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.match_statistics match_statistics_pkey"
--
-- TOC entry 4124 (class 2606 OID 22453)
-- Name: match_statistics match_statistics_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.match_statistics
    ADD CONSTRAINT match_statistics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.matches matches_external_api_id_key"
--
-- TOC entry 4005 (class 2606 OID 22021)
-- Name: matches matches_external_api_id_key; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.matches
    ADD CONSTRAINT matches_external_api_id_key UNIQUE (external_api_id);


pg_dump: creating CONSTRAINT "predictions.matches matches_pkey"
--
-- TOC entry 4007 (class 2606 OID 22019)
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.prediction_analytics prediction_analytics_pkey"
--
-- TOC entry 4179 (class 2606 OID 22724)
-- Name: prediction_analytics prediction_analytics_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_analytics
    ADD CONSTRAINT prediction_analytics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.prediction_analytics prediction_analytics_prediction_id_key"
--
-- TOC entry 4181 (class 2606 OID 22726)
-- Name: prediction_analytics prediction_analytics_prediction_id_key; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_analytics
    ADD CONSTRAINT prediction_analytics_prediction_id_key UNIQUE (prediction_id);


pg_dump: creating CONSTRAINT "predictions.prediction_audit prediction_audit_pkey"
--
-- TOC entry 4187 (class 2606 OID 22739)
-- Name: prediction_audit prediction_audit_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_audit
    ADD CONSTRAINT prediction_audit_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.prediction_comments prediction_comments_pkey"
--
-- TOC entry 4192 (class 2606 OID 22760)
-- Name: prediction_comments prediction_comments_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_comments
    ADD CONSTRAINT prediction_comments_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.prediction_markets prediction_markets_pkey"
--
-- TOC entry 4196 (class 2606 OID 22795)
-- Name: prediction_markets prediction_markets_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_markets
    ADD CONSTRAINT prediction_markets_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.prediction_overrides prediction_overrides_pkey"
--
-- TOC entry 4201 (class 2606 OID 22809)
-- Name: prediction_overrides prediction_overrides_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_overrides
    ADD CONSTRAINT prediction_overrides_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.prediction_overrides prediction_overrides_prediction_id_key"
--
-- TOC entry 4203 (class 2606 OID 22811)
-- Name: prediction_overrides prediction_overrides_prediction_id_key; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_overrides
    ADD CONSTRAINT prediction_overrides_prediction_id_key UNIQUE (prediction_id);


pg_dump: creating CONSTRAINT "predictions.prediction_results prediction_results_pkey"
--
-- TOC entry 4208 (class 2606 OID 22855)
-- Name: prediction_results prediction_results_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_results
    ADD CONSTRAINT prediction_results_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.prediction_results prediction_results_prediction_id_key"
--
-- TOC entry 4210 (class 2606 OID 22857)
-- Name: prediction_results prediction_results_prediction_id_key; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_results
    ADD CONSTRAINT prediction_results_prediction_id_key UNIQUE (prediction_id);


pg_dump: creating CONSTRAINT "predictions.prediction_shares prediction_shares_pkey"
--
-- TOC entry 4215 (class 2606 OID 22877)
-- Name: prediction_shares prediction_shares_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_shares
    ADD CONSTRAINT prediction_shares_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.prediction_templates prediction_templates_pkey"
--
-- TOC entry 4011 (class 2606 OID 22049)
-- Name: prediction_templates prediction_templates_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_templates
    ADD CONSTRAINT prediction_templates_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.predictions predictions_pkey"
--
-- TOC entry 4170 (class 2606 OID 22667)
-- Name: predictions predictions_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.predictions
    ADD CONSTRAINT predictions_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.teams teams_external_api_id_key"
--
-- TOC entry 3896 (class 2606 OID 21635)
-- Name: teams teams_external_api_id_key; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.teams
    ADD CONSTRAINT teams_external_api_id_key UNIQUE (external_api_id);


pg_dump: creating CONSTRAINT "predictions.teams teams_pkey"
--
-- TOC entry 3898 (class 2606 OID 21633)
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.user_prediction_feedback uq_user_prediction_feedback"
--
-- TOC entry 4219 (class 2606 OID 22899)
-- Name: user_prediction_feedback uq_user_prediction_feedback; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.user_prediction_feedback
    ADD CONSTRAINT uq_user_prediction_feedback UNIQUE (prediction_id, user_id);


pg_dump: creating CONSTRAINT "predictions.user_prediction_feedback user_prediction_feedback_pkey"
--
-- TOC entry 4221 (class 2606 OID 22897)
-- Name: user_prediction_feedback user_prediction_feedback_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.user_prediction_feedback
    ADD CONSTRAINT user_prediction_feedback_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "predictions.user_prediction_views user_prediction_views_pkey"
--
-- TOC entry 4226 (class 2606 OID 22918)
-- Name: user_prediction_views user_prediction_views_pkey; Type: CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.user_prediction_views
    ADD CONSTRAINT user_prediction_views_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.db_init_log db_init_log_pkey"
--
-- TOC entry 3849 (class 2606 OID 17114)
-- Name: db_init_log db_init_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_init_log
    ADD CONSTRAINT db_init_log_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.admin_activity_log admin_activity_log_pkey"
--
-- TOC entry 4126 (class 2606 OID 22467)
-- Name: admin_activity_log admin_activity_log_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.admin_activity_log
    ADD CONSTRAINT admin_activity_log_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.admin_permissions admin_permissions_pkey"
--
-- TOC entry 4131 (class 2606 OID 22482)
-- Name: admin_permissions admin_permissions_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.admin_permissions
    ADD CONSTRAINT admin_permissions_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.admin_profiles admin_profiles_pkey"
--
-- TOC entry 4013 (class 2606 OID 22061)
-- Name: admin_profiles admin_profiles_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.admin_profiles
    ADD CONSTRAINT admin_profiles_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.admin_profiles admin_profiles_user_id_key"
--
-- TOC entry 4015 (class 2606 OID 22063)
-- Name: admin_profiles admin_profiles_user_id_key; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.admin_profiles
    ADD CONSTRAINT admin_profiles_user_id_key UNIQUE (user_id);


pg_dump: creating CONSTRAINT "users.alembic_version alembic_version_pkc"
--
-- TOC entry 3851 (class 2606 OID 19932)
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


pg_dump: creating CONSTRAINT "users.expert_performance_metrics expert_performance_metrics_pkey"
--
-- TOC entry 4135 (class 2606 OID 22501)
-- Name: expert_performance_metrics expert_performance_metrics_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.expert_performance_metrics
    ADD CONSTRAINT expert_performance_metrics_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.expert_profiles expert_profiles_pkey"
--
-- TOC entry 4019 (class 2606 OID 22077)
-- Name: expert_profiles expert_profiles_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.expert_profiles
    ADD CONSTRAINT expert_profiles_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.expert_profiles expert_profiles_user_id_key"
--
-- TOC entry 4021 (class 2606 OID 22079)
-- Name: expert_profiles expert_profiles_user_id_key; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.expert_profiles
    ADD CONSTRAINT expert_profiles_user_id_key UNIQUE (user_id);


pg_dump: creating CONSTRAINT "users.expert_specialties expert_specialties_pkey"
--
-- TOC entry 4139 (class 2606 OID 22513)
-- Name: expert_specialties expert_specialties_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.expert_specialties
    ADD CONSTRAINT expert_specialties_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.password_reset_tokens password_reset_tokens_pkey"
--
-- TOC entry 4029 (class 2606 OID 22099)
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.password_reset_tokens password_reset_tokens_token_key"
--
-- TOC entry 4031 (class 2606 OID 22101)
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


pg_dump: creating CONSTRAINT "users.permissions permissions_name_key"
--
-- TOC entry 3902 (class 2606 OID 21647)
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


pg_dump: creating CONSTRAINT "users.permissions permissions_pkey"
--
-- TOC entry 3904 (class 2606 OID 21645)
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.role_permissions role_permissions_pkey"
--
-- TOC entry 4035 (class 2606 OID 22114)
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.roles roles_name_key"
--
-- TOC entry 3908 (class 2606 OID 21658)
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


pg_dump: creating CONSTRAINT "users.roles roles_pkey"
--
-- TOC entry 3910 (class 2606 OID 21656)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.role_permissions uq_role_permissions_role_permission"
--
-- TOC entry 4037 (class 2606 OID 22116)
-- Name: role_permissions uq_role_permissions_role_permission; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.role_permissions
    ADD CONSTRAINT uq_role_permissions_role_permission UNIQUE (role_id, permission_id);


pg_dump: creating CONSTRAINT "users.user_roles uq_user_roles_user_role"
--
-- TOC entry 4056 (class 2606 OID 22197)
-- Name: user_roles uq_user_roles_user_role; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_roles
    ADD CONSTRAINT uq_user_roles_user_role UNIQUE (user_id, role_id);


pg_dump: creating CONSTRAINT "users.user_activity_log user_activity_log_pkey"
--
-- TOC entry 4042 (class 2606 OID 22140)
-- Name: user_activity_log user_activity_log_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_activity_log
    ADD CONSTRAINT user_activity_log_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.user_notifications user_notifications_pkey"
--
-- TOC entry 4047 (class 2606 OID 22167)
-- Name: user_notifications user_notifications_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_notifications
    ADD CONSTRAINT user_notifications_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.user_preferences user_preferences_pkey"
--
-- TOC entry 4050 (class 2606 OID 22182)
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.user_preferences user_preferences_user_id_key"
--
-- TOC entry 4052 (class 2606 OID 22184)
-- Name: user_preferences user_preferences_user_id_key; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_preferences
    ADD CONSTRAINT user_preferences_user_id_key UNIQUE (user_id);


pg_dump: creating CONSTRAINT "users.user_roles user_roles_pkey"
--
-- TOC entry 4058 (class 2606 OID 22195)
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.user_sessions user_sessions_pkey"
--
-- TOC entry 4064 (class 2606 OID 22221)
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.user_sessions user_sessions_refresh_token_key"
--
-- TOC entry 4066 (class 2606 OID 22223)
-- Name: user_sessions user_sessions_refresh_token_key; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_sessions
    ADD CONSTRAINT user_sessions_refresh_token_key UNIQUE (refresh_token);


pg_dump: creating CONSTRAINT "users.user_subscriptions user_subscriptions_pkey"
--
-- TOC entry 4071 (class 2606 OID 22259)
-- Name: user_subscriptions user_subscriptions_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_subscriptions
    ADD CONSTRAINT user_subscriptions_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.user_subscriptions user_subscriptions_stripe_subscription_id_key"
--
-- TOC entry 4073 (class 2606 OID 22261)
-- Name: user_subscriptions user_subscriptions_stripe_subscription_id_key; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_subscriptions
    ADD CONSTRAINT user_subscriptions_stripe_subscription_id_key UNIQUE (stripe_subscription_id);


pg_dump: creating CONSTRAINT "users.users users_email_key"
--
-- TOC entry 3917 (class 2606 OID 21687)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


pg_dump: creating CONSTRAINT "users.users users_pkey"
--
-- TOC entry 3919 (class 2606 OID 21685)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "users.users users_username_key"
--
-- TOC entry 3921 (class 2606 OID 21689)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


pg_dump: creating INDEX "analytics.idx_analytics_user_activity_log_activity_type"
--
-- TOC entry 3932 (class 1259 OID 21737)
-- Name: idx_analytics_user_activity_log_activity_type; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_analytics_user_activity_log_activity_type ON analytics.user_activity_log USING btree (activity_type);


pg_dump: creating INDEX "analytics.idx_analytics_user_activity_log_created_at"
--
-- TOC entry 3933 (class 1259 OID 21738)
-- Name: idx_analytics_user_activity_log_created_at; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_analytics_user_activity_log_created_at ON analytics.user_activity_log USING btree (created_at);


pg_dump: creating INDEX "analytics.idx_analytics_user_activity_log_user_id"
--
-- TOC entry 3934 (class 1259 OID 21739)
-- Name: idx_analytics_user_activity_log_user_id; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_analytics_user_activity_log_user_id ON analytics.user_activity_log USING btree (user_id);


pg_dump: creating INDEX "analytics.idx_api_usage_analytics_endpoint"
--
-- TOC entry 3924 (class 1259 OID 21707)
-- Name: idx_api_usage_analytics_endpoint; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_api_usage_analytics_endpoint ON analytics.api_usage_analytics USING btree (endpoint);


pg_dump: creating INDEX "analytics.idx_api_usage_analytics_period_start"
--
-- TOC entry 3925 (class 1259 OID 21708)
-- Name: idx_api_usage_analytics_period_start; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_api_usage_analytics_period_start ON analytics.api_usage_analytics USING btree (period_start);


pg_dump: creating INDEX "analytics.idx_api_usage_analytics_user_id"
--
-- TOC entry 3926 (class 1259 OID 21709)
-- Name: idx_api_usage_analytics_user_id; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_api_usage_analytics_user_id ON analytics.api_usage_analytics USING btree (user_id);


pg_dump: creating INDEX "analytics.idx_conversion_analytics_funnel_name"
--
-- TOC entry 3854 (class 1259 OID 21554)
-- Name: idx_conversion_analytics_funnel_name; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_conversion_analytics_funnel_name ON analytics.conversion_analytics USING btree (funnel_name);


pg_dump: creating INDEX "analytics.idx_conversion_analytics_period_start"
--
-- TOC entry 3855 (class 1259 OID 21555)
-- Name: idx_conversion_analytics_period_start; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_conversion_analytics_period_start ON analytics.conversion_analytics USING btree (period_start);


pg_dump: creating INDEX "analytics.idx_error_analytics_error_type"
--
-- TOC entry 3858 (class 1259 OID 21563)
-- Name: idx_error_analytics_error_type; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_error_analytics_error_type ON analytics.error_analytics USING btree (error_type);


pg_dump: creating INDEX "analytics.idx_error_analytics_period_start"
--
-- TOC entry 3859 (class 1259 OID 21564)
-- Name: idx_error_analytics_period_start; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_error_analytics_period_start ON analytics.error_analytics USING btree (period_start);


pg_dump: creating INDEX "analytics.idx_error_analytics_severity"
--
-- TOC entry 3860 (class 1259 OID 21565)
-- Name: idx_error_analytics_severity; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_error_analytics_severity ON analytics.error_analytics USING btree (severity);


pg_dump: creating INDEX "analytics.idx_expert_analytics_expert_profile_id"
--
-- TOC entry 4076 (class 1259 OID 22282)
-- Name: idx_expert_analytics_expert_profile_id; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_expert_analytics_expert_profile_id ON analytics.expert_analytics USING btree (expert_profile_id);


pg_dump: creating INDEX "analytics.idx_expert_analytics_period_start"
--
-- TOC entry 4077 (class 1259 OID 22283)
-- Name: idx_expert_analytics_period_start; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_expert_analytics_period_start ON analytics.expert_analytics USING btree (period_start);


pg_dump: creating INDEX "analytics.idx_expert_analytics_period_type"
--
-- TOC entry 4078 (class 1259 OID 22284)
-- Name: idx_expert_analytics_period_type; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_expert_analytics_period_type ON analytics.expert_analytics USING btree (period_type);


pg_dump: creating INDEX "analytics.idx_feature_usage_analytics_feature_name"
--
-- TOC entry 3863 (class 1259 OID 21573)
-- Name: idx_feature_usage_analytics_feature_name; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_feature_usage_analytics_feature_name ON analytics.feature_usage_analytics USING btree (feature_name);


pg_dump: creating INDEX "analytics.idx_feature_usage_analytics_period_start"
--
-- TOC entry 3864 (class 1259 OID 21574)
-- Name: idx_feature_usage_analytics_period_start; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_feature_usage_analytics_period_start ON analytics.feature_usage_analytics USING btree (period_start);


pg_dump: creating INDEX "analytics.idx_model_performance_analytics_model_id"
--
-- TOC entry 4079 (class 1259 OID 22297)
-- Name: idx_model_performance_analytics_model_id; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_model_performance_analytics_model_id ON analytics.model_performance_analytics USING btree (model_id);


pg_dump: creating INDEX "analytics.idx_model_performance_analytics_period_start"
--
-- TOC entry 4080 (class 1259 OID 22298)
-- Name: idx_model_performance_analytics_period_start; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_model_performance_analytics_period_start ON analytics.model_performance_analytics USING btree (period_start);


pg_dump: creating INDEX "analytics.idx_prediction_analytics_summary_period_start"
--
-- TOC entry 3865 (class 1259 OID 21582)
-- Name: idx_prediction_analytics_summary_period_start; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_prediction_analytics_summary_period_start ON analytics.prediction_analytics_summary USING btree (period_start);


pg_dump: creating INDEX "analytics.idx_prediction_analytics_summary_period_type"
--
-- TOC entry 3866 (class 1259 OID 21583)
-- Name: idx_prediction_analytics_summary_period_type; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_prediction_analytics_summary_period_type ON analytics.prediction_analytics_summary USING btree (period_type);


pg_dump: creating INDEX "analytics.idx_prediction_performance_metrics_league_id"
--
-- TOC entry 3927 (class 1259 OID 21722)
-- Name: idx_prediction_performance_metrics_league_id; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_prediction_performance_metrics_league_id ON analytics.prediction_performance_metrics USING btree (league_id);


pg_dump: creating INDEX "analytics.idx_prediction_performance_metrics_market_type"
--
-- TOC entry 3928 (class 1259 OID 21723)
-- Name: idx_prediction_performance_metrics_market_type; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_prediction_performance_metrics_market_type ON analytics.prediction_performance_metrics USING btree (market_type);


pg_dump: creating INDEX "analytics.idx_prediction_performance_metrics_metric_date"
--
-- TOC entry 3929 (class 1259 OID 21724)
-- Name: idx_prediction_performance_metrics_metric_date; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_prediction_performance_metrics_metric_date ON analytics.prediction_performance_metrics USING btree (metric_date);


pg_dump: creating INDEX "analytics.idx_revenue_analytics_period_start"
--
-- TOC entry 3869 (class 1259 OID 21591)
-- Name: idx_revenue_analytics_period_start; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_revenue_analytics_period_start ON analytics.revenue_analytics USING btree (period_start);


pg_dump: creating INDEX "analytics.idx_revenue_analytics_period_type"
--
-- TOC entry 3870 (class 1259 OID 21592)
-- Name: idx_revenue_analytics_period_type; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_revenue_analytics_period_type ON analytics.revenue_analytics USING btree (period_type);


pg_dump: creating INDEX "analytics.idx_revenue_analytics_subscription_tier"
--
-- TOC entry 3871 (class 1259 OID 21593)
-- Name: idx_revenue_analytics_subscription_tier; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_revenue_analytics_subscription_tier ON analytics.revenue_analytics USING btree (subscription_tier);


pg_dump: creating INDEX "analytics.idx_system_analytics_period_start"
--
-- TOC entry 3874 (class 1259 OID 21601)
-- Name: idx_system_analytics_period_start; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_system_analytics_period_start ON analytics.system_analytics USING btree (period_start);


pg_dump: creating INDEX "analytics.idx_system_analytics_period_type"
--
-- TOC entry 3875 (class 1259 OID 21602)
-- Name: idx_system_analytics_period_type; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_system_analytics_period_type ON analytics.system_analytics USING btree (period_type);


pg_dump: creating INDEX "analytics.idx_user_analytics_period_start"
--
-- TOC entry 3937 (class 1259 OID 21761)
-- Name: idx_user_analytics_period_start; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_user_analytics_period_start ON analytics.user_analytics USING btree (period_start);


pg_dump: creating INDEX "analytics.idx_user_analytics_period_type"
--
-- TOC entry 3938 (class 1259 OID 21762)
-- Name: idx_user_analytics_period_type; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_user_analytics_period_type ON analytics.user_analytics USING btree (period_type);


pg_dump: creating INDEX "analytics.idx_user_analytics_user_id"
--
-- TOC entry 3939 (class 1259 OID 21763)
-- Name: idx_user_analytics_user_id; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_user_analytics_user_id ON analytics.user_analytics USING btree (user_id);


pg_dump: creating INDEX "analytics.idx_user_engagement_metrics_metric_date"
--
-- TOC entry 3942 (class 1259 OID 21776)
-- Name: idx_user_engagement_metrics_metric_date; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_user_engagement_metrics_metric_date ON analytics.user_engagement_metrics USING btree (metric_date);


pg_dump: creating INDEX "analytics.idx_user_engagement_metrics_metric_type"
--
-- TOC entry 3943 (class 1259 OID 21777)
-- Name: idx_user_engagement_metrics_metric_type; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_user_engagement_metrics_metric_type ON analytics.user_engagement_metrics USING btree (metric_type);


pg_dump: creating INDEX "analytics.idx_user_engagement_metrics_user_id"
--
-- TOC entry 3944 (class 1259 OID 21778)
-- Name: idx_user_engagement_metrics_user_id; Type: INDEX; Schema: analytics; Owner: postgres
--

CREATE INDEX idx_user_engagement_metrics_user_id ON analytics.user_engagement_metrics USING btree (user_id);


pg_dump: creating INDEX "audit.idx_admin_action_log_action_type"
--
-- TOC entry 4085 (class 1259 OID 22326)
-- Name: idx_admin_action_log_action_type; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_admin_action_log_action_type ON audit.admin_action_log USING btree (action_type);


pg_dump: creating INDEX "audit.idx_admin_action_log_admin_user_id"
--
-- TOC entry 4086 (class 1259 OID 22327)
-- Name: idx_admin_action_log_admin_user_id; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_admin_action_log_admin_user_id ON audit.admin_action_log USING btree (admin_user_id);


pg_dump: creating INDEX "audit.idx_admin_action_log_created_at"
--
-- TOC entry 4087 (class 1259 OID 22328)
-- Name: idx_admin_action_log_created_at; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_admin_action_log_created_at ON audit.admin_action_log USING btree (created_at);


pg_dump: creating INDEX "audit.idx_admin_action_log_target_user_id"
--
-- TOC entry 4088 (class 1259 OID 22329)
-- Name: idx_admin_action_log_target_user_id; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_admin_action_log_target_user_id ON audit.admin_action_log USING btree (target_user_id);


pg_dump: creating INDEX "audit.idx_audit_log_action"
--
-- TOC entry 3949 (class 1259 OID 21823)
-- Name: idx_audit_log_action; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_audit_log_action ON audit.audit_log USING btree (action);


pg_dump: creating INDEX "audit.idx_audit_log_created_at"
--
-- TOC entry 3950 (class 1259 OID 21824)
-- Name: idx_audit_log_created_at; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_audit_log_created_at ON audit.audit_log USING btree (created_at);


pg_dump: creating INDEX "audit.idx_audit_log_ip_address"
--
-- TOC entry 3951 (class 1259 OID 21825)
-- Name: idx_audit_log_ip_address; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_audit_log_ip_address ON audit.audit_log USING btree (ip_address);


pg_dump: creating INDEX "audit.idx_audit_log_resource_id"
--
-- TOC entry 3952 (class 1259 OID 21826)
-- Name: idx_audit_log_resource_id; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_audit_log_resource_id ON audit.audit_log USING btree (resource_id);


pg_dump: creating INDEX "audit.idx_audit_log_resource_type"
--
-- TOC entry 3953 (class 1259 OID 21827)
-- Name: idx_audit_log_resource_type; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_audit_log_resource_type ON audit.audit_log USING btree (resource_type);


pg_dump: creating INDEX "audit.idx_audit_log_severity"
--
-- TOC entry 3954 (class 1259 OID 21828)
-- Name: idx_audit_log_severity; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_audit_log_severity ON audit.audit_log USING btree (severity);


pg_dump: creating INDEX "audit.idx_audit_log_user_id"
--
-- TOC entry 3955 (class 1259 OID 21829)
-- Name: idx_audit_log_user_id; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_audit_log_user_id ON audit.audit_log USING btree (user_id);


pg_dump: creating INDEX "audit.idx_data_access_log_accessed_user_id"
--
-- TOC entry 3958 (class 1259 OID 21847)
-- Name: idx_data_access_log_accessed_user_id; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_data_access_log_accessed_user_id ON audit.data_access_log USING btree (accessed_user_id);


pg_dump: creating INDEX "audit.idx_data_access_log_created_at"
--
-- TOC entry 3959 (class 1259 OID 21848)
-- Name: idx_data_access_log_created_at; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_data_access_log_created_at ON audit.data_access_log USING btree (created_at);


pg_dump: creating INDEX "audit.idx_data_access_log_data_type"
--
-- TOC entry 3960 (class 1259 OID 21849)
-- Name: idx_data_access_log_data_type; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_data_access_log_data_type ON audit.data_access_log USING btree (data_type);


pg_dump: creating INDEX "audit.idx_data_access_log_is_authorized"
--
-- TOC entry 3961 (class 1259 OID 21850)
-- Name: idx_data_access_log_is_authorized; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_data_access_log_is_authorized ON audit.data_access_log USING btree (is_authorized);


pg_dump: creating INDEX "audit.idx_data_access_log_user_id"
--
-- TOC entry 3962 (class 1259 OID 21851)
-- Name: idx_data_access_log_user_id; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_data_access_log_user_id ON audit.data_access_log USING btree (user_id);


pg_dump: creating INDEX "audit.idx_data_export_log_created_at"
--
-- TOC entry 3965 (class 1259 OID 21875)
-- Name: idx_data_export_log_created_at; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_data_export_log_created_at ON audit.data_export_log USING btree (created_at);


pg_dump: creating INDEX "audit.idx_data_export_log_expires_at"
--
-- TOC entry 3966 (class 1259 OID 21876)
-- Name: idx_data_export_log_expires_at; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_data_export_log_expires_at ON audit.data_export_log USING btree (expires_at);


pg_dump: creating INDEX "audit.idx_data_export_log_status"
--
-- TOC entry 3967 (class 1259 OID 21877)
-- Name: idx_data_export_log_status; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_data_export_log_status ON audit.data_export_log USING btree (status);


pg_dump: creating INDEX "audit.idx_data_export_log_user_id"
--
-- TOC entry 3968 (class 1259 OID 21878)
-- Name: idx_data_export_log_user_id; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_data_export_log_user_id ON audit.data_export_log USING btree (user_id);


pg_dump: creating INDEX "audit.idx_gdpr_consent_log_consent_type"
--
-- TOC entry 3971 (class 1259 OID 21903)
-- Name: idx_gdpr_consent_log_consent_type; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_gdpr_consent_log_consent_type ON audit.gdpr_consent_log USING btree (consent_type);


pg_dump: creating INDEX "audit.idx_gdpr_consent_log_created_at"
--
-- TOC entry 3972 (class 1259 OID 21904)
-- Name: idx_gdpr_consent_log_created_at; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_gdpr_consent_log_created_at ON audit.gdpr_consent_log USING btree (created_at);


pg_dump: creating INDEX "audit.idx_gdpr_consent_log_is_active"
--
-- TOC entry 3973 (class 1259 OID 21905)
-- Name: idx_gdpr_consent_log_is_active; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_gdpr_consent_log_is_active ON audit.gdpr_consent_log USING btree (is_active);


pg_dump: creating INDEX "audit.idx_gdpr_consent_log_user_id"
--
-- TOC entry 3974 (class 1259 OID 21906)
-- Name: idx_gdpr_consent_log_user_id; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_gdpr_consent_log_user_id ON audit.gdpr_consent_log USING btree (user_id);


pg_dump: creating INDEX "audit.idx_prediction_change_log_change_type"
--
-- TOC entry 4171 (class 1259 OID 22716)
-- Name: idx_prediction_change_log_change_type; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_prediction_change_log_change_type ON audit.prediction_change_log USING btree (change_type);


pg_dump: creating INDEX "audit.idx_prediction_change_log_changed_by"
--
-- TOC entry 4172 (class 1259 OID 22717)
-- Name: idx_prediction_change_log_changed_by; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_prediction_change_log_changed_by ON audit.prediction_change_log USING btree (changed_by);


pg_dump: creating INDEX "audit.idx_prediction_change_log_created_at"
--
-- TOC entry 4173 (class 1259 OID 22718)
-- Name: idx_prediction_change_log_created_at; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_prediction_change_log_created_at ON audit.prediction_change_log USING btree (created_at);


pg_dump: creating INDEX "audit.idx_prediction_change_log_prediction_id"
--
-- TOC entry 4174 (class 1259 OID 22719)
-- Name: idx_prediction_change_log_prediction_id; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_prediction_change_log_prediction_id ON audit.prediction_change_log USING btree (prediction_id);


pg_dump: creating INDEX "audit.idx_system_event_log_created_at"
--
-- TOC entry 3975 (class 1259 OID 21919)
-- Name: idx_system_event_log_created_at; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_system_event_log_created_at ON audit.system_event_log USING btree (created_at);


pg_dump: creating INDEX "audit.idx_system_event_log_event_type"
--
-- TOC entry 3976 (class 1259 OID 21920)
-- Name: idx_system_event_log_event_type; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_system_event_log_event_type ON audit.system_event_log USING btree (event_type);


pg_dump: creating INDEX "audit.idx_system_event_log_is_resolved"
--
-- TOC entry 3977 (class 1259 OID 21921)
-- Name: idx_system_event_log_is_resolved; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_system_event_log_is_resolved ON audit.system_event_log USING btree (is_resolved);


pg_dump: creating INDEX "audit.idx_system_event_log_severity"
--
-- TOC entry 3978 (class 1259 OID 21922)
-- Name: idx_system_event_log_severity; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_system_event_log_severity ON audit.system_event_log USING btree (severity);


pg_dump: creating INDEX "audit.idx_user_action_log_action_type"
--
-- TOC entry 3981 (class 1259 OID 21935)
-- Name: idx_user_action_log_action_type; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_user_action_log_action_type ON audit.user_action_log USING btree (action_type);


pg_dump: creating INDEX "audit.idx_user_action_log_created_at"
--
-- TOC entry 3982 (class 1259 OID 21936)
-- Name: idx_user_action_log_created_at; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_user_action_log_created_at ON audit.user_action_log USING btree (created_at);


pg_dump: creating INDEX "audit.idx_user_action_log_is_suspicious"
--
-- TOC entry 3983 (class 1259 OID 21937)
-- Name: idx_user_action_log_is_suspicious; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_user_action_log_is_suspicious ON audit.user_action_log USING btree (is_suspicious);


pg_dump: creating INDEX "audit.idx_user_action_log_user_id"
--
-- TOC entry 3984 (class 1259 OID 21938)
-- Name: idx_user_action_log_user_id; Type: INDEX; Schema: audit; Owner: postgres
--

CREATE INDEX idx_user_action_log_user_id ON audit.user_action_log USING btree (user_id);


pg_dump: creating INDEX "ml_models.idx_ml_ab_test_results_ab_test_id"
--
-- TOC entry 4142 (class 1259 OID 22538)
-- Name: idx_ml_ab_test_results_ab_test_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_ab_test_results_ab_test_id ON ml_models.ml_ab_test_results USING btree (ab_test_id);


pg_dump: creating INDEX "ml_models.idx_ml_ab_test_results_evaluation_date"
--
-- TOC entry 4143 (class 1259 OID 22539)
-- Name: idx_ml_ab_test_results_evaluation_date; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_ab_test_results_evaluation_date ON ml_models.ml_ab_test_results USING btree (evaluation_date);


pg_dump: creating INDEX "ml_models.idx_ml_ab_test_results_model_id"
--
-- TOC entry 4144 (class 1259 OID 22540)
-- Name: idx_ml_ab_test_results_model_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_ab_test_results_model_id ON ml_models.ml_ab_test_results USING btree (model_id);


pg_dump: creating INDEX "ml_models.idx_ml_ab_tests_is_active"
--
-- TOC entry 4089 (class 1259 OID 22357)
-- Name: idx_ml_ab_tests_is_active; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_ab_tests_is_active ON ml_models.ml_ab_tests USING btree (is_active);


pg_dump: creating INDEX "ml_models.idx_ml_ab_tests_model_a_id"
--
-- TOC entry 4090 (class 1259 OID 22358)
-- Name: idx_ml_ab_tests_model_a_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_ab_tests_model_a_id ON ml_models.ml_ab_tests USING btree (model_a_id);


pg_dump: creating INDEX "ml_models.idx_ml_ab_tests_model_b_id"
--
-- TOC entry 4091 (class 1259 OID 22359)
-- Name: idx_ml_ab_tests_model_b_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_ab_tests_model_b_id ON ml_models.ml_ab_tests USING btree (model_b_id);


pg_dump: creating INDEX "ml_models.idx_ml_ab_tests_started_at"
--
-- TOC entry 4092 (class 1259 OID 22360)
-- Name: idx_ml_ab_tests_started_at; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_ab_tests_started_at ON ml_models.ml_ab_tests USING btree (started_at);


pg_dump: creating INDEX "ml_models.idx_ml_ensemble_configs_ensemble_model_id"
--
-- TOC entry 4095 (class 1259 OID 22373)
-- Name: idx_ml_ensemble_configs_ensemble_model_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_ensemble_configs_ensemble_model_id ON ml_models.ml_ensemble_configs USING btree (ensemble_model_id);


pg_dump: creating INDEX "ml_models.idx_ml_ensemble_configs_is_active"
--
-- TOC entry 4096 (class 1259 OID 22374)
-- Name: idx_ml_ensemble_configs_is_active; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_ensemble_configs_is_active ON ml_models.ml_ensemble_configs USING btree (is_active);


pg_dump: creating INDEX "ml_models.idx_ml_feature_engineering_feature_id"
--
-- TOC entry 3987 (class 1259 OID 21956)
-- Name: idx_ml_feature_engineering_feature_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_feature_engineering_feature_id ON ml_models.ml_feature_engineering USING btree (feature_id);


pg_dump: creating INDEX "ml_models.idx_ml_feature_engineering_is_active"
--
-- TOC entry 3988 (class 1259 OID 21957)
-- Name: idx_ml_feature_engineering_is_active; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_feature_engineering_is_active ON ml_models.ml_feature_engineering USING btree (is_active);


pg_dump: creating INDEX "ml_models.idx_ml_features_feature_category"
--
-- TOC entry 3878 (class 1259 OID 21612)
-- Name: idx_ml_features_feature_category; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_features_feature_category ON ml_models.ml_features USING btree (feature_category);


pg_dump: creating INDEX "ml_models.idx_ml_features_feature_name"
--
-- TOC entry 3879 (class 1259 OID 21613)
-- Name: idx_ml_features_feature_name; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_features_feature_name ON ml_models.ml_features USING btree (feature_name);


pg_dump: creating INDEX "ml_models.idx_ml_features_is_active"
--
-- TOC entry 3880 (class 1259 OID 21614)
-- Name: idx_ml_features_is_active; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_features_is_active ON ml_models.ml_features USING btree (is_active);


pg_dump: creating INDEX "ml_models.idx_ml_model_deployments_deployed_at"
--
-- TOC entry 4147 (class 1259 OID 22575)
-- Name: idx_ml_model_deployments_deployed_at; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_model_deployments_deployed_at ON ml_models.ml_model_deployments USING btree (deployed_at);


pg_dump: creating INDEX "ml_models.idx_ml_model_deployments_model_id"
--
-- TOC entry 4148 (class 1259 OID 22576)
-- Name: idx_ml_model_deployments_model_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_model_deployments_model_id ON ml_models.ml_model_deployments USING btree (model_id);


pg_dump: creating INDEX "ml_models.idx_ml_model_deployments_status"
--
-- TOC entry 4149 (class 1259 OID 22577)
-- Name: idx_ml_model_deployments_status; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_model_deployments_status ON ml_models.ml_model_deployments USING btree (status);


pg_dump: creating INDEX "ml_models.idx_ml_model_metadata_metadata_key"
--
-- TOC entry 4099 (class 1259 OID 22387)
-- Name: idx_ml_model_metadata_metadata_key; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_model_metadata_metadata_key ON ml_models.ml_model_metadata USING btree (metadata_key);


pg_dump: creating INDEX "ml_models.idx_ml_model_metadata_model_id"
--
-- TOC entry 4100 (class 1259 OID 22388)
-- Name: idx_ml_model_metadata_model_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_model_metadata_model_id ON ml_models.ml_model_metadata USING btree (model_id);


pg_dump: creating INDEX "ml_models.idx_ml_model_performance_evaluation_date"
--
-- TOC entry 4152 (class 1259 OID 22595)
-- Name: idx_ml_model_performance_evaluation_date; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_model_performance_evaluation_date ON ml_models.ml_model_performance USING btree (evaluation_date);


pg_dump: creating INDEX "ml_models.idx_ml_model_performance_model_id"
--
-- TOC entry 4153 (class 1259 OID 22596)
-- Name: idx_ml_model_performance_model_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_model_performance_model_id ON ml_models.ml_model_performance USING btree (model_id);


pg_dump: creating INDEX "ml_models.idx_ml_model_versions_is_production"
--
-- TOC entry 4103 (class 1259 OID 22403)
-- Name: idx_ml_model_versions_is_production; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_model_versions_is_production ON ml_models.ml_model_versions USING btree (is_production);


pg_dump: creating INDEX "ml_models.idx_ml_model_versions_model_id"
--
-- TOC entry 4104 (class 1259 OID 22404)
-- Name: idx_ml_model_versions_model_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_model_versions_model_id ON ml_models.ml_model_versions USING btree (model_id);


pg_dump: creating INDEX "ml_models.idx_ml_model_versions_version"
--
-- TOC entry 4105 (class 1259 OID 22405)
-- Name: idx_ml_model_versions_version; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_model_versions_version ON ml_models.ml_model_versions USING btree (version);


pg_dump: creating INDEX "ml_models.idx_ml_models_is_champion"
--
-- TOC entry 3991 (class 1259 OID 21997)
-- Name: idx_ml_models_is_champion; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_models_is_champion ON ml_models.ml_models USING btree (is_champion);


pg_dump: creating INDEX "ml_models.idx_ml_models_is_deployed"
--
-- TOC entry 3992 (class 1259 OID 21998)
-- Name: idx_ml_models_is_deployed; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_models_is_deployed ON ml_models.ml_models USING btree (is_deployed);


pg_dump: creating INDEX "ml_models.idx_ml_models_model_name"
--
-- TOC entry 3993 (class 1259 OID 21999)
-- Name: idx_ml_models_model_name; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_models_model_name ON ml_models.ml_models USING btree (model_name);


pg_dump: creating INDEX "ml_models.idx_ml_models_model_status"
--
-- TOC entry 3994 (class 1259 OID 22000)
-- Name: idx_ml_models_model_status; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_models_model_status ON ml_models.ml_models USING btree (model_status);


pg_dump: creating INDEX "ml_models.idx_ml_models_model_type"
--
-- TOC entry 3995 (class 1259 OID 22001)
-- Name: idx_ml_models_model_type; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_models_model_type ON ml_models.ml_models USING btree (model_type);


pg_dump: creating INDEX "ml_models.idx_ml_predictions_created_at"
--
-- TOC entry 4110 (class 1259 OID 22428)
-- Name: idx_ml_predictions_created_at; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_predictions_created_at ON ml_models.ml_predictions USING btree (created_at);


pg_dump: creating INDEX "ml_models.idx_ml_predictions_match_id"
--
-- TOC entry 4111 (class 1259 OID 22429)
-- Name: idx_ml_predictions_match_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_predictions_match_id ON ml_models.ml_predictions USING btree (match_id);


pg_dump: creating INDEX "ml_models.idx_ml_predictions_model_id"
--
-- TOC entry 4112 (class 1259 OID 22430)
-- Name: idx_ml_predictions_model_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_predictions_model_id ON ml_models.ml_predictions USING btree (model_id);


pg_dump: creating INDEX "ml_models.idx_ml_predictions_was_overridden"
--
-- TOC entry 4113 (class 1259 OID 22431)
-- Name: idx_ml_predictions_was_overridden; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_predictions_was_overridden ON ml_models.ml_predictions USING btree (was_overridden);


pg_dump: creating INDEX "ml_models.idx_ml_training_runs_model_id"
--
-- TOC entry 4156 (class 1259 OID 22633)
-- Name: idx_ml_training_runs_model_id; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_training_runs_model_id ON ml_models.ml_training_runs USING btree (model_id);


pg_dump: creating INDEX "ml_models.idx_ml_training_runs_started_at"
--
-- TOC entry 4157 (class 1259 OID 22634)
-- Name: idx_ml_training_runs_started_at; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_training_runs_started_at ON ml_models.ml_training_runs USING btree (started_at);


pg_dump: creating INDEX "ml_models.idx_ml_training_runs_status"
--
-- TOC entry 4158 (class 1259 OID 22635)
-- Name: idx_ml_training_runs_status; Type: INDEX; Schema: ml_models; Owner: postgres
--

CREATE INDEX idx_ml_training_runs_status ON ml_models.ml_training_runs USING btree (status);


pg_dump: creating INDEX "predictions.idx_leagues_country"
--
-- TOC entry 3885 (class 1259 OID 21624)
-- Name: idx_leagues_country; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_leagues_country ON predictions.leagues USING btree (country);


pg_dump: creating INDEX "predictions.idx_leagues_external_api_id"
--
-- TOC entry 3886 (class 1259 OID 21625)
-- Name: idx_leagues_external_api_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_leagues_external_api_id ON predictions.leagues USING btree (external_api_id);


pg_dump: creating INDEX "predictions.idx_leagues_name"
--
-- TOC entry 3887 (class 1259 OID 21626)
-- Name: idx_leagues_name; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_leagues_name ON predictions.leagues USING btree (name);


pg_dump: creating INDEX "predictions.idx_match_results_match_id"
--
-- TOC entry 4116 (class 1259 OID 22446)
-- Name: idx_match_results_match_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_match_results_match_id ON predictions.match_results USING btree (match_id);


pg_dump: creating INDEX "predictions.idx_match_statistics_match_id"
--
-- TOC entry 4121 (class 1259 OID 22459)
-- Name: idx_match_statistics_match_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_match_statistics_match_id ON predictions.match_statistics USING btree (match_id);


pg_dump: creating INDEX "predictions.idx_match_statistics_stat_type"
--
-- TOC entry 4122 (class 1259 OID 22460)
-- Name: idx_match_statistics_stat_type; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_match_statistics_stat_type ON predictions.match_statistics USING btree (stat_type);


pg_dump: creating INDEX "predictions.idx_matches_away_team_id"
--
-- TOC entry 3998 (class 1259 OID 22037)
-- Name: idx_matches_away_team_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_matches_away_team_id ON predictions.matches USING btree (away_team_id);


pg_dump: creating INDEX "predictions.idx_matches_external_api_id"
--
-- TOC entry 3999 (class 1259 OID 22038)
-- Name: idx_matches_external_api_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_matches_external_api_id ON predictions.matches USING btree (external_api_id);


pg_dump: creating INDEX "predictions.idx_matches_home_team_id"
--
-- TOC entry 4000 (class 1259 OID 22039)
-- Name: idx_matches_home_team_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_matches_home_team_id ON predictions.matches USING btree (home_team_id);


pg_dump: creating INDEX "predictions.idx_matches_league_id"
--
-- TOC entry 4001 (class 1259 OID 22040)
-- Name: idx_matches_league_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_matches_league_id ON predictions.matches USING btree (league_id);


pg_dump: creating INDEX "predictions.idx_matches_match_date"
--
-- TOC entry 4002 (class 1259 OID 22041)
-- Name: idx_matches_match_date; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_matches_match_date ON predictions.matches USING btree (match_date);


pg_dump: creating INDEX "predictions.idx_matches_status"
--
-- TOC entry 4003 (class 1259 OID 22042)
-- Name: idx_matches_status; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_matches_status ON predictions.matches USING btree (status);


pg_dump: creating INDEX "predictions.idx_prediction_analytics_prediction_id"
--
-- TOC entry 4177 (class 1259 OID 22732)
-- Name: idx_prediction_analytics_prediction_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_analytics_prediction_id ON predictions.prediction_analytics USING btree (prediction_id);


pg_dump: creating INDEX "predictions.idx_prediction_audit_action"
--
-- TOC entry 4182 (class 1259 OID 22750)
-- Name: idx_prediction_audit_action; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_audit_action ON predictions.prediction_audit USING btree (action);


pg_dump: creating INDEX "predictions.idx_prediction_audit_created_at"
--
-- TOC entry 4183 (class 1259 OID 22751)
-- Name: idx_prediction_audit_created_at; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_audit_created_at ON predictions.prediction_audit USING btree (created_at);


pg_dump: creating INDEX "predictions.idx_prediction_audit_prediction_id"
--
-- TOC entry 4184 (class 1259 OID 22752)
-- Name: idx_prediction_audit_prediction_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_audit_prediction_id ON predictions.prediction_audit USING btree (prediction_id);


pg_dump: creating INDEX "predictions.idx_prediction_audit_user_id"
--
-- TOC entry 4185 (class 1259 OID 22753)
-- Name: idx_prediction_audit_user_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_audit_user_id ON predictions.prediction_audit USING btree (user_id);


pg_dump: creating INDEX "predictions.idx_prediction_comments_created_at"
--
-- TOC entry 4188 (class 1259 OID 22776)
-- Name: idx_prediction_comments_created_at; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_comments_created_at ON predictions.prediction_comments USING btree (created_at);


pg_dump: creating INDEX "predictions.idx_prediction_comments_prediction_id"
--
-- TOC entry 4189 (class 1259 OID 22777)
-- Name: idx_prediction_comments_prediction_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_comments_prediction_id ON predictions.prediction_comments USING btree (prediction_id);


pg_dump: creating INDEX "predictions.idx_prediction_comments_user_id"
--
-- TOC entry 4190 (class 1259 OID 22778)
-- Name: idx_prediction_comments_user_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_comments_user_id ON predictions.prediction_comments USING btree (user_id);


pg_dump: creating INDEX "predictions.idx_prediction_markets_market_type"
--
-- TOC entry 4193 (class 1259 OID 22801)
-- Name: idx_prediction_markets_market_type; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_markets_market_type ON predictions.prediction_markets USING btree (market_type);


pg_dump: creating INDEX "predictions.idx_prediction_markets_prediction_id"
--
-- TOC entry 4194 (class 1259 OID 22802)
-- Name: idx_prediction_markets_prediction_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_markets_prediction_id ON predictions.prediction_markets USING btree (prediction_id);


pg_dump: creating INDEX "predictions.idx_prediction_overrides_created_at"
--
-- TOC entry 4197 (class 1259 OID 22837)
-- Name: idx_prediction_overrides_created_at; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_overrides_created_at ON predictions.prediction_overrides USING btree (created_at);


pg_dump: creating INDEX "predictions.idx_prediction_overrides_expert_user_id"
--
-- TOC entry 4198 (class 1259 OID 22838)
-- Name: idx_prediction_overrides_expert_user_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_overrides_expert_user_id ON predictions.prediction_overrides USING btree (expert_user_id);


pg_dump: creating INDEX "predictions.idx_prediction_overrides_prediction_id"
--
-- TOC entry 4199 (class 1259 OID 22839)
-- Name: idx_prediction_overrides_prediction_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_overrides_prediction_id ON predictions.prediction_overrides USING btree (prediction_id);


pg_dump: creating INDEX "predictions.idx_prediction_results_outcome"
--
-- TOC entry 4204 (class 1259 OID 22868)
-- Name: idx_prediction_results_outcome; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_results_outcome ON predictions.prediction_results USING btree (outcome);


pg_dump: creating INDEX "predictions.idx_prediction_results_prediction_id"
--
-- TOC entry 4205 (class 1259 OID 22869)
-- Name: idx_prediction_results_prediction_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_results_prediction_id ON predictions.prediction_results USING btree (prediction_id);


pg_dump: creating INDEX "predictions.idx_prediction_results_settled_at"
--
-- TOC entry 4206 (class 1259 OID 22870)
-- Name: idx_prediction_results_settled_at; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_results_settled_at ON predictions.prediction_results USING btree (settled_at);


pg_dump: creating INDEX "predictions.idx_prediction_shares_platform"
--
-- TOC entry 4211 (class 1259 OID 22888)
-- Name: idx_prediction_shares_platform; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_shares_platform ON predictions.prediction_shares USING btree (platform);


pg_dump: creating INDEX "predictions.idx_prediction_shares_prediction_id"
--
-- TOC entry 4212 (class 1259 OID 22889)
-- Name: idx_prediction_shares_prediction_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_shares_prediction_id ON predictions.prediction_shares USING btree (prediction_id);


pg_dump: creating INDEX "predictions.idx_prediction_shares_user_id"
--
-- TOC entry 4213 (class 1259 OID 22890)
-- Name: idx_prediction_shares_user_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_shares_user_id ON predictions.prediction_shares USING btree (user_id);


pg_dump: creating INDEX "predictions.idx_prediction_templates_created_by"
--
-- TOC entry 4008 (class 1259 OID 22055)
-- Name: idx_prediction_templates_created_by; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_templates_created_by ON predictions.prediction_templates USING btree (created_by);


pg_dump: creating INDEX "predictions.idx_prediction_templates_is_active"
--
-- TOC entry 4009 (class 1259 OID 22056)
-- Name: idx_prediction_templates_is_active; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_prediction_templates_is_active ON predictions.prediction_templates USING btree (is_active);


pg_dump: creating INDEX "predictions.idx_predictions_created_at"
--
-- TOC entry 4163 (class 1259 OID 22693)
-- Name: idx_predictions_created_at; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_predictions_created_at ON predictions.predictions USING btree (created_at);


pg_dump: creating INDEX "predictions.idx_predictions_created_by"
--
-- TOC entry 4164 (class 1259 OID 22694)
-- Name: idx_predictions_created_by; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_predictions_created_by ON predictions.predictions USING btree (created_by);


pg_dump: creating INDEX "predictions.idx_predictions_match_id"
--
-- TOC entry 4165 (class 1259 OID 22695)
-- Name: idx_predictions_match_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_predictions_match_id ON predictions.predictions USING btree (match_id);


pg_dump: creating INDEX "predictions.idx_predictions_published_at"
--
-- TOC entry 4166 (class 1259 OID 22696)
-- Name: idx_predictions_published_at; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_predictions_published_at ON predictions.predictions USING btree (published_at);


pg_dump: creating INDEX "predictions.idx_predictions_source"
--
-- TOC entry 4167 (class 1259 OID 22697)
-- Name: idx_predictions_source; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_predictions_source ON predictions.predictions USING btree (source);


pg_dump: creating INDEX "predictions.idx_predictions_status"
--
-- TOC entry 4168 (class 1259 OID 22698)
-- Name: idx_predictions_status; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_predictions_status ON predictions.predictions USING btree (status);


pg_dump: creating INDEX "predictions.idx_teams_country"
--
-- TOC entry 3892 (class 1259 OID 21636)
-- Name: idx_teams_country; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_teams_country ON predictions.teams USING btree (country);


pg_dump: creating INDEX "predictions.idx_teams_external_api_id"
--
-- TOC entry 3893 (class 1259 OID 21637)
-- Name: idx_teams_external_api_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_teams_external_api_id ON predictions.teams USING btree (external_api_id);


pg_dump: creating INDEX "predictions.idx_teams_name"
--
-- TOC entry 3894 (class 1259 OID 21638)
-- Name: idx_teams_name; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_teams_name ON predictions.teams USING btree (name);


pg_dump: creating INDEX "predictions.idx_user_prediction_feedback_prediction_id"
--
-- TOC entry 4216 (class 1259 OID 22910)
-- Name: idx_user_prediction_feedback_prediction_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_user_prediction_feedback_prediction_id ON predictions.user_prediction_feedback USING btree (prediction_id);


pg_dump: creating INDEX "predictions.idx_user_prediction_feedback_user_id"
--
-- TOC entry 4217 (class 1259 OID 22911)
-- Name: idx_user_prediction_feedback_user_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_user_prediction_feedback_user_id ON predictions.user_prediction_feedback USING btree (user_id);


pg_dump: creating INDEX "predictions.idx_user_prediction_views_created_at"
--
-- TOC entry 4222 (class 1259 OID 22929)
-- Name: idx_user_prediction_views_created_at; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_user_prediction_views_created_at ON predictions.user_prediction_views USING btree (created_at);


pg_dump: creating INDEX "predictions.idx_user_prediction_views_prediction_id"
--
-- TOC entry 4223 (class 1259 OID 22930)
-- Name: idx_user_prediction_views_prediction_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_user_prediction_views_prediction_id ON predictions.user_prediction_views USING btree (prediction_id);


pg_dump: creating INDEX "predictions.idx_user_prediction_views_user_id"
--
-- TOC entry 4224 (class 1259 OID 22931)
-- Name: idx_user_prediction_views_user_id; Type: INDEX; Schema: predictions; Owner: postgres
--

CREATE INDEX idx_user_prediction_views_user_id ON predictions.user_prediction_views USING btree (user_id);


pg_dump: creating INDEX "users.idx_admin_activity_log_action_type"
--
-- TOC entry 4127 (class 1259 OID 22473)
-- Name: idx_admin_activity_log_action_type; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_admin_activity_log_action_type ON users.admin_activity_log USING btree (action_type);


pg_dump: creating INDEX "users.idx_admin_activity_log_admin_profile_id"
--
-- TOC entry 4128 (class 1259 OID 22474)
-- Name: idx_admin_activity_log_admin_profile_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_admin_activity_log_admin_profile_id ON users.admin_activity_log USING btree (admin_profile_id);


pg_dump: creating INDEX "users.idx_admin_activity_log_created_at"
--
-- TOC entry 4129 (class 1259 OID 22475)
-- Name: idx_admin_activity_log_created_at; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_admin_activity_log_created_at ON users.admin_activity_log USING btree (created_at);


pg_dump: creating INDEX "users.idx_admin_permissions_admin_profile_id"
--
-- TOC entry 4132 (class 1259 OID 22493)
-- Name: idx_admin_permissions_admin_profile_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_admin_permissions_admin_profile_id ON users.admin_permissions USING btree (admin_profile_id);


pg_dump: creating INDEX "users.idx_admin_permissions_permission_type"
--
-- TOC entry 4133 (class 1259 OID 22494)
-- Name: idx_admin_permissions_permission_type; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_admin_permissions_permission_type ON users.admin_permissions USING btree (permission_type);


pg_dump: creating INDEX "users.idx_admin_profiles_is_super_admin"
--
-- TOC entry 4016 (class 1259 OID 22069)
-- Name: idx_admin_profiles_is_super_admin; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_admin_profiles_is_super_admin ON users.admin_profiles USING btree (is_super_admin);


pg_dump: creating INDEX "users.idx_admin_profiles_user_id"
--
-- TOC entry 4017 (class 1259 OID 22070)
-- Name: idx_admin_profiles_user_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_admin_profiles_user_id ON users.admin_profiles USING btree (user_id);


pg_dump: creating INDEX "users.idx_expert_performance_metrics_expert_profile_id"
--
-- TOC entry 4136 (class 1259 OID 22507)
-- Name: idx_expert_performance_metrics_expert_profile_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_expert_performance_metrics_expert_profile_id ON users.expert_performance_metrics USING btree (expert_profile_id);


pg_dump: creating INDEX "users.idx_expert_performance_metrics_period_start"
--
-- TOC entry 4137 (class 1259 OID 22508)
-- Name: idx_expert_performance_metrics_period_start; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_expert_performance_metrics_period_start ON users.expert_performance_metrics USING btree (period_start);


pg_dump: creating INDEX "users.idx_expert_profiles_accuracy_score"
--
-- TOC entry 4022 (class 1259 OID 22090)
-- Name: idx_expert_profiles_accuracy_score; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_expert_profiles_accuracy_score ON users.expert_profiles USING btree (accuracy_score);


pg_dump: creating INDEX "users.idx_expert_profiles_is_verified"
--
-- TOC entry 4023 (class 1259 OID 22091)
-- Name: idx_expert_profiles_is_verified; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_expert_profiles_is_verified ON users.expert_profiles USING btree (is_verified);


pg_dump: creating INDEX "users.idx_expert_profiles_user_id"
--
-- TOC entry 4024 (class 1259 OID 22092)
-- Name: idx_expert_profiles_user_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_expert_profiles_user_id ON users.expert_profiles USING btree (user_id);


pg_dump: creating INDEX "users.idx_expert_specialties_expert_profile_id"
--
-- TOC entry 4140 (class 1259 OID 22519)
-- Name: idx_expert_specialties_expert_profile_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_expert_specialties_expert_profile_id ON users.expert_specialties USING btree (expert_profile_id);


pg_dump: creating INDEX "users.idx_expert_specialties_specialty_type"
--
-- TOC entry 4141 (class 1259 OID 22520)
-- Name: idx_expert_specialties_specialty_type; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_expert_specialties_specialty_type ON users.expert_specialties USING btree (specialty_type);


pg_dump: creating INDEX "users.idx_password_reset_tokens_expires_at"
--
-- TOC entry 4025 (class 1259 OID 22107)
-- Name: idx_password_reset_tokens_expires_at; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_password_reset_tokens_expires_at ON users.password_reset_tokens USING btree (expires_at);


pg_dump: creating INDEX "users.idx_password_reset_tokens_token"
--
-- TOC entry 4026 (class 1259 OID 22108)
-- Name: idx_password_reset_tokens_token; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_password_reset_tokens_token ON users.password_reset_tokens USING btree (token);


pg_dump: creating INDEX "users.idx_password_reset_tokens_user_id"
--
-- TOC entry 4027 (class 1259 OID 22109)
-- Name: idx_password_reset_tokens_user_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_password_reset_tokens_user_id ON users.password_reset_tokens USING btree (user_id);


pg_dump: creating INDEX "users.idx_permissions_name"
--
-- TOC entry 3899 (class 1259 OID 21648)
-- Name: idx_permissions_name; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_permissions_name ON users.permissions USING btree (name);


pg_dump: creating INDEX "users.idx_permissions_resource_type"
--
-- TOC entry 3900 (class 1259 OID 21649)
-- Name: idx_permissions_resource_type; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_permissions_resource_type ON users.permissions USING btree (resource_type);


pg_dump: creating INDEX "users.idx_role_permissions_permission_id"
--
-- TOC entry 4032 (class 1259 OID 22132)
-- Name: idx_role_permissions_permission_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_role_permissions_permission_id ON users.role_permissions USING btree (permission_id);


pg_dump: creating INDEX "users.idx_role_permissions_role_id"
--
-- TOC entry 4033 (class 1259 OID 22133)
-- Name: idx_role_permissions_role_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_role_permissions_role_id ON users.role_permissions USING btree (role_id);


pg_dump: creating INDEX "users.idx_roles_is_active"
--
-- TOC entry 3905 (class 1259 OID 21659)
-- Name: idx_roles_is_active; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_roles_is_active ON users.roles USING btree (is_active);


pg_dump: creating INDEX "users.idx_roles_name"
--
-- TOC entry 3906 (class 1259 OID 21660)
-- Name: idx_roles_name; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_roles_name ON users.roles USING btree (name);


pg_dump: creating INDEX "users.idx_user_activity_log_activity_type"
--
-- TOC entry 4038 (class 1259 OID 22146)
-- Name: idx_user_activity_log_activity_type; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_activity_log_activity_type ON users.user_activity_log USING btree (activity_type);


pg_dump: creating INDEX "users.idx_user_activity_log_created_at"
--
-- TOC entry 4039 (class 1259 OID 22147)
-- Name: idx_user_activity_log_created_at; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_activity_log_created_at ON users.user_activity_log USING btree (created_at);


pg_dump: creating INDEX "users.idx_user_activity_log_user_id"
--
-- TOC entry 4040 (class 1259 OID 22148)
-- Name: idx_user_activity_log_user_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_activity_log_user_id ON users.user_activity_log USING btree (user_id);


pg_dump: creating INDEX "users.idx_user_notifications_created_at"
--
-- TOC entry 4043 (class 1259 OID 22173)
-- Name: idx_user_notifications_created_at; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_notifications_created_at ON users.user_notifications USING btree (created_at);


pg_dump: creating INDEX "users.idx_user_notifications_is_read"
--
-- TOC entry 4044 (class 1259 OID 22174)
-- Name: idx_user_notifications_is_read; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_notifications_is_read ON users.user_notifications USING btree (is_read);


pg_dump: creating INDEX "users.idx_user_notifications_user_id"
--
-- TOC entry 4045 (class 1259 OID 22175)
-- Name: idx_user_notifications_user_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_notifications_user_id ON users.user_notifications USING btree (user_id);


pg_dump: creating INDEX "users.idx_user_preferences_user_id"
--
-- TOC entry 4048 (class 1259 OID 22190)
-- Name: idx_user_preferences_user_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_preferences_user_id ON users.user_preferences USING btree (user_id);


pg_dump: creating INDEX "users.idx_user_roles_role_id"
--
-- TOC entry 4053 (class 1259 OID 22213)
-- Name: idx_user_roles_role_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_roles_role_id ON users.user_roles USING btree (role_id);


pg_dump: creating INDEX "users.idx_user_roles_user_id"
--
-- TOC entry 4054 (class 1259 OID 22214)
-- Name: idx_user_roles_user_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_roles_user_id ON users.user_roles USING btree (user_id);


pg_dump: creating INDEX "users.idx_user_sessions_expires_at"
--
-- TOC entry 4059 (class 1259 OID 22229)
-- Name: idx_user_sessions_expires_at; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_sessions_expires_at ON users.user_sessions USING btree (expires_at);


pg_dump: creating INDEX "users.idx_user_sessions_is_active"
--
-- TOC entry 4060 (class 1259 OID 22230)
-- Name: idx_user_sessions_is_active; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_sessions_is_active ON users.user_sessions USING btree (is_active);


pg_dump: creating INDEX "users.idx_user_sessions_refresh_token"
--
-- TOC entry 4061 (class 1259 OID 22231)
-- Name: idx_user_sessions_refresh_token; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_sessions_refresh_token ON users.user_sessions USING btree (refresh_token);


pg_dump: creating INDEX "users.idx_user_sessions_user_id"
--
-- TOC entry 4062 (class 1259 OID 22232)
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_sessions_user_id ON users.user_sessions USING btree (user_id);


pg_dump: creating INDEX "users.idx_user_subscriptions_expires_at"
--
-- TOC entry 4067 (class 1259 OID 22267)
-- Name: idx_user_subscriptions_expires_at; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_subscriptions_expires_at ON users.user_subscriptions USING btree (expires_at);


pg_dump: creating INDEX "users.idx_user_subscriptions_status"
--
-- TOC entry 4068 (class 1259 OID 22268)
-- Name: idx_user_subscriptions_status; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_subscriptions_status ON users.user_subscriptions USING btree (status);


pg_dump: creating INDEX "users.idx_user_subscriptions_user_id"
--
-- TOC entry 4069 (class 1259 OID 22269)
-- Name: idx_user_subscriptions_user_id; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_user_subscriptions_user_id ON users.user_subscriptions USING btree (user_id);


pg_dump: creating INDEX "users.idx_users_account_status"
--
-- TOC entry 3911 (class 1259 OID 21690)
-- Name: idx_users_account_status; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_users_account_status ON users.users USING btree (account_status);


pg_dump: creating INDEX "users.idx_users_created_at"
--
-- TOC entry 3912 (class 1259 OID 21691)
-- Name: idx_users_created_at; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_users_created_at ON users.users USING btree (created_at);


pg_dump: creating INDEX "users.idx_users_email"
--
-- TOC entry 3913 (class 1259 OID 21692)
-- Name: idx_users_email; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_users_email ON users.users USING btree (email);


pg_dump: creating INDEX "users.idx_users_user_type"
--
-- TOC entry 3914 (class 1259 OID 21693)
-- Name: idx_users_user_type; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_users_user_type ON users.users USING btree (user_type);


pg_dump: creating INDEX "users.idx_users_username"
--
-- TOC entry 3915 (class 1259 OID 21694)
-- Name: idx_users_username; Type: INDEX; Schema: users; Owner: postgres
--

CREATE INDEX idx_users_username ON users.users USING btree (username);


pg_dump: creating FK CONSTRAINT "analytics.api_usage_analytics api_usage_analytics_user_id_fkey"
--
-- TOC entry 4227 (class 2606 OID 21702)
-- Name: api_usage_analytics api_usage_analytics_user_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.api_usage_analytics
    ADD CONSTRAINT api_usage_analytics_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "analytics.expert_analytics expert_analytics_expert_profile_id_fkey"
--
-- TOC entry 4261 (class 2606 OID 22277)
-- Name: expert_analytics expert_analytics_expert_profile_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.expert_analytics
    ADD CONSTRAINT expert_analytics_expert_profile_id_fkey FOREIGN KEY (expert_profile_id) REFERENCES users.expert_profiles(id);


pg_dump: creating FK CONSTRAINT "analytics.model_performance_analytics model_performance_analytics_model_id_fkey"
--
-- TOC entry 4262 (class 2606 OID 22292)
-- Name: model_performance_analytics model_performance_analytics_model_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.model_performance_analytics
    ADD CONSTRAINT model_performance_analytics_model_id_fkey FOREIGN KEY (model_id) REFERENCES ml_models.ml_models(id);


pg_dump: creating FK CONSTRAINT "analytics.prediction_performance_metrics prediction_performance_metrics_league_id_fkey"
--
-- TOC entry 4228 (class 2606 OID 21717)
-- Name: prediction_performance_metrics prediction_performance_metrics_league_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.prediction_performance_metrics
    ADD CONSTRAINT prediction_performance_metrics_league_id_fkey FOREIGN KEY (league_id) REFERENCES predictions.leagues(id);


pg_dump: creating FK CONSTRAINT "analytics.user_activity_log user_activity_log_user_id_fkey"
--
-- TOC entry 4229 (class 2606 OID 21732)
-- Name: user_activity_log user_activity_log_user_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.user_activity_log
    ADD CONSTRAINT user_activity_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "analytics.user_analytics user_analytics_user_id_fkey"
--
-- TOC entry 4230 (class 2606 OID 21756)
-- Name: user_analytics user_analytics_user_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.user_analytics
    ADD CONSTRAINT user_analytics_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "analytics.user_engagement_metrics user_engagement_metrics_user_id_fkey"
--
-- TOC entry 4231 (class 2606 OID 21771)
-- Name: user_engagement_metrics user_engagement_metrics_user_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: postgres
--

ALTER TABLE ONLY analytics.user_engagement_metrics
    ADD CONSTRAINT user_engagement_metrics_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "audit.admin_action_log admin_action_log_admin_profile_id_fkey"
--
-- TOC entry 4263 (class 2606 OID 22306)
-- Name: admin_action_log admin_action_log_admin_profile_id_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.admin_action_log
    ADD CONSTRAINT admin_action_log_admin_profile_id_fkey FOREIGN KEY (admin_profile_id) REFERENCES users.admin_profiles(id);


pg_dump: creating FK CONSTRAINT "audit.admin_action_log admin_action_log_admin_user_id_fkey"
--
-- TOC entry 4264 (class 2606 OID 22311)
-- Name: admin_action_log admin_action_log_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.admin_action_log
    ADD CONSTRAINT admin_action_log_admin_user_id_fkey FOREIGN KEY (admin_user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "audit.admin_action_log admin_action_log_approved_by_admin_id_fkey"
--
-- TOC entry 4265 (class 2606 OID 22316)
-- Name: admin_action_log admin_action_log_approved_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.admin_action_log
    ADD CONSTRAINT admin_action_log_approved_by_admin_id_fkey FOREIGN KEY (approved_by_admin_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "audit.admin_action_log admin_action_log_target_user_id_fkey"
--
-- TOC entry 4266 (class 2606 OID 22321)
-- Name: admin_action_log admin_action_log_target_user_id_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.admin_action_log
    ADD CONSTRAINT admin_action_log_target_user_id_fkey FOREIGN KEY (target_user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "audit.audit_log audit_log_user_id_fkey"
--
-- TOC entry 4232 (class 2606 OID 21818)
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "audit.data_access_log data_access_log_accessed_user_id_fkey"
--
-- TOC entry 4233 (class 2606 OID 21837)
-- Name: data_access_log data_access_log_accessed_user_id_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.data_access_log
    ADD CONSTRAINT data_access_log_accessed_user_id_fkey FOREIGN KEY (accessed_user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "audit.data_access_log data_access_log_user_id_fkey"
--
-- TOC entry 4234 (class 2606 OID 21842)
-- Name: data_access_log data_access_log_user_id_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.data_access_log
    ADD CONSTRAINT data_access_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "audit.data_export_log data_export_log_user_id_fkey"
--
-- TOC entry 4235 (class 2606 OID 21870)
-- Name: data_export_log data_export_log_user_id_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.data_export_log
    ADD CONSTRAINT data_export_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "audit.gdpr_consent_log gdpr_consent_log_user_id_fkey"
--
-- TOC entry 4236 (class 2606 OID 21898)
-- Name: gdpr_consent_log gdpr_consent_log_user_id_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.gdpr_consent_log
    ADD CONSTRAINT gdpr_consent_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "audit.prediction_change_log prediction_change_log_changed_by_fkey"
--
-- TOC entry 4299 (class 2606 OID 22706)
-- Name: prediction_change_log prediction_change_log_changed_by_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.prediction_change_log
    ADD CONSTRAINT prediction_change_log_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "audit.prediction_change_log prediction_change_log_prediction_id_fkey"
--
-- TOC entry 4300 (class 2606 OID 22711)
-- Name: prediction_change_log prediction_change_log_prediction_id_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.prediction_change_log
    ADD CONSTRAINT prediction_change_log_prediction_id_fkey FOREIGN KEY (prediction_id) REFERENCES predictions.predictions(id);


pg_dump: creating FK CONSTRAINT "audit.system_event_log system_event_log_resolved_by_admin_id_fkey"
--
-- TOC entry 4237 (class 2606 OID 21914)
-- Name: system_event_log system_event_log_resolved_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.system_event_log
    ADD CONSTRAINT system_event_log_resolved_by_admin_id_fkey FOREIGN KEY (resolved_by_admin_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "audit.user_action_log user_action_log_user_id_fkey"
--
-- TOC entry 4238 (class 2606 OID 21930)
-- Name: user_action_log user_action_log_user_id_fkey; Type: FK CONSTRAINT; Schema: audit; Owner: postgres
--

ALTER TABLE ONLY audit.user_action_log
    ADD CONSTRAINT user_action_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_ab_test_results ml_ab_test_results_ab_test_id_fkey"
--
-- TOC entry 4284 (class 2606 OID 22528)
-- Name: ml_ab_test_results ml_ab_test_results_ab_test_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_ab_test_results
    ADD CONSTRAINT ml_ab_test_results_ab_test_id_fkey FOREIGN KEY (ab_test_id) REFERENCES ml_models.ml_ab_tests(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_ab_test_results ml_ab_test_results_model_id_fkey"
--
-- TOC entry 4285 (class 2606 OID 22533)
-- Name: ml_ab_test_results ml_ab_test_results_model_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_ab_test_results
    ADD CONSTRAINT ml_ab_test_results_model_id_fkey FOREIGN KEY (model_id) REFERENCES ml_models.ml_models(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_ab_tests ml_ab_tests_created_by_user_id_fkey"
--
-- TOC entry 4267 (class 2606 OID 22337)
-- Name: ml_ab_tests ml_ab_tests_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_ab_tests
    ADD CONSTRAINT ml_ab_tests_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_ab_tests ml_ab_tests_model_a_id_fkey"
--
-- TOC entry 4268 (class 2606 OID 22342)
-- Name: ml_ab_tests ml_ab_tests_model_a_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_ab_tests
    ADD CONSTRAINT ml_ab_tests_model_a_id_fkey FOREIGN KEY (model_a_id) REFERENCES ml_models.ml_models(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_ab_tests ml_ab_tests_model_b_id_fkey"
--
-- TOC entry 4269 (class 2606 OID 22347)
-- Name: ml_ab_tests ml_ab_tests_model_b_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_ab_tests
    ADD CONSTRAINT ml_ab_tests_model_b_id_fkey FOREIGN KEY (model_b_id) REFERENCES ml_models.ml_models(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_ab_tests ml_ab_tests_winner_model_id_fkey"
--
-- TOC entry 4270 (class 2606 OID 22352)
-- Name: ml_ab_tests ml_ab_tests_winner_model_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_ab_tests
    ADD CONSTRAINT ml_ab_tests_winner_model_id_fkey FOREIGN KEY (winner_model_id) REFERENCES ml_models.ml_models(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_ensemble_configs ml_ensemble_configs_ensemble_model_id_fkey"
--
-- TOC entry 4271 (class 2606 OID 22368)
-- Name: ml_ensemble_configs ml_ensemble_configs_ensemble_model_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_ensemble_configs
    ADD CONSTRAINT ml_ensemble_configs_ensemble_model_id_fkey FOREIGN KEY (ensemble_model_id) REFERENCES ml_models.ml_models(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_feature_engineering ml_feature_engineering_created_by_user_id_fkey"
--
-- TOC entry 4239 (class 2606 OID 21946)
-- Name: ml_feature_engineering ml_feature_engineering_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_feature_engineering
    ADD CONSTRAINT ml_feature_engineering_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_feature_engineering ml_feature_engineering_feature_id_fkey"
--
-- TOC entry 4240 (class 2606 OID 21951)
-- Name: ml_feature_engineering ml_feature_engineering_feature_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_feature_engineering
    ADD CONSTRAINT ml_feature_engineering_feature_id_fkey FOREIGN KEY (feature_id) REFERENCES ml_models.ml_features(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_model_deployments ml_model_deployments_deployed_by_user_id_fkey"
--
-- TOC entry 4286 (class 2606 OID 22560)
-- Name: ml_model_deployments ml_model_deployments_deployed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_model_deployments
    ADD CONSTRAINT ml_model_deployments_deployed_by_user_id_fkey FOREIGN KEY (deployed_by_user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_model_deployments ml_model_deployments_model_id_fkey"
--
-- TOC entry 4287 (class 2606 OID 22565)
-- Name: ml_model_deployments ml_model_deployments_model_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_model_deployments
    ADD CONSTRAINT ml_model_deployments_model_id_fkey FOREIGN KEY (model_id) REFERENCES ml_models.ml_models(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_model_deployments ml_model_deployments_model_version_id_fkey"
--
-- TOC entry 4288 (class 2606 OID 22570)
-- Name: ml_model_deployments ml_model_deployments_model_version_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_model_deployments
    ADD CONSTRAINT ml_model_deployments_model_version_id_fkey FOREIGN KEY (model_version_id) REFERENCES ml_models.ml_model_versions(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_model_metadata ml_model_metadata_model_id_fkey"
--
-- TOC entry 4272 (class 2606 OID 22382)
-- Name: ml_model_metadata ml_model_metadata_model_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_model_metadata
    ADD CONSTRAINT ml_model_metadata_model_id_fkey FOREIGN KEY (model_id) REFERENCES ml_models.ml_models(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_model_performance ml_model_performance_model_id_fkey"
--
-- TOC entry 4289 (class 2606 OID 22585)
-- Name: ml_model_performance ml_model_performance_model_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_model_performance
    ADD CONSTRAINT ml_model_performance_model_id_fkey FOREIGN KEY (model_id) REFERENCES ml_models.ml_models(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_model_performance ml_model_performance_model_version_id_fkey"
--
-- TOC entry 4290 (class 2606 OID 22590)
-- Name: ml_model_performance ml_model_performance_model_version_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_model_performance
    ADD CONSTRAINT ml_model_performance_model_version_id_fkey FOREIGN KEY (model_version_id) REFERENCES ml_models.ml_model_versions(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_model_versions ml_model_versions_model_id_fkey"
--
-- TOC entry 4273 (class 2606 OID 22398)
-- Name: ml_model_versions ml_model_versions_model_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_model_versions
    ADD CONSTRAINT ml_model_versions_model_id_fkey FOREIGN KEY (model_id) REFERENCES ml_models.ml_models(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_models ml_models_created_by_user_id_fkey"
--
-- TOC entry 4241 (class 2606 OID 21992)
-- Name: ml_models ml_models_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_models
    ADD CONSTRAINT ml_models_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_predictions ml_predictions_match_id_fkey"
--
-- TOC entry 4274 (class 2606 OID 22413)
-- Name: ml_predictions ml_predictions_match_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_predictions
    ADD CONSTRAINT ml_predictions_match_id_fkey FOREIGN KEY (match_id) REFERENCES predictions.matches(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_predictions ml_predictions_model_id_fkey"
--
-- TOC entry 4275 (class 2606 OID 22418)
-- Name: ml_predictions ml_predictions_model_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_predictions
    ADD CONSTRAINT ml_predictions_model_id_fkey FOREIGN KEY (model_id) REFERENCES ml_models.ml_models(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_predictions ml_predictions_overridden_by_expert_id_fkey"
--
-- TOC entry 4276 (class 2606 OID 22423)
-- Name: ml_predictions ml_predictions_overridden_by_expert_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_predictions
    ADD CONSTRAINT ml_predictions_overridden_by_expert_id_fkey FOREIGN KEY (overridden_by_expert_id) REFERENCES users.expert_profiles(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_training_runs ml_training_runs_model_id_fkey"
--
-- TOC entry 4291 (class 2606 OID 22618)
-- Name: ml_training_runs ml_training_runs_model_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_training_runs
    ADD CONSTRAINT ml_training_runs_model_id_fkey FOREIGN KEY (model_id) REFERENCES ml_models.ml_models(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_training_runs ml_training_runs_model_version_id_fkey"
--
-- TOC entry 4292 (class 2606 OID 22623)
-- Name: ml_training_runs ml_training_runs_model_version_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_training_runs
    ADD CONSTRAINT ml_training_runs_model_version_id_fkey FOREIGN KEY (model_version_id) REFERENCES ml_models.ml_model_versions(id);


pg_dump: creating FK CONSTRAINT "ml_models.ml_training_runs ml_training_runs_triggered_by_user_id_fkey"
--
-- TOC entry 4293 (class 2606 OID 22628)
-- Name: ml_training_runs ml_training_runs_triggered_by_user_id_fkey; Type: FK CONSTRAINT; Schema: ml_models; Owner: postgres
--

ALTER TABLE ONLY ml_models.ml_training_runs
    ADD CONSTRAINT ml_training_runs_triggered_by_user_id_fkey FOREIGN KEY (triggered_by_user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "predictions.match_results match_results_match_id_fkey"
--
-- TOC entry 4277 (class 2606 OID 22441)
-- Name: match_results match_results_match_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.match_results
    ADD CONSTRAINT match_results_match_id_fkey FOREIGN KEY (match_id) REFERENCES predictions.matches(id);


pg_dump: creating FK CONSTRAINT "predictions.match_statistics match_statistics_match_id_fkey"
--
-- TOC entry 4278 (class 2606 OID 22454)
-- Name: match_statistics match_statistics_match_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.match_statistics
    ADD CONSTRAINT match_statistics_match_id_fkey FOREIGN KEY (match_id) REFERENCES predictions.matches(id);


pg_dump: creating FK CONSTRAINT "predictions.matches matches_away_team_id_fkey"
--
-- TOC entry 4242 (class 2606 OID 22022)
-- Name: matches matches_away_team_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.matches
    ADD CONSTRAINT matches_away_team_id_fkey FOREIGN KEY (away_team_id) REFERENCES predictions.teams(id);


pg_dump: creating FK CONSTRAINT "predictions.matches matches_home_team_id_fkey"
--
-- TOC entry 4243 (class 2606 OID 22027)
-- Name: matches matches_home_team_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.matches
    ADD CONSTRAINT matches_home_team_id_fkey FOREIGN KEY (home_team_id) REFERENCES predictions.teams(id);


pg_dump: creating FK CONSTRAINT "predictions.matches matches_league_id_fkey"
--
-- TOC entry 4244 (class 2606 OID 22032)
-- Name: matches matches_league_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.matches
    ADD CONSTRAINT matches_league_id_fkey FOREIGN KEY (league_id) REFERENCES predictions.leagues(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_analytics prediction_analytics_prediction_id_fkey"
--
-- TOC entry 4301 (class 2606 OID 22727)
-- Name: prediction_analytics prediction_analytics_prediction_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_analytics
    ADD CONSTRAINT prediction_analytics_prediction_id_fkey FOREIGN KEY (prediction_id) REFERENCES predictions.predictions(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_audit prediction_audit_prediction_id_fkey"
--
-- TOC entry 4302 (class 2606 OID 22740)
-- Name: prediction_audit prediction_audit_prediction_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_audit
    ADD CONSTRAINT prediction_audit_prediction_id_fkey FOREIGN KEY (prediction_id) REFERENCES predictions.predictions(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_audit prediction_audit_user_id_fkey"
--
-- TOC entry 4303 (class 2606 OID 22745)
-- Name: prediction_audit prediction_audit_user_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_audit
    ADD CONSTRAINT prediction_audit_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_comments prediction_comments_parent_comment_id_fkey"
--
-- TOC entry 4304 (class 2606 OID 22761)
-- Name: prediction_comments prediction_comments_parent_comment_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_comments
    ADD CONSTRAINT prediction_comments_parent_comment_id_fkey FOREIGN KEY (parent_comment_id) REFERENCES predictions.prediction_comments(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_comments prediction_comments_prediction_id_fkey"
--
-- TOC entry 4305 (class 2606 OID 22766)
-- Name: prediction_comments prediction_comments_prediction_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_comments
    ADD CONSTRAINT prediction_comments_prediction_id_fkey FOREIGN KEY (prediction_id) REFERENCES predictions.predictions(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_comments prediction_comments_user_id_fkey"
--
-- TOC entry 4306 (class 2606 OID 22771)
-- Name: prediction_comments prediction_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_comments
    ADD CONSTRAINT prediction_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_markets prediction_markets_prediction_id_fkey"
--
-- TOC entry 4307 (class 2606 OID 22796)
-- Name: prediction_markets prediction_markets_prediction_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_markets
    ADD CONSTRAINT prediction_markets_prediction_id_fkey FOREIGN KEY (prediction_id) REFERENCES predictions.predictions(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_overrides prediction_overrides_expert_profile_id_fkey"
--
-- TOC entry 4308 (class 2606 OID 22812)
-- Name: prediction_overrides prediction_overrides_expert_profile_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_overrides
    ADD CONSTRAINT prediction_overrides_expert_profile_id_fkey FOREIGN KEY (expert_profile_id) REFERENCES users.expert_profiles(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_overrides prediction_overrides_expert_user_id_fkey"
--
-- TOC entry 4309 (class 2606 OID 22817)
-- Name: prediction_overrides prediction_overrides_expert_user_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_overrides
    ADD CONSTRAINT prediction_overrides_expert_user_id_fkey FOREIGN KEY (expert_user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_overrides prediction_overrides_original_ml_prediction_id_fkey"
--
-- TOC entry 4310 (class 2606 OID 22822)
-- Name: prediction_overrides prediction_overrides_original_ml_prediction_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_overrides
    ADD CONSTRAINT prediction_overrides_original_ml_prediction_id_fkey FOREIGN KEY (original_ml_prediction_id) REFERENCES ml_models.ml_predictions(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_overrides prediction_overrides_prediction_id_fkey"
--
-- TOC entry 4311 (class 2606 OID 22827)
-- Name: prediction_overrides prediction_overrides_prediction_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_overrides
    ADD CONSTRAINT prediction_overrides_prediction_id_fkey FOREIGN KEY (prediction_id) REFERENCES predictions.predictions(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_overrides prediction_overrides_reviewed_by_admin_id_fkey"
--
-- TOC entry 4312 (class 2606 OID 22832)
-- Name: prediction_overrides prediction_overrides_reviewed_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_overrides
    ADD CONSTRAINT prediction_overrides_reviewed_by_admin_id_fkey FOREIGN KEY (reviewed_by_admin_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_results prediction_results_match_result_id_fkey"
--
-- TOC entry 4313 (class 2606 OID 22858)
-- Name: prediction_results prediction_results_match_result_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_results
    ADD CONSTRAINT prediction_results_match_result_id_fkey FOREIGN KEY (match_result_id) REFERENCES predictions.match_results(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_results prediction_results_prediction_id_fkey"
--
-- TOC entry 4314 (class 2606 OID 22863)
-- Name: prediction_results prediction_results_prediction_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_results
    ADD CONSTRAINT prediction_results_prediction_id_fkey FOREIGN KEY (prediction_id) REFERENCES predictions.predictions(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_shares prediction_shares_prediction_id_fkey"
--
-- TOC entry 4315 (class 2606 OID 22878)
-- Name: prediction_shares prediction_shares_prediction_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_shares
    ADD CONSTRAINT prediction_shares_prediction_id_fkey FOREIGN KEY (prediction_id) REFERENCES predictions.predictions(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_shares prediction_shares_user_id_fkey"
--
-- TOC entry 4316 (class 2606 OID 22883)
-- Name: prediction_shares prediction_shares_user_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_shares
    ADD CONSTRAINT prediction_shares_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "predictions.prediction_templates prediction_templates_created_by_fkey"
--
-- TOC entry 4245 (class 2606 OID 22050)
-- Name: prediction_templates prediction_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.prediction_templates
    ADD CONSTRAINT prediction_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "predictions.predictions predictions_approved_by_fkey"
--
-- TOC entry 4294 (class 2606 OID 22668)
-- Name: predictions predictions_approved_by_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.predictions
    ADD CONSTRAINT predictions_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "predictions.predictions predictions_created_by_fkey"
--
-- TOC entry 4295 (class 2606 OID 22673)
-- Name: predictions predictions_created_by_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.predictions
    ADD CONSTRAINT predictions_created_by_fkey FOREIGN KEY (created_by) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "predictions.predictions predictions_expert_profile_id_fkey"
--
-- TOC entry 4296 (class 2606 OID 22678)
-- Name: predictions predictions_expert_profile_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.predictions
    ADD CONSTRAINT predictions_expert_profile_id_fkey FOREIGN KEY (expert_profile_id) REFERENCES users.expert_profiles(id);


pg_dump: creating FK CONSTRAINT "predictions.predictions predictions_match_id_fkey"
--
-- TOC entry 4297 (class 2606 OID 22683)
-- Name: predictions predictions_match_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.predictions
    ADD CONSTRAINT predictions_match_id_fkey FOREIGN KEY (match_id) REFERENCES predictions.matches(id);


pg_dump: creating FK CONSTRAINT "predictions.predictions predictions_ml_prediction_id_fkey"
--
-- TOC entry 4298 (class 2606 OID 22688)
-- Name: predictions predictions_ml_prediction_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.predictions
    ADD CONSTRAINT predictions_ml_prediction_id_fkey FOREIGN KEY (ml_prediction_id) REFERENCES ml_models.ml_predictions(id);


pg_dump: creating FK CONSTRAINT "predictions.user_prediction_feedback user_prediction_feedback_prediction_id_fkey"
--
-- TOC entry 4317 (class 2606 OID 22900)
-- Name: user_prediction_feedback user_prediction_feedback_prediction_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.user_prediction_feedback
    ADD CONSTRAINT user_prediction_feedback_prediction_id_fkey FOREIGN KEY (prediction_id) REFERENCES predictions.predictions(id);


pg_dump: creating FK CONSTRAINT "predictions.user_prediction_feedback user_prediction_feedback_user_id_fkey"
--
-- TOC entry 4318 (class 2606 OID 22905)
-- Name: user_prediction_feedback user_prediction_feedback_user_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.user_prediction_feedback
    ADD CONSTRAINT user_prediction_feedback_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "predictions.user_prediction_views user_prediction_views_prediction_id_fkey"
--
-- TOC entry 4319 (class 2606 OID 22919)
-- Name: user_prediction_views user_prediction_views_prediction_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.user_prediction_views
    ADD CONSTRAINT user_prediction_views_prediction_id_fkey FOREIGN KEY (prediction_id) REFERENCES predictions.predictions(id);


pg_dump: creating FK CONSTRAINT "predictions.user_prediction_views user_prediction_views_user_id_fkey"
--
-- TOC entry 4320 (class 2606 OID 22924)
-- Name: user_prediction_views user_prediction_views_user_id_fkey; Type: FK CONSTRAINT; Schema: predictions; Owner: postgres
--

ALTER TABLE ONLY predictions.user_prediction_views
    ADD CONSTRAINT user_prediction_views_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.admin_activity_log admin_activity_log_admin_profile_id_fkey"
--
-- TOC entry 4279 (class 2606 OID 22468)
-- Name: admin_activity_log admin_activity_log_admin_profile_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.admin_activity_log
    ADD CONSTRAINT admin_activity_log_admin_profile_id_fkey FOREIGN KEY (admin_profile_id) REFERENCES users.admin_profiles(id);


pg_dump: creating FK CONSTRAINT "users.admin_permissions admin_permissions_admin_profile_id_fkey"
--
-- TOC entry 4280 (class 2606 OID 22483)
-- Name: admin_permissions admin_permissions_admin_profile_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.admin_permissions
    ADD CONSTRAINT admin_permissions_admin_profile_id_fkey FOREIGN KEY (admin_profile_id) REFERENCES users.admin_profiles(id);


pg_dump: creating FK CONSTRAINT "users.admin_permissions admin_permissions_granted_by_admin_id_fkey"
--
-- TOC entry 4281 (class 2606 OID 22488)
-- Name: admin_permissions admin_permissions_granted_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.admin_permissions
    ADD CONSTRAINT admin_permissions_granted_by_admin_id_fkey FOREIGN KEY (granted_by_admin_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.admin_profiles admin_profiles_user_id_fkey"
--
-- TOC entry 4246 (class 2606 OID 22064)
-- Name: admin_profiles admin_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.admin_profiles
    ADD CONSTRAINT admin_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.expert_performance_metrics expert_performance_metrics_expert_profile_id_fkey"
--
-- TOC entry 4282 (class 2606 OID 22502)
-- Name: expert_performance_metrics expert_performance_metrics_expert_profile_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.expert_performance_metrics
    ADD CONSTRAINT expert_performance_metrics_expert_profile_id_fkey FOREIGN KEY (expert_profile_id) REFERENCES users.expert_profiles(id);


pg_dump: creating FK CONSTRAINT "users.expert_profiles expert_profiles_user_id_fkey"
--
-- TOC entry 4247 (class 2606 OID 22080)
-- Name: expert_profiles expert_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.expert_profiles
    ADD CONSTRAINT expert_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.expert_profiles expert_profiles_verified_by_admin_id_fkey"
--
-- TOC entry 4248 (class 2606 OID 22085)
-- Name: expert_profiles expert_profiles_verified_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.expert_profiles
    ADD CONSTRAINT expert_profiles_verified_by_admin_id_fkey FOREIGN KEY (verified_by_admin_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.expert_specialties expert_specialties_expert_profile_id_fkey"
--
-- TOC entry 4283 (class 2606 OID 22514)
-- Name: expert_specialties expert_specialties_expert_profile_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.expert_specialties
    ADD CONSTRAINT expert_specialties_expert_profile_id_fkey FOREIGN KEY (expert_profile_id) REFERENCES users.expert_profiles(id);


pg_dump: creating FK CONSTRAINT "users.password_reset_tokens password_reset_tokens_user_id_fkey"
--
-- TOC entry 4249 (class 2606 OID 22102)
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.role_permissions role_permissions_granted_by_admin_id_fkey"
--
-- TOC entry 4250 (class 2606 OID 22117)
-- Name: role_permissions role_permissions_granted_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.role_permissions
    ADD CONSTRAINT role_permissions_granted_by_admin_id_fkey FOREIGN KEY (granted_by_admin_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.role_permissions role_permissions_permission_id_fkey"
--
-- TOC entry 4251 (class 2606 OID 22122)
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES users.permissions(id);


pg_dump: creating FK CONSTRAINT "users.role_permissions role_permissions_role_id_fkey"
--
-- TOC entry 4252 (class 2606 OID 22127)
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES users.roles(id);


pg_dump: creating FK CONSTRAINT "users.user_activity_log user_activity_log_user_id_fkey"
--
-- TOC entry 4253 (class 2606 OID 22141)
-- Name: user_activity_log user_activity_log_user_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_activity_log
    ADD CONSTRAINT user_activity_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.user_notifications user_notifications_user_id_fkey"
--
-- TOC entry 4254 (class 2606 OID 22168)
-- Name: user_notifications user_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_notifications
    ADD CONSTRAINT user_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.user_preferences user_preferences_user_id_fkey"
--
-- TOC entry 4255 (class 2606 OID 22185)
-- Name: user_preferences user_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_preferences
    ADD CONSTRAINT user_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.user_roles user_roles_assigned_by_admin_id_fkey"
--
-- TOC entry 4256 (class 2606 OID 22198)
-- Name: user_roles user_roles_assigned_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_roles
    ADD CONSTRAINT user_roles_assigned_by_admin_id_fkey FOREIGN KEY (assigned_by_admin_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.user_roles user_roles_role_id_fkey"
--
-- TOC entry 4257 (class 2606 OID 22203)
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES users.roles(id);


pg_dump: creating FK CONSTRAINT "users.user_roles user_roles_user_id_fkey"
--
-- TOC entry 4258 (class 2606 OID 22208)
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.user_sessions user_sessions_user_id_fkey"
--
-- TOC entry 4259 (class 2606 OID 22224)
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating FK CONSTRAINT "users.user_subscriptions user_subscriptions_user_id_fkey"
--
-- TOC entry 4260 (class 2606 OID 22262)
-- Name: user_subscriptions user_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.user_subscriptions
    ADD CONSTRAINT user_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


pg_dump: creating DEFAULT ACL "analytics.DEFAULT PRIVILEGES FOR TABLES"
--
-- TOC entry 2616 (class 826 OID 17102)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: analytics; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA analytics GRANT ALL ON TABLES  TO postgres;


pg_dump: creating DEFAULT ACL "audit.DEFAULT PRIVILEGES FOR TABLES"
--
-- TOC entry 2617 (class 826 OID 17103)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: audit; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA audit GRANT ALL ON TABLES  TO postgres;


pg_dump: creating DEFAULT ACL "ml_models.DEFAULT PRIVILEGES FOR TABLES"
--
-- TOC entry 2615 (class 826 OID 17101)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: ml_models; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA ml_models GRANT ALL ON TABLES  TO postgres;


pg_dump: creating DEFAULT ACL "predictions.DEFAULT PRIVILEGES FOR TABLES"
--
-- TOC entry 2614 (class 826 OID 17100)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: predictions; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA predictions GRANT ALL ON TABLES  TO postgres;


pg_dump: creating DEFAULT ACL "users.DEFAULT PRIVILEGES FOR TABLES"
--
-- TOC entry 2613 (class 826 OID 17099)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: users; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA users GRANT ALL ON TABLES  TO postgres;


-- Completed on 2025-10-09 02:49:41 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict EgneefYQixXTeWaKaunCsxPltTcz7aNYxYcxmzzauW1xthQVgGFQfPU4mU3BSdE

